ATMS PRO P114.23 – SAFE FLIGHT EVIDENCE GUARDS – 09.10.2026
ONE-ZIP guarded patch. Only this zip is uploaded to GitHub main root.
Baseline GitHub main HEAD (freshly confirmed): bcf1056285a75cd777b103a9482394dda747f84f
Source P114.22 -> P114.23, no ride import or data cleanup.
Changes: direction-bound LO405 opposite-route diagnostic; usable-board classification and safe missing-flight
FlightStats single fallback; explicit carrier+number from FlightStats; preview-only source rejection codes.
Existing two-source, same-day, same-direction gates stay fail-closed. No silent flight correction.
Two new preBuild regression gates: runtimeAssetAlignmentP11423 and safeFlightEvidenceP11423.
The existing P11422 safe-flight-preview preBuild gate is still required.
This ZIP is SOURCE, not APK; only install GitHub Actions successful APK after confirmation.
