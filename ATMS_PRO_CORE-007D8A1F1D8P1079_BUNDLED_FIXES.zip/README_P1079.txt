ATMS PRO · CORE-007D8A1F1D8P1079 · BUNDLED FIXES
Basis: GitHub main HEAD fae1ebb1be8b04bc4278ff80970a6ba0b7c93668 (P1078 bot-applied main)
Datum: 05.10.2026

Gebündelte, realgerätbestätigte Punkte:
1) Native Back Navigation
   - Android-System-Zurück auf root „Fahrten“ beendet die App nicht sofort.
   - Erster Zurück-Impuls auf root Fahrten armiert das Beenden und zeigt einen Hinweis.
   - Zweiter Android-Zurück-Impuls innerhalb 3,2 s beendet die Native Activity.
   - Der sichtbare Fahrten-Zurück-Button beendet die App weiterhin nie.

2) About Metadata Sync
   - Version: CORE-007D8A1F1D8P1079
   - Letzte Aktualisierung: 05.10.2026
   - Produkt-Build bleibt bewusst „Stable Native-App · V1.4.0 Final“.

3) About Polish
   - Mehr Luft oberhalb des Hero-Bereichs.
   - Fahrzeugdarstellung etwas kleiner und ruhiger positioniert.
   - Goldrahmen sauberer/gleichmäßiger hervorgehoben.

4) Flugprüfung-Zusammenfassung
   - Nach automatischer Flugprüfung nutzt der sichtbare Bereich „Flugprüfung offen“ denselben strengen Verifikationszustand wie die Auto-Pipeline.
   - Ein weiterhin sicher offener, nicht streng verifizierter Flug (z. B. Unsupported/Fremdairport wie VL1972) kann nicht mehr gleichzeitig mit „✓ Keine Flugprüfung offen“ angezeigt werden.
   - Keine Route, Flugnummer, Flugort- oder FLIGHT-008-Entscheidung wird durch diesen UI-Sync verändert.

Unverändert:
OCR-Erkennung, Flugnummern-Normalisierung, FLIGHT-008-Verifikationsregeln, PLAN/DISPO/LIVE-Zeiten, Preise, Fahrer-/Fahrzeugdaten, Dedupe, P102/P103/P105, Storage V2, Backup-/Archivdaten und Persistenz.

Lokale Prüfungen vor Paketierung:
- node --check app.js: OK
- node --check plan-import.js: OK
- node --check service-worker.js: OK
- MainActivity.java Klammer-/Bridge-Selbstcheck: OK
- Lokaler Gradle-Build nicht ausgeführt, da gradle im Arbeitscontainer nicht installiert ist; GitHub validate-install-build bleibt der verbindliche Build-Gate.
