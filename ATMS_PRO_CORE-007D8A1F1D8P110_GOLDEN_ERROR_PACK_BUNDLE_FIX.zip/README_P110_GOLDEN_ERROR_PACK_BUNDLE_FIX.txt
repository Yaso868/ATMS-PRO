ATMS PRO · CORE-007D8A1F1D8P110
GOLDEN ERROR PACK BUNDLE FIX
Stand: 06.10.2026

PATCHBASIS
- Frisch vom Nutzer unmittelbar vor Patchstart heruntergeladenes GitHub-main-Archiv: ATMS-PRO-main.zip
- Archiv-SHA-256: 8981fd8bab3610e5b72cb01fc12698a90f00d7997eaf04cc54d033859816a412
- In der Patchbasis verifiziert: android-native/app/src/main/assets/js/plan-import.js = CORE-007D8A1F1D8P1094
- In der Patchbasis verifiziert: index.html zeigt CORE-007D8A1F1D8P1094
- GitHub-Source-Archive enthaelt keinen Commit-SHA. Ein HEAD-SHA wurde daher NICHT geraten oder erfunden.

BEHOBENE GOLDEN-ERROR-KLASSEN
1. Nach/Kunde-Spaltengrenze
   - hochkonfidentes Randwort darf bei flacher Ueberlappung ab 15% nur dann als Route-Wort gelten,
     wenn die bestehende wiederholte Zwei-Zeilen-Geometrie-Evidenz greift; >=90 OCR-Confidence und >=7 px Ueberlappung sind zusaetzlich Pflicht.
   - Ist das Randwort damit bereits sicher dem Ziel zugeordnet, wird derselbe fuehrende Token aus der
     Kundenzelle nur entfernt, wenn der verbleibende Kundenwert mindestens zweimal exakt in derselben Liste vorkommt.
   - Die spaetere Text-Integrity-OCR darf den archivierten Roh-Spillover danach nicht wieder als Kundenwert verwenden.

2. Fahrzeug-Zellbereinigung
   - Nur eindeutige Tabellenrandzeichen | ¦ │ = ~ am Anfang/Ende werden entfernt.
   - Keine inhaltliche Fahrzeug-Hardcodierung.

3. Kurze Firmen-Codes
   - 2-3 reine Buchstaben-Codes in Firma duerfen nur bei eindeutigem Listen-Mehrheitskonsens in der Schreibweise vereinheitlicht werden.
   - Keine Aenderung an Kunden-/Namenslogik und keine inhaltliche Firmenzuordnung.

4. Auffaelliger gemischter Flugpraefix
   - Struktur Ziffer + 2 Buchstaben + Zahl wird als auffaelliger 3er-Praefix lokal gegengeprueft.
   - Keine blinde Entfernung der fuehrenden Ziffer.
   - Automatische Korrektur nur ueber die bestehende lokale Mehrcrop-/Mehrfach-OCR-Long-Prefix-Logik.
   - Bei fehlendem sicheren Konsens bleibt der Fall fail-closed/pruefpflichtig.

5. Performance Low-Confidence-/Long-Prefix-OCR
   - P109.4 lossless PNG-data-URL-Transport wird auch bei diesen spezialisierten direkten Workern genutzt.
   - Crop-Geometrie, Pixel, OCR-Modi, Passzahl, Whitelist und Konsensregeln bleiben unveraendert.

GOLDEN ERROR PACK
- android-native/tools/fixtures/ATMS_GOLDEN_ERROR_PACK_2026-10-06.png
- android-native/tools/fixtures/ATMS_GOLDEN_ERROR_PACK_2026-10-06_manifest.json
- 16 Fehler-/Kontrollzeilen, Plantag 06.10.2026.
- Originalpixel wurden beim Pack nicht skaliert/retuschiert/neu beschriftet.

DETERMINISTISCHE TESTS
- android-native/tools/ocr-regression-selftest.js erweitert.
- Node-Syntaxcheck plan-import.js: PASS
- Node-Syntaxcheck ocr-integrity-core.js: PASS
- Node-Syntaxcheck service-worker.js: PASS
- P109.2 Regression Self-Test: PASS
- P110 Golden Error Pack deterministic self-test: PASS

NICHT GEÄNDERT
- FLIGHT-008 Zwei-Quellen-Freigabe
- PLAN/DISPO/LIVE-Zeitlogik
- Persistenz/Storage/Backup
- Fahrerfarbenlogik
- Preise/Personen
- produktive Daten

REALGERAET-ABNAHME
Nach erfolgreichem GitHub-Build zuerst nur das mitgelieferte Golden Error Pack fuer Plantag 06.10.2026 analysieren.
Der Patch ist erst nach Soll/Ist-Pruefung der Fehler- UND Kontrollzeilen vollstaendig regressionsbestaetigt.
