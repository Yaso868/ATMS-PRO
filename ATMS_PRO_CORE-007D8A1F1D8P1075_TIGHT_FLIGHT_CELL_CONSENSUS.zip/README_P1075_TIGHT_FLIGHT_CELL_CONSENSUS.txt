ATMS PRO · P107.5 TIGHT-FLIGHT-CELL CONSENSUS + REVIEW VISIBILITY
Datum: 04.10.2026
Basis: frisch vom Nutzer hochgeladener GitHub-main-Stand nach P107.4 / Actions #170 Success. Die GitHub-Archiv-ZIP enthaelt selbst keine verlaessliche HEAD-SHA; daher wird keine SHA geraten.

Zweck
- Behebt die im P107.4-Realgeraet-Test verbliebenen Ein-Ziffer-OCR-Faelle bei farbigen Flugzellen.
- Verhindert, dass blockierende Flug-OCR-Fehler samt manueller Korrekturmaske hinter vielen Info-/Recovery-Eintraegen verschwinden.

Produktionslogik
- Keine Airline-, Flugnummer-, Fahrer-, Orts- oder Datums-Hardcodes.
- Schwache bzw. kontextuell widerspruechliche Standard-Flugnummern werden aus zwei engen Crops innerhalb derselben Tabellenzeile nachgelesen.
- Wenn die Primaerwort-Geometrie vorhanden ist, richtet sich der Crop ausschliesslich nach dieser real erkannten Wortbox und bleibt mit Sicherheitsrand innerhalb der Datenzeile. Dadurch werden horizontale Rasterlinien und Nachbarzellen weniger stark in die OCR gezogen.
- Drei OCR-Modi (PSM 6/7/8) stimmen pro Crop ab. Eine automatische Ein-Ziffer-Korrektur bleibt nur bei eindeutigem Mehrfach-Konsens ueber mindestens zwei Crops zulaessig.
- Bleibt die OCR uneindeutig, wird weiterhin fail-closed blockiert; es wird keine Flugnummer geraten.
- Blockierende OCR-Fehler werden in der Vorschau immer vor Warnungen und Info-Korrekturen gerendert. Damit bleibt die vorhandene manuelle Flugnummern-Korrekturmaske sichtbar, auch wenn die Liste mehr als 20 Diagnose-/Recovery-Eintraege erzeugt.
- Service-Worker-Cache auf P1075 angehoben.

Regression
- P107.5 Golden-Test prueft Mehrfach-Konsens einer Ein-Ziffer-Korrektur ueber zwei enge Crops und drei OCR-Modi.
- Test prueft, dass die sichtbare Fehler-Priorisierung und der PSM-6-Modus im Produktionspfad vorhanden sind.
- Alle bisherigen P107.1-P107.4 Golden-Faelle bleiben enthalten.
