ATMS PRO – STORAGE V2 PHASE 2A + FINAL ICON
Basis: GitHub main, vom Nutzer bestaetigter HEAD 73b2c14 am 01.10.2026.

INHALT
- Storage V2 Phase 2A: manuelles Tagesarchiv .atmsarchive.
- Nicht-destruktiv: keine automatische Loeschung, keine automatische Archivierung,
  kein Primary-Switch weg von localStorage.
- Archivdaten werden aus dem gespeicherten localStorage-Bestand erzeugt.
- Anzahl, eindeutige Fahrt-IDs, Done-IDs und SHA-256 werden vor dem Speichern validiert.
- Fuer .atmsarchive verwendet die Native Bridge einen separaten verifizierten Exportpfad:
  Datei schreiben -> Datei wieder lesen -> Byte-fuer-Byte vergleichen -> Datei-SHA-256 bilden.
- Erst nach erfolgreicher Write-Read-Pruefung wird das Archiv in der read-only
  Archivuebersicht registriert.
- Bestehende Backup-/CSV-/XLSX-Exporte benutzen weiterhin den bisherigen nicht-verifizierten
  Exportpfad und werden durch die neue Archivpruefung nicht umgestellt.
- Archivuebersicht liegt unter Einstellungen -> Backup & Wiederherstellen.
- Keine Restore-/Delete-Aktion fuer Archive in Phase 2A.

FINALER LAUNCHER-ICON
- Exakte Referenz aus CURRENT HANDOFF eingebaut:
  ICON_FINAL_BESTAETIGT/ATMS_PRO_APP_ICON_FINAL.png
- SHA256 der exakten Launcher-Ressource:
  12daa774e8d6f308504505186704c53fd907b3ea8fe2becf377e0028078f0c2b
- AndroidManifest verweist auf ic_atms_pro_launcher_final.
- Alte ic_atms_pro_launcher-Ressource ist nur noch ein Alias auf die finale Grafik.
- Native Asset-Icons 192/512 wurden ausschliesslich aus derselben finalen Referenz skaliert.

LOKALE PREFLIGHTS
- app.js: node --check OK.
- Storage-V2-Phase-2A-Archivlogik mit Testdaten: Anzahl/IDs/Done/SHA-256 OK.
- Native Bridge injiziertes JavaScript: node --check OK.
- MainActivity.java: keine offensichtlichen Java-Syntaxfehler; vollstaendiger Android-Build
  erfolgt wie vorgesehen im bestehenden GitHub-Workflow.
- AndroidManifest.xml und Launcher-Alias-XML: XML-Parse OK.
- Patch-SHA256 wird durch SHA256.txt und den GitHub-Patch-Installer verifiziert.
