ATMS PRO – ATMS_PRO_CORE-007D8A1F1D8P11413_HEADERLESS_FLIGHT_GATE_TRACE_ONE_ZIP
08.10.2026 – read-only admission-gate flight provenance for Golden Error 62

AFFECTED: Native-Android headless 13-column OCR import diagnostics.
SCOPE: P11413 is DIAGNOSTIC ONLY (no automatic repair/ride import).
Evidence basis: user real-device P11412 CORE-007D4 message on IMG-20261008-WA0014.jpg: 0 invalid core cells, import refused.
P11413 shows which existing flight-gate rejected, number of rows with flights, count of simultaneous arrival/departure flight codes, first offending excerpt row and both raw flight cells. Bounds/word evidence retained in window.ATMSP11413HeaderlessFlightGateTrace, and imageMeta.headerlessFlightGateTrace.

GUARDS: Does not change recognized values, flight adjudication, arrival/departure direction, time OCR, companies (P11411), zero-silent-error, FLIGHT-008, or persistence. Existing import veto remains fail-closed.
Case 62 becomes DIAGNOSTICALLY OBSERVABLE; NOT marked fixed or complete before Samsung real-device output.

BASED ON: publicly visible GitHub main P11412 source and user-provided ATMS-PRO-main.zip plus the previously validated P11412 installer overlay. Visible prior user commit b3a22c1 (P11412). Full live HEAD SHA could not be fetched independently; verify main=latest P11412 before committing this new ZIP.

APP INSTALLATION: upload THIS ONE ZIP to repository ROOT on main and use GitHub Actions workflow `ATMS PRO Native APK + Patch Installer`. The GitHub workflow validates SHA256.txt, overlays android-native/, runs signed Gradle APK build + preBuild gates and publishes APK artifact. This ZIP itself is not an APK.

TESTING: 12/12 P11413 production-function positive/negative tests passed with OCR stub (not real Android OCR). All 21 existing/new functional/preBuild Node gates PASS. Golden 62-case registry copied verbatim, old 61 cases preserved. Real-device validation must still be performed and may reveal one remaining genuine flight conflict.
No new registrations / paid APIs. No rides imported.
