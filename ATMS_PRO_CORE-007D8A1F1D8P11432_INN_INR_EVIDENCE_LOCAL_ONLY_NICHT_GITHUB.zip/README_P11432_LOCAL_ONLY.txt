ATMS PRO P11432 – LOCAL ONLY / NO GITHUB WRITE / NO APK BUILD

Scope: exact source-evidence Inn/Inr terminal glyph OCR false import block only.
Read-only verified test branch base: 5b3a99e6b9241f44e8760c28100a09b78b450c4d
One installer ZIP for branch atms-price-p11429-test-only. NEVER upload without
new explicit GitHub-write and auto-build user approval. Never write main.

Changes: only two insertions into P11431 plan-import.js and corrected route-G4
positive/negative source regressions. 33/33 source replay PASS, 12/12 final
integrity PASS, 29/29 price gate PASS, 27/27 price source harness PASS.
Existing price OCR functions EXACT bytes unchanged in core JS. Primary-route
proof requires complete/high geometric original cell, >=90 source cell confidence,
>=95 original Inn word confidence and strict in-cell word bounding box, with no
competing Inr raw original word or prior unresolved conflict. Does not rewrite Inn
or suppress other semantic edits. Never assumes repeated OCR views are independent.

The mandatory P11431 G4 source test file is updated in this local ZIP (the previous
test expected the wrong block). The P11432 runtime generation selftest is added,
existing price tests, final-integrity and all other build gates stay mandatory.

This is a local source fix only: full Golden73, GitHub Actions, signed APK and
Samsung E2E have NOT run on this code. Historical R6/R9 no-block evidence gates
remain open and no production approval is implied. No rides or app data modified.

Upload would automatically trigger GitHub Actions, signed debug APK generation,
ZIP removal and a bot commit on the TEST branch. Not authorized yet.
