ATMS PRO P11438 – SEPARATE QA2-APP + GESCHUETZTE STABILE SIGNATUR

NUR der freigegebene GitHub-Testbranch atms-price-p11429-test-only.
Quelle: Commit c44b3d81d38c6bef2c09b7373a403b10a42a171e (P11437)
Version: P11438 / versionCode 15
Neue Android-Paketkennung debug UND release: de.atmspro.app.qa2.
Neuer Launchername: ATMS PRO TEST 2.
Nicht identisch mit produktiver App oder bisheriger P11436 Test-App .qa.

Dauerhafte Signatur: Der bestehende durch GitHub Secrets geschuetzte
ATMS_SIGNING_* Keystore wird fuer diese ISOLIERTE QA2-App wiederverwendet.
Im ZIP / Repository ist KEIN privater Schluessel enthalten. Das Runtime-Gate
VERBIETET ein stilles Fallback auf wechselnde Debug-Zertifikate.
Die gebaute APK muss mit keytool gegen die persistente Keystore-Public-Cert
belegt werden und die neue Paketkennung enthalten.

Bewahrung: P11437 gzip:false/Offline OCR und anschliessende echte APK-
Sprachdateipruefung bleiben aktiv, alle Fahrtdaten-, Golden-, Tageswechsel-
und Flug-Konfliktschutzfunktionen bleiben bytegenau unveraendert.

NICHT: Hauptbranch, Samsung-Apps, Installationen, Loeschung, Datenmigration,
Import, Masteraenderungen. Bestehende QA-Versionen koennen parallel bleiben.
ZIP ist ein PATCH – keine APK. Kein echter Samsung-Golden-Test nachgewiesen.
