ATMS PRO · P102 · CURRENT PLAN KEEP PREVIEW
Datum: 02.10.2026
Basis: frisch heruntergeladener GitHub-main-Stand nach P101 / Commit 7af013b
Source ZIP SHA-256: 475869677751e9b4626ec84de77aeec32d13cbfc365a550a65981beb0eaa54a3

ZIEL
====
Sicherheitsstufe fuer die spaetere Funktion „Nur aktuelle Planliste behalten“.
P102 zeigt ausschliesslich eine Vorschau und erlaubt, einzelne aeltere Carryover-Fahrten
mit „📌 Behalten“ zu schuetzen.

WICHTIG: P102 LOESCHT KEINE FAHRT.
Es gibt in P102 keine Bereinigungs-, Archivierungs- oder Verschiebeaktion fuer Fahrten.

ERKENNUNG
=========
Aktuelle Fahrten:
- Fahrt ist NICHT gleichzeitig _planCarryover===true UND _planMissingFromLatest===true.

Aeltere Carryover-Fahrten:
- _planCarryover===true UND _planMissingFromLatest===true.

Die Abgrenzung verwendet damit exakt die bereits vorhandene P32/P99-Merge-Markierung
und fuehrt keine neue heuristische Fahrterkennung ein.

VORSCHAU
========
Der neue Bereich „🧹 Nur aktuelle Planliste behalten · Vorschau“ zeigt:
- aktuelle Planliste
- aeltere Carryover-Fahrten
- davon „📌 behalten“
- spaeter bereinigbare Fahrten

Zusaetzlich wird der aktuelle erkannte Bestand gegen incomingCount der letzten bestaetigten
Plan-Import-Session abgeglichen. Bei Gleichheit erscheint eine gruene Bestaetigung;
bei Abweichung nur eine Warnung. Auch bei Warnung wird nichts veraendert.

BEHALTEN-MARKIERUNG
===================
- Einzelne aeltere Fahrten koennen mit „📌 Behalten“ markiert werden.
- Nochmaliges Antippen hebt die Markierung auf.
- Speicher-Key: atms_plan_keep_pinned_v1
- Der Key ist in Backup, Persistence-Safety und Durable-Shadow geschuetzt.
- Ein bewusster kompletter Plan-Neustart setzt diese Pins explizit leer.

REALBESTAND-DRY-RUN
===================
Mit dem verifizierten Sicherheitsbackup ATMS_Backup_2026-10-02_12-14.atms wurde die
P102-Abgrenzung ohne Datenmutation gegengeprueft:
- gespeicherte Fahrten: 156
- letzte bestaetigte Plan-Import-Session incomingCount: 13
- als aktuelle Planliste erkannt: 13
- als aeltere Carryover erkannt: 143
- Abgleich: exakt

Die 143 Carryover-Fahrten verteilen sich im Backup auf vorhandene Plantage; darunter auch
4 Fahrten vom 01.10.2026, die nicht zur neuesten 13-Fahrten-Planversion gehoeren.
Das ist beabsichtigt: P102 trennt nach letzter Planversion, nicht nur nach Datum.

UNVERAENDERT
============
- Fahrtdaten selbst
- Done/Erledigt-Status
- P101 Storage V2 Phase 2B
- Tagesarchive / .atmsarchive
- P100 Adressbuch-Kandidaten
- OCR / plan-import.js
- Import-/Dedupe-/Bundle-Logik
- PLAN / DISPO / LIVE
- FLIGHT-008
- Routing

TEST NACH INSTALLATION
======================
1. Import-Seite oeffnen; KEINE Planliste neu importieren.
2. Im P102-Vorschaubereich fuer den aktuellen Realbestand erwarten:
   - 13 aktuelle Planliste
   - 143 aeltere Carryover
   - 0 behalten
   - 143 spaeter bereinigbar
   - „✓ Aktuelle Planliste eindeutig abgegrenzt“
3. Genau eine aeltere Fahrt mit „📌 Behalten“ markieren.
4. Erwartung: 1 behalten / 142 spaeter bereinigbar; Gesamtfahrten bleiben 156.
5. App neu starten; Pin muss bestehen bleiben.

Erst nach bestandenem P102-Realgeraet-Test darf eine spaetere destruktive Bereinigungsstufe
ueberhaupt entworfen/aktiviert werden.
