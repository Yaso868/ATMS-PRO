ATMS PRO – P11445 ORIGINAL-PHOTO GRID FENCE, QA2 BUILD-GATED ONE-ZIP
23.10.2026 · only GitHub atms-price-p11429-test-only · parent BASE 990979efa02a9fbbf8f6f0abb78d29177e229273.
NOT main, TEST1 or production. No Samsung writes, import or data restore.
SOURCE P11444; TARGET P11445; Android package de.atmspro.app.qa2 preserved.
Only 9 explicitly audited files changed/added; 14 critical WATCH files unchanged.
Patch closes the 23.10 physical-row OCR crossing of 08:55/09:10 in Y346-395 by
recognizing horizontal rules on the actual image pixels, accepting only the
unique adjacent-rule interval, then clipping BOTH OCR scales before cell analysis.
Actual 08:55 original: 35,70 EUR, not 35,00 or 3500. No global OCR price transforms.
Physical grid uncertainties, contradictions and neighbour collisions remain blocked.
All 18 visually distinct original rides are a Golden reference (not imported).
CLI original-photo proof and synthetic source-grid negative regressions PASS;
43/43 mandatory preBuild Exec gates PASS (includes historical source, flight,
Get-E, date, price and P11444-R6 guards). A real Samsung WASM photo test is
NOT yet proven; only install TEST2 after successful GitHub signed APK build.
The GitHub Actions existing installer will verify the exact baseline, SOURCE
and TARGET version, SHA256 and WATCH gate before building and committing.
