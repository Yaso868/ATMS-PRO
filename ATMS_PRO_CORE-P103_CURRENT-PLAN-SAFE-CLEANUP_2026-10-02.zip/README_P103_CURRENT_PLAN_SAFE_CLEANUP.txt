ATMS PRO · P103 · CURRENT-PLAN SAFE CLEANUP
Datum: 02.10.2026
Basis: frisch heruntergeladener GitHub-main nach P102.1 / finalem Installer-Commit 4b5fd42.

ZIEL
Die bisherige P102/P102.1-Vorschau „Nur aktuelle Planliste behalten“ bekommt die echte, ausdrücklich bestätigte Bereinigungsstufe.

SICHERHEITSGATES VOR JEGLICHER ENTFERNUNG
1. Aktuelle Planliste muss weiterhin eindeutig abgegrenzt sein.
2. Ein erfolgreich gespeichertes ATMS-Backup muss nach dem aktuellen bestätigten Import erstellt worden und höchstens 24 Stunden alt sein.
3. Storage V2 muss vor Preflight und erneut direkt vor Entfernung exakt synchron sein.
4. Der persistente Android-Archivordner muss weiterhin gültige Lese-/Schreibrechte besitzen.
5. Jede zu entfernende Fahrt braucht eine eindeutige ID und ein archivfähiges Datum.
6. Für jeden betroffenen Tag wird VORHER ein neues .atmsarchive geschrieben, nativ zurückgelesen und byte-/SHA-256-genau bestätigt.
7. Der Preflight speichert Kandidaten-IDs sowie SHA-256 des unveränderten Fahrten-/Erledigt-Speichers. Jede zwischenzeitliche Änderung blockiert die Entfernung.
8. Erst danach erscheint die zweite, ausdrücklich bestätigte Schaltfläche zur Entfernung.

BEREINIGUNG
- Entfernt ausschließlich P102-removalCandidates = ältere Carryover-Fahrten ohne „📌 Behalten“.
- Aktuelle Fahrten bleiben erhalten.
- „📌 Behalten“-Fahrten bleiben erhalten.
- Zugehörige Erledigt-IDs und Ride-Overrides der entfernten Fahrten werden bereinigt.
- Alte lokale Import-Rollback-Snapshots werden nach erfolgreicher Bereinigung entfernt, damit sie den bereinigten Altbestand nicht versehentlich wieder einspielen.
- Planlisten-Historie, Archive, Backup, Fahrer, Disponenten, Adressbuch, P100-Kandidaten, Einstellungen und Flight-Cache bleiben erhalten.
- Nach der Entfernung werden Durable Shadow und Storage V2 neu geschrieben und exakt geprüft.
- Bei Schreib-/Sync-Fehlern wird der vorherige aktive Fahrtenbestand sofort zurückgerollt und erneut synchronisiert.

REALBESTAND-TROCKENPRÜFUNG MIT VERIFIZIERTEM BACKUP VOM 02.10.2026 12:14
- Gesamt: 156
- Aktuelle Planliste: 13
- ältere ungeschützte Carryover: 143
- betroffene Archivtage: 7
  23.09.2026 / 25.09.2026 / 26.09.2026 / 27.09.2026 / 28.09.2026 / 30.09.2026 / 01.10.2026
- erwarteter aktiver Bestand nach Bereinigung bei 0 Pins: 13
- Kandidaten-IDs: vollständig und eindeutig
- Tagesabdeckung der Vor-Archive: vollständig

NICHT GEÄNDERT
- OCR / plan-import.js
- P99/P98 Import-/Dedupe-/Bundle-Logik
- PLAN / DISPO / LIVE
- FLIGHT-008
- P100 Adressbuch-Kandidaten
- P101 Storage-V2-Archivbridge / MainActivity

LOKALE PRÜFUNGEN
- node --check app.js: bestanden
- statische Diff-Prüfung: nur app.js + README/SHA im Patch
- Daten-Trockensimulation gegen verifiziertes 156-Fahrten-Backup: 156 -> 13 bei 143 RemovalCandidates, 7 Archivtage, bestanden

WICHTIG
Der GitHub Native Patch Installer muss weiterhin den sauberen Android-Build und die signierte Debug-APK bestätigen. Erst danach Realgerät-Test.
