ATMS PRO CORE-007D8A1F1D8P1149 – BOUNDED COMPANY SOURCE-TAIL OCR

Freigabe: JETZT PATCHEN (08.10.2026). Keine Freigabe zum Planlistenimport.
Last user-confirmed deployed production: P114.8; last screenshot commit 9e51f38.

PROBLEM: Zeile 17 des Golden-Bildes IMG-20261007-WA0001.jpg traegt Get-E,
aber der unabhaengige Text-Nach-OCR Konflikt GetE blockiert weiter.
Drei zuvor lokal erfolgreiche Patches (P114.6/P114.7/P114.8) waren am
Realgeraet fuer diesen Fall nicht erfolgreich. Kein erfundener Realgeraet-Beweis.

BILDREPLAY: Im echten Originalbild wird die Firmenzelle bei engem rechten
Zellrand als Get- erkannt, bei einem begrenzt breiteren Crop als Get-E
(in zwei Tesseract-OCR-Modi). Das ist eine plausible geometrische Ursache,
nicht der exakte aufgezeichnete interne Android-Zustand.

FIX: Fuer kurze Firmen-Codes mit internem Delimiter ein zusaetzliches,
beschraenkt nach rechts erweitertes originalbildbasiertes OCR-Quorum.
Zwei verschiedene OCR-Modi und mindestens drei identische andere Planzeilen
sind erforderlich. Ein echtes Nachbarwort im erweiterten Bereich, fehlende
sichere Nachbargeometrie, konkurrierende Quell-Zellbelege, Wortsubstitution,
falsche Row/Column-Evidenz, und leere oder widersprechende Ergebnisse bleiben
fail closed. Kein Bild-/Firmen-/Flug-/Zeilen-Wert in Produktionslogik hardcodiert.

TESTS: node tools/company-adaptive-tail-selftest-p1149.js prueft reale
Entscheidungsfunktionen mit Positiv-/Negativ- und Fail-Closed-Matrix.
Zusaetzlich wurde der Ziel-Zellzuschnitt aus dem Originalbild lokal mittels
Tesseract OCR eng/deu PSM 6/7 gelesen; weitere Golden-Regressionen bleiben.
Ein vollstaendiger Android/WebView-Tesseract.js-Realgeraetelauf ist noch nicht
bewiesen und darf NICHT als bereits erfolgreich beschrieben werden.

MASTER-PROMPT: die vom Nutzer freigegebene V1.3 und P114.8 Realgeraet-
Fehlerdokumentation eingespielt; keine neue dauerhafte Prozessregel ohne
separate Zustimmung. Golden-Pack 60 bestehende Faelle ohne Dublette.

SICHERHEIT: GitHub main ist Source of Truth. Die Live-HEAD-Verifikation war
via Web und Netzwerk technisch nicht moeglich. Der produzierte Kandidat muss
vor einem produktiven Upload zwingend gegen frisches GitHub-main abgesichert
werden. Ohne HEAD-Vergleich STOP; dies ist kein freigegebener Installationsbeweis.

PLANLISTE NICHT IMPORTIEREN; keine P103-Bereinigung starten.
