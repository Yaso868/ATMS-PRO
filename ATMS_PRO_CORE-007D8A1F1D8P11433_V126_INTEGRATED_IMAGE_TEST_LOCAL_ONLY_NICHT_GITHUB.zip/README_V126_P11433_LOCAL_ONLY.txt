ATMS PRO – V1.26 P11433 INTEGRATED IMAGE-OCR CANDIDATE – LOCAL ONLY

STATUS: NOT GITHUB, NOT APK, NOT INSTALLED, NOT OFFLINE RELEASE.
Exact pre-patch source GitHub testbranch: 260501fefaec74b367bc926a2dd9f6211c875e74
Productive main protected. Current Samsung P11432 has 17 saved rides on 19.10.2026.

Test scope: generic first/last price-cell geometry, 35/47.60 separator evidence,
weak primary route evidence with exact-cell corroboration; preserve Inn/Inr source guard.
Unresolved: original-image Samsung E2E, Get-E contradictory cell read, full Golden-73,
reimport persistence, licensing, fully bundled offline OCR, 9/16 open flight checks.
Test-only preview mode first; NEVER automatically reimport the saved 17 rides.

This archive contains ONE guarded patch for branch 260501fefaec74b367bc926a2dd9f6211c875e74, not the release APK.
Upload to GitHub would automatically trigger Actions build and commit on testbranch.
No GitHub write, APK build, Samsung installation, data changes or costs are authorized by this file.

Preserves existing flight-based bundle pricing. New user requirement for two differing
flight numbers / two distinct price input fields is only documented for later UI work,
not implemented in this candidate.
