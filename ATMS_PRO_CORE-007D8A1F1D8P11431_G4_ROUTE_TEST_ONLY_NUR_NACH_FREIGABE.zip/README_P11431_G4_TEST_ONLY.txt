ATMS PRO P11431 – G4-INTEGRIERTE TESTVERSION / NO AUTOMATIC DEPLOY

ONLY for GitHub test branch atms-price-p11429-test-only, base 5878d20f4673f5b19e6574d771980c987505a1cb.
DO NOT upload without a new explicit GitHub write + automatic-build approval.
Repo main is out of scope. No real device install or data import has been authorized.

Payload: P11430 price-OCR release source + unchanged local Inn/Inr and G4 source JS;
P11431 Android version and PWA cache generation; two mandatory G4 source tests;
price admission and price interior OCR preBuild tests preserved.

PREVIOUS LOCAL TEST EVIDENCE: G4 route 20/20, G4 final 12/12, isolated price 27/27,
price traces before/after identical. Historic Golden73 full run NOT performed;
WA0014 R6/R9 expected no-block vs conservative Inn/Inr conflict remains OPEN.
Native Android Gradle/APK/keystore/sig and Samsung live E2E NOT checked.
CI push of the ZIP WILL AUTO-TRIGGER THE WORKFLOW AND BOT COMMIT: separate approval required.

Installer guard: upload commit must change exactly ONE ZIP at repository root.
BASE_COMMIT must be ancestor of upload commit parent, old P11430, new P11431.
The exact baseline and watched hashes are covered by README_PATCH_BASELINE.txt + SHA256.txt.
