ATMS PRO · P100 ADDRESS-CANDIDATE PC ROUNDTRIP
Datum: 2026-10-02

Basis
- Native-App: android-native/app/src/main/assets/js/app.js
- Ausgangsstand: vom Nutzer direkt aus GitHub main heruntergeladene aktuelle Native-Datei nach P99.4R.
- Fachlicher Stand bleibt P99.3; P99.4R hat nur den verworfenen OCR-Parallelversuch zurückgenommen.

Ziel
1. Offene P98-Adressbuch-Kandidaten separat als Excel oder CSV exportieren.
2. Datei am PC ergänzen. Unterstützte Aktion je Zeile: OFFEN, ÜBERNEHMEN, IGNORIEREN.
3. Sicherer Reimport mit Vorschau/Zusammenfassung vor jeder Änderung.
4. Nur kollisionsfreie neue Adressen werden additiv angelegt. Bestehende Adressen werden niemals automatisch überschrieben oder gelöscht.
5. Kandidaten-ID hält die Rückzuordnung stabil, auch wenn der Kurzname am PC geändert wird.
6. Wird der Kurzname geändert, bleibt der ursprünglich erkannte Planname automatisch als Alias erhalten.
7. Typ, Telefon, Website, Google Maps, Hinweise und Quellen werden in das bereits vorhandene strukturierte Notizformat übernommen.
8. IGNORIEREN setzt ausschließlich den bestehenden Kandidatenstatus. OFFEN ändert nichts.
9. Konflikte, fehlende Adressen, ungültige Aktionen und nicht zuordenbare Zeilen bleiben unverändert/offen.
10. Native Speichern-unter-Bridge wird für Excel/CSV weiterverwendet.

Neue Oberfläche
Einstellungen > Import & Export > Adressbuch-Kandidaten
- Bearbeitete Datei einlesen
- Excel exportieren
- CSV exportieren

Excel/CSV-Spalten
Aktion | Erkannter Name | Kurzname / Planname | Typ | Vollständige Adresse | Alias 1 | Alias 2 | Telefon | Website | Google Maps | Hinweise | Quellen | Abholung Anzahl | Ziel Anzahl | Letzter Plantag | Kandidaten-ID (nicht ändern)

Sicherheit
- Keine Änderung an Fahrtdaten, Import/Dedupe/Bundles, Datum, OCR, PLAN/DISPO/LIVE oder FLIGHT-008.
- Keine Änderung an Storage V2.
- Keine automatische Adresslöschung oder -überschreibung.
- Vor Anwendung wird eine Zusammenfassung per Bestätigungsdialog gezeigt.
- Vor/bei Kandidatenimport wird die bestehende Persistenz-Safety-Schicht verwendet.
- Bei Fehler beim Kandidatenstatus nach neuem Adressschreiben wird der Adressbestand auf den Vorzustand zurückgerollt.

Lokale Vorprüfung
- node --check app.js
- P100 Funktions-/UI-Marker vorhanden
- Patch enthält nur die vollständige Native-app.js plus README/SHA256.
