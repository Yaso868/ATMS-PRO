ATMS PRO · P107.1 OCR INTEGRITY REVIEW GATE · 04.10.2026
Base: freshly downloaded GitHub main after successful P106.4 (#166) verification.

Scope (safely related OCR/import integrity bundle):
- Unresolved suspicious long-prefix flight OCR is import-blocking instead of silently importable.
- Generic correction UI for unresolved flight OCR; local OCR suggestion can be explicitly confirmed or manually entered.
- Strong repeated-list consensus: local candidate may auto-resolve only with at least two independent peer rides from the same direction + flight-location context.
- Driver uncertainty markers ? / ! are preserved and remain review-required.
- Generic trailing OCR marker cleanup for repeated name/customer artifacts; no customer hardcode.
- Driver-cell color sampling gets a spatial/pastel fallback from the CURRENT plan cell.
- Ride rendering uses the ride's own captured plan color as source of truth; uncertain image colors do not fall back to old driver colors.
- Correction audit visibility for flight normalization, flight-location normalization and OCR boundary cleanup.
- Shared deterministic OCR integrity core + Node regression self-test.
- Gradle preBuild runs the regression self-test; GitHub APK build fails if these golden cases regress.

TEST FIXTURES only include historical examples. Production logic contains no literal flight/driver/customer mapping for them.

Not part of P107.1 (separate root causes / later bundle):
- DUS transport/no-JSON + duplicate provider diagnostics
- stale current-ride count/cache refresh
- Morgen-Modus wording/auto-import policy audit
