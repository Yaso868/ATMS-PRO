ATMS PRO – CORE-007D8A1F1D8P36 OFFICIAL AIRPORT AUTO-FLIGHT
Stand: 22.09.2026

ZIEL
- Sauberer Planimport prüft DUS und CGN zuerst automatisch über die bereits vorhandene offizielle Airport-Datenschicht.
- Ein eindeutiger datumsspezifischer Treffer aus genau EINER offiziellen Airport-Quelle darf nur als source_confirmed übernommen werden.
- verified/high bleibt unverändert mindestens ZWEI unabhängigen datumsspezifischen Quellen vorbehalten.
- airportIata, airportEventDate, date und direction werden beim Ergebnis-Matching zwingend geprüft.
- flightTime bleibt zusätzliches Unterscheidungsmerkmal und wird vom Provider zurückgespiegelt.
- Nur ungelöste Flüge fallen auf den bisherigen Gemini-/manuellen Fallback zurück.

GEÄNDERTE DATEIEN
1. android-native/app/src/main/assets/js/plan-import.js
2. android-native/app/src/main/assets/js/flight-data-provider.js

NICHT GEÄNDERT
- OCR-/Preis-/Fahrerlogik
- PLAN/DISPO/LIVE-Semantik
- Native DUS-Allowlist / Endpoint
- APK-Signing / Secrets / Workflow
- Persistenzlogik
- manueller Gemini-Fallback

SICHERHEIT
- Einzelquelle wird niemals zu verified/high hochgestuft.
- source_confirmed erfordert exakt eine Quelle, gültigen Gegenairport-IATA, eindeutigen Ort, keinen Konflikt und exakte Fahrtidentität.
- Vorhandener widersprüchlicher Planort wird durch eine Einzelquelle nicht überschrieben.
- Unbekannte/nicht konfigurierte Airports bleiben offen und werden nicht geraten.

LOKALE PRÜFUNGEN VOR VERPACKUNG
- node --check plan-import.js: PASS
- node --check flight-data-provider.js: PASS
- DUS Native Transport Contract + Parser Self-Test: PASS
- DUS flightTime echo 20:00: PASS
- Patch enthält ausschließlich die zwei Native-JS-Dateien + README + SHA256.

RUNTIME-TEST NACH APK-BUILD
- Noch offen: echter Import einer aktuellen Planliste mit DUS/CGN-Flug.
- Erwartung: eindeutiger offizieller Einzelquellen-Treffer erscheint als source_confirmed; kein verified/high.
- Andere/unklare Airports bleiben sicher offen bzw. nutzen den bisherigen Fallback.
