ATMS PRO P11439 - QA2 TEST 2 - NUR DIAGNOSE (kein OCR-Heilversprechen)

ZIP nur lokal vorbereitet, NICHT hochgeladen / NICHT gebaut.
Ziel-Branch: atms-price-p11429-test-only. main strikt tabu.
Ein einziger Testbranch-One-ZIP-Commit mit exakt diesem Archiv im Root löst einen GitHub-Workflow aus, nach vorheriger ausdrücklicher Freigabe.
Runtime P11439, Android versionCode 16, dieselbe getrennte QA2-Paketkennung und derselbe persistente QA2-Signier-Schlüssel.
Sperrt weiterhin unsicher rekonstruierte Zeilen. Gibt Diagnoseposition/Grund statt generischer Meldung.
Alte OCR-Erkennung unverändert; das 22/22 Samsung-End-to-End-Ergebnis ist OFFEN.
Installieren / Planliste nur Testanalyse / kein Import erst nach gesonderter Freigabe.
Lokale Quellen und alte Versionen behalten. Keine Arbeitsdateien/Referenzbilder im ZIP.

R2 LOCAL H35 PREBUILD CORRECTION AFTER FAILED ACTIONS #254:
Only the historical H35 source guard is aligned to the current P11439 plan-import script.
Existing original H35 helper hashes/order and all prior fail-closed controls are still mandatory.
This does NOT repair the underlying image OCR; it only removes the obsolete version assertion.
Important: failed #254 left the old P11439 ZIP at branch root. Remove it before uploading a single R2 ZIP; upload commit must ONLY add R2 ZIP.
No GitHub writes/build/installation authorized by this LOCAL corrective task.
