ATMS PRO · P106.2 · OCR SCHEMA + PERFORMANCE FIX · 02.10.2026

Basis:
- frischer GitHub-main nach P106.1 / Native Build #163
- P106 Mehrbild-, Fahrername- und Fahrerfarbenlogik bleibt erhalten
- P106.1 nativer Ein-/Mehrfach-Dateiwähler bleibt unverändert

Belegter Realgerätefehler:
- vollständige 8-Fahrten-Bildliste wurde zwar gelesen, aber die erste Kopfzeilen-Uhrzeit kam als "Uhrzett" aus der Primär-OCR.
- dadurch erkannte die Schemaauswahl nur zwei statt drei Uhrzeit-Anker und rekonstruierte fälschlich 13 statt 14 Spalten.
- Folge: rechte Tabellenhälfte verschob sich semantisch; Fahrer wurden als zusammengesetzte Resttexte gelesen (z. B. Fahrzeug/Pax/Flugzeit/Ort/Fahrer), Flugnummern landeten in falschen Feldern.
- danach startete unnötig sehr teure lokale Nach-OCR: Realtest gesamt ca. 220 s, davon missing_driver_targeted_ocr ca. 173 s und missing_flight_targeted_ocr ca. 30 s.
- der fehlerhafte Analyse-Lauf wurde NICHT übernommen; aktiver Bestand blieb unverändert.

Fix:
1) Header-Schema
- ausschließlich das Kopfzeilenwort "Uhrzeit" darf bei genau EINER OCR-Zeichenabweichung strukturell normalisiert werden.
- Beispiel des Realfalls: "Uhrzett" -> "Uhrzeit".
- dadurch wird die echte 14-Spalten-Preisliste mit mittlerer Spiegelzeit wieder als 14-Spalten-Schema erkannt.
- keine Fahrtdaten, Namen, Flugnummern oder Orte werden über diese Regel korrigiert.

2) Performance-/Sicherheitsguard
- wenn trotz Header-Reparatur mindestens die Hälfte mehrerer Zeilen gleichzeitig
  a) zusammengerutschte Fahrerwerte und
  b) fehlende Flugnummern mit flugnummernartigem Inhalt in der Ort-Spalte zeigen,
  bricht ATMS VOR der teuren Zell-Nach-OCR fail-closed ab.
- dadurch kein minutenlanger OCR-Lauf auf klar verschobenem Tabellenschema.

Nicht geändert:
- P105 Archiv-Restore / Backups / Storage V2 / P103
- P106 Mehrbild-Zusammenführung
- P106 Selm->Selim Mehrfach-OCR-Konsens
- P106 Fahrerfarben-Integritätsprüfung
- P106.1 Android-Dateiwähler
- Flugverifikation / FLIGHT-008 / Routing / Preise / Dedupe

Verbindlicher Realtest nach Installation:
A) exakt dasselbe einzelne 8-Fahrten-Hauptbild erneut analysieren.
   Erwartung:
   - Schema 14 Spalten; Diagnose-Mapping u. a. driver=13, flightTime=11
   - Fahrer wieder nur als Namen, keine zusammengesetzten Resttexte
   - 6 eindeutige Flüge wieder als Flugnummern erkannt
   - keine 220-s-Regressionslaufzeit
B) danach erst den P106 Mehrbild-Test mit Hauptbild + Fortsetzungsbild durchführen.
   Erwartung: 10 Fahrten inkl. XC333/XC334; Fahrerfarben danach separat prüfen.
