ATMS PRO · P109.0 · Text Cell Integrity Gate / Silent OCR Safety
Datum: 05.10.2026
Source of Truth: GitHub main, unmittelbar vor Patch-Freigabe auf Realgerät verifiziert
Basis-Commit: dd3057e
Basis-Commit-Titel: Apply validated ATMS patch: ATMS_PRO_CORE-007D8A1F1D8P1080_IMPORT_QUALITY_GATE
Parent laut GitHub: edfe237

Ziel
- Behebt keine einzelnen Kunden-/Ortsnamen per Hardcode, sondern die allgemeine Fehlerklasse „formal plausibler, aber bildseitig falscher Freitext“.
- Ausgangsbelege: führendes OCR-Randartefakt im Kundenfeld sowie Diakritik-/Glyphen-Aufspaltung in Freitext.
- Customer/Partner werden nicht als zwei unabhängige Quellen gewertet; Partner bleibt Alias aus Customer/Firma.
- Unsichere Text-OCR bleibt fail-closed: ungelöster echter Bildkonflikt blockiert die automatische Übernahme.

A) Text Cell Integrity Gate
- Neue wiederverwendbare Gegenprüfung für Name/Kunde, Firma und Flugort.
- Ein zusätzlicher deutscher Spaltenlauf dient nur als günstiger Trigger/Beweisquelle.
- Nur tatsächlich auffällige Zeilen erhalten zwei lokale Zell-Nach-OCRs mit unterschiedlichen PSM/Crop-Konfigurationen.
- Automatische Korrektur verlangt mindestens 1 DEU-Spaltenbeleg + 2 lokale Zellbelege desselben sicheren Alternativtexts.
- Bei starkem Gegenbeweis ohne eindeutigen Sieger wird ein Import-blockierender text_ocr-Fehler erzeugt.

B) Diakritik / Glyphen-Split
- Keine Regel „ii → ü“ und kein Wörterbuch.
- Eine mögliche schmale Doppelglyphen-Sequenz ist ausschließlich ein Recheck-Trigger und korrigiert niemals selbst.
- Distanz-2-Änderungen sind nur als bildbestätigte Diakritik-Wiederherstellung zugelassen; ohne ausreichenden Konsens bleibt der Wert offen/blockiert.
- OCR-spezifische München-Fehlvarianten werden nicht mehr per Einzel-Ortsalias korrigiert; der Bildkonsens entscheidet. Die bestehende semantische ASCII-Transliteration bleibt erhalten.

C) Leading/Trailing OCR-Artefakte
- Keine pauschale trim-punctuation-Regel.
- Randinterpunktion löst nur Gegenprüfung aus.
- Selbst bei starkem DEU-Spalten-/Zellkonsens darf eine Randzeichen-Korrektur nur erfolgen, wenn derselbe Zieltext zusätzlich mindestens zweimal in derselben aktuellen Planliste vorkommt.
- Fehlt dieser zusätzliche Same-Plan-Beleg, wird fail-closed blockiert statt legitime Interpunktion zu entfernen.

D) Diagnose / Transparenz
- customerRawOcr wird bei Bildimporten als echter Primärwert erhalten, nicht nur bei bereits erfolgreicher Boundary-Recovery.
- Neue Diagnosefelder: *TargetedOcrAttempts, *OcrInitial, *OcrAutoCorrected, *OcrCorrectionSource, *OcrEvidence, *OcrConflict, *OcrConflictCandidate, *OcrSuspicious.
- validate() zeigt sichere Korrekturen als ocr_recovery und ungelöste Textkonflikte als Fehler.
- Automatische Planübernahme bleibt dadurch bei unresolved text_ocr blockiert.

E) Performance
- Pro geeigneter Textspalte nur EIN zusätzlicher DEU-Batchlauf.
- Teure lokale OCR ausschließlich für echte Near-Conflict-/Randzeichen-/Glyphensplit-Trigger.
- P54-Diagnose enthält neuen Stage-Namen text_integrity_ocr.
- Keine 3×-OCR für jede Textzelle.

Anti-Hardcode
- Keine Kunden-, Fahrer-, Flugnummer-, Zeilen-, Dateinamen- oder Datums-Sonderregel.
- Keine konkreten Regressionwerte im Produktionscode.
- Keine Firma→Kunde- oder Flug→Kunde-Zuordnung.
- Keine alte Planliste / Stammdaten als versteckte Wahrheit.
- Keine automatische Korrektur nur aufgrund „ungewöhnlicher“ Schreibweise.

Golden Regression – Realgerät nach Installation
1. IMG-20261005-WA0023.jpg erneut analysieren.
2. 29/29 Fahrten und bestehende P108.0-Erfolge müssen erhalten bleiben.
3. sourceRow 18: Name/Kunde und Partner müssen bildgetreu ohne führendes Fremdzeichen vorliegen ODER bei fehlendem Konsens explizit blockiert werden; niemals still falsch + „0 Fehler“.
4. sourceRow 30: Diakritischer Kundenname muss bei starkem Bildkonsens korrekt übernommen werden ODER explizit blockiert werden; niemals still als plausible ASCII-Fehlsegmentierung durchlaufen.
5. Frühere Diakritik-Regression bei Ortsnamen erneut mit verfügbarer Referenzplanliste prüfen; keine ii→ü-Sonderregel.
6. Keine legitime Interpunktion darf ohne den zusätzlichen Same-Plan-Beleg entfernt werden.
7. Erweiterter JSON-Import auf customerRawOcr, customerTargetedOcrAttempts und Ocr*-Diagnose prüfen.
8. OCR-Performance Stage text_integrity_ocr und Gesamtzeit notieren.

Lokale Vorprüfung
- node --check ocr-integrity-core.js: PASS
- node --check plan-import.js: PASS
- node --check service-worker.js: PASS
- android-native/tools/ocr-regression-selftest.js auf rekonstruiertem P108.0-Repo: PASS
- Android/Gradle-Build lokal nicht ausgeführt, da im bereitgestellten Source-Snapshot kein Gradle-Wrapper und im Container kein Gradle-Binary vorhanden ist. Der GitHub-Patch-Installer muss wie bisher den clean signed debug APK build als endgültiges Build-Gate ausführen.
