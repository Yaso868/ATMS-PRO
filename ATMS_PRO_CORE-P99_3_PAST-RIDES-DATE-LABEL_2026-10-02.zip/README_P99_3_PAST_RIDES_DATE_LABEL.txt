ATMS PRO · P99.3 PAST-RIDES DATE LABEL
Datum: 2026-10-02

Frisch verifizierte Basis:
- GitHub main wurde unmittelbar vor Erstellung über die aktuelle Commit-Historie auf dem Realgerät geprüft.
- Branch: main.
- Im Ordner android-native/app/src/main/assets/js ist der neueste sichtbare github-actions[bot]-Commit:
  Apply validated ATMS patch: ATMS_PRO_CORE-P99_2_LEGACY-PARTNER-FIRMA-IDENTITY_2026-10-02
- Basisdatei ist exakt die P99.2 app.js, die durch diesen validierten Patch auf main übernommen wurde.
- Keine ältere ZIP wurde ungeprüft als Codebasis verwendet.

Anlass / belegte Erkenntnis:
- Zwei scheinbar doppelte XR6574-Karten waren tatsächlich zwei echte historische Fahrten verschiedener Tage:
  * 26.09.2026 (ältere Fahrt)
  * 02.10.2026 (aktuelle Folgetag-Fahrt)
- Beide sehen im Bereich „Vergangene Fahrten“ nahezu identisch aus, weil dort das Fahrtdatum auf der Karte nicht sichtbar ist.
- Es darf deshalb KEINE Dedupe-/Löschregel greifen; die Historie muss erhalten bleiben.

Ziel P99.3:
1. Nur im Bereich „Vergangene Fahrten“ das echte Fahrtdatum direkt auf jeder Fahrtenkarte anzeigen.
2. Darstellung kompakt als „📅 TT.MM.JJJJ“ unter der Fahrtzeit.
3. Aktuelle/offene Fahrten und „Erledigte Fahrten“ bleiben optisch unverändert.
4. Es werden keinerlei Fahrtdaten verändert.

Technische Umsetzung:
- rideCard() erhält eine reine Render-Option showPastDate.
- Nur past.map(...) setzt showPastDate=true.
- Datum wird aus date -> planDate -> datum gelesen und nur bei gültigem ISO-Datum YYYY-MM-DD angezeigt.
- Formatierung nutzt die bestehende atmsFormatIsoDateDe()-Funktion.

Unverändert:
- Import/OCR und Folgetag-Logik
- P98/P99/P99.1/P99.2-Dedupe- und Merge-Regeln
- Bundle-Logik
- Erledigt-Status
- Fahrtenpersistenz
- Storage V2
- Backup/Wiederherstellen
- FLIGHT-008 / LIVE
- Adressbuch-Kandidaten / P100

Lokale Vorprüfung:
- node --check app.js: OK
- Nur app.js wird funktional verändert.
- Keine Datenmigration.
- Kein Startup-Cleanup.

Gezielter Realgerät-Test nach Build:
- App öffnen -> Fahrten -> „Vergangene Fahrten“ aufklappen.
- Beim XR6574-Vergleich müssen die beiden echten historischen Fahrten anhand des Datums sofort unterscheidbar sein:
  * 📅 02.10.2026 bei der Fahrt mit Flugzeit 02:04 / Hurghada
  * 📅 26.09.2026 bei der älteren Fahrt mit Flugzeit 01:35 / Flugort nicht verfügbar
- Keine erneute Planlistenanalyse erforderlich.
