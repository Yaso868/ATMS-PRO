ATMS PRO · P99 SOURCE-ROW REIMPORT + DATE-SAFE BUNDLES
Datum: 2026-10-02

Basis vor Patch:
- GitHub main am 02.10.2026 frisch geprüft.
- Aktuelles raw main app.js trägt P98 IMPORT-INTEGRITY + ADDRESS-CANDIDATES.
- Die für P99 betroffenen main-Blöcke bundleGroupKey(), planImportStableRideIdentity() und mergePlanImportByIdentity() wurden gegen die P98-Arbeitsbasis abgeglichen.
- Build #144 / P98 wurde auf dem Realgerät erfolgreich installiert und der P98-Importtest bestätigt.
- Kein älteres Repository-ZIP wird ungeprüft als Codebasis verwendet.

Enthaltene vollständige Datei:
- android-native/app/src/main/assets/js/app.js

Ziele des Patches:
1. Re-Import derselben Quellzeile:
   - Neue Herkunftsidentität: sourceFile + sourceRow + planDate.
   - Nur wenn alle drei Werte vorhanden sind; Alt-/Fremdimporte ohne expliziten Plantag bleiben unangetastet (fail closed).
   - Bei erneutem Import derselben Quellzeile werden ältere Varianten dieser Quellzeile konsumiert statt als Carryover weitergeführt.
   - Dadurch können sichere spätere Korrekturen von Zeit, Fahrt-Datum, Route, Flug/Firma usw. die alte Variante ersetzen, ohne Dublette zu erzeugen.
   - Wenn bereits eine exakt passende neue Variante existiert, wird diese bevorzugt und weitere Varianten derselben Quellzeile werden dedupliziert.

2. Bündel nur innerhalb desselben Fahrtags:
   - bundleGroupKey enthält zusätzlich das Fahrt-Datum.
   - Gleichartige Fahrten verschiedener Kalendertage dürfen nicht mehr implizit zusammengebündelt werden.
   - P98-Fahrzeug-/Preis-Kompatibilitätsgate bleibt unverändert bestehen.
   - Explizite bundleStops und bestehende echte Bündelpfade bleiben unverändert.

Belegter Realgerät-Fall:
- XC112 und XR6574 wurden vor P98 als 11:35 am 01.10. gespeichert und nach P98 korrekt als 01:35 am 02.10. neu importiert; die alten Varianten blieben Carryover.
- XR6574 wurde zusätzlich mit einer gleichartigen Fahrt eines anderen Tages visuell zu 12 Personen gebündelt, weil das Datum bisher nicht Teil des Bündelschlüssels war.

Nicht Teil dieses Patches:
- P100 Excel/CSV Export + Reimport der Adressbuch-Kandidaten.
- FLIGHT-008 / Flugstatuslogik.
- Storage V2 Phase 2B.
- Automatische oder globale destruktive Bereinigung.

Lokale Vorprüfung:
- node --check app.js: OK
- synthetischer P99-Test: gleiche sourceFile/sourceRow/planDate trotz 11:35->01:35 und 01.10->02.10 wird als gleiche Quellzeile erkannt: OK
- synthetischer P99-Test: identische Bündelmerkmale an unterschiedlichen Fahrtagen ergeben verschiedene Bündelschlüssel: OK

Gezielter Realgerät-Beweistest nach erfolgreichem Build:
- dieselbe 13-Zeilen-Liste genau EINMAL erneut importieren.
- XC112: nur noch 01:35 / 02.10.2026; kein 11:35-Altstand.
- XR6574: nur noch 01:35 / 02.10.2026; kein 11:35-Altstand.
- XR6574 darf nicht mehr als 12-Personen-Bündelfahrt mit einer Fahrt eines anderen Tages erscheinen.
- P98-EW9223 bleibt getrennt.
