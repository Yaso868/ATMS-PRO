ATMS PRO P11434 LOCAL ONLY - NOT GITHUB / NOT APK / NOT INSTALLED
SOURCE BASE: P11433, testbranch HEAD e77457211d9c8fa17b8fd7fdf502cf5a75209b1a (read-only checked)
P11433 local ZIP SHA-256 46d4e369b47ce7b086e52c5a17a8062232fcea4352728fe2633ce403602d056c
New versionCode 11 is prepared only, NO Android build.
G4 route correction: carry forward source-row and source-column-bound four-view weak original proof; independently replay original evidence at final integrity. No generic route substitution.
Company: only same-row primary source (>=80 confidence) PLUS 2 clean full-cell modes PLUS 2 adaptive source-cell modes can reconcile a single lost internal delimiter without 3 other same-company rides. A clean opposite source reading or two independent competing cell reads veto. No Get-E exception.
Price: preserve existing safe five-attempt decimal recognition and import review; add observational per-cell diagnostic including original OCR attempts; no 3500->35 conversion.
PREREQUISITE: candidate must pass full GitHub repository preBuild/regression only after a separate future authorization to write/build, and real Samsung photo/Golden73/import-gate acceptance. This archive has NOT passed full Android/Golden73/OCR E2E/offline-license gates.
No local project Master change, repository write, APK installation, ride import, reset or restore.
