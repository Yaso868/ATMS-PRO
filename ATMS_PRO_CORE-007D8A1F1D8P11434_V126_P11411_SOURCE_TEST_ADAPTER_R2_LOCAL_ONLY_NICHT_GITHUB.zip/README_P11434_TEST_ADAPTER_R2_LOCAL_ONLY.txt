ATMS P11434 R2 – Lokale NUR-TESTADAPTER-Korrektur nach Actions #244.
Basis ist die schon geprüfte P11434-One-ZIP; ALLE 8 Original-Android-Dateien sind bytegleich.
Zusätzlich die historische P11411-Testdatei mit erwarteter Original-SHA-256 in den Guard aufgenommen.
Nur im Test-Replay werden die bestätigten Zeile/Spalte der Original-Firmenzellansichten gebunden.
Schwache/konträre Quellen und fremde Zellbelege bleiben gesperrt. Original-Foto/Fixture nicht geändert.
P11411 32/32; V1.26 22/22; P11434 41/41 lokal mit synthetischer Golden-MANIFEST-Huelle für P11411.
Keine Produktion-Codeaenderung, kein GitHub-Upload, kein Build, keine Installation, kein Import.
Achtung: Vor erneutem Upload muss die alte fehlgeschlagene ZIP vom TESTBRANCH entfernt sein;
dies ist NICHT freigegeben und darf nicht automatisch geschehen.
