ATMS PRO · P102.1 · CURRENT PLAN PREVIEW UI ANCHOR FIX
Datum: 02.10.2026
Basis: frisch heruntergeladener GitHub-main-Stand nach P102 / Native Build #154
Source ZIP SHA-256: c33f473b9938892211a4fe6fb989b168042af342e2dbe38aba5706da71755339

ZIEL
====
Reiner UI-Anker-Fix fuer die bereits vorhandene, nicht-destruktive P102-Vorschau
„Nur aktuelle Planliste behalten“.

FEHLERBILD AUS DEM REALGERAET-TEST
=================================
P102 war im Native-Build enthalten, wurde aber auf der aktuellen Seite
„Planliste importieren“ nicht sichtbar angezeigt. Ursache: Die Karte wurde indirekt
an das alte Plan-History/Tool-Layout angehaengt statt direkt an die heute sichtbare
Native-Importseite.

AENDERUNG P102.1
================
- Die bestehende P102-Karte wird direkt in #importView > main.import gemountet.
- Position: zwischen der Hauptkarte „Planliste direkt hochladen“ und
  „Erweiterter JSON-Import“.
- Bei jedem Oeffnen der Importseite wird der sichtbare Mount erneut sichergestellt.
- Eine bereits vorhandene P102-Karte wird verschoben statt dupliziert.

WICHTIG: KEINE DATENLOGIK-GEAENDERT
===================================
P102.1 aendert NICHT:
- die P102-Erkennung fuer aktuelle vs. aeltere Carryover-Fahrten
- die Behalten-Markierungen
- Fahrtdaten / IDs / Done-Status
- OCR / plan-import.js
- Import / Dedupe / Bundles
- P101 Storage V2 / Archive / Backup
- P100 Adressbuch-Kandidaten
- PLAN / DISPO / LIVE
- FLIGHT-008
- Routing

P102.1 LOESCHT, ARCHIVIERT ODER VERSCHIEBT KEINE FAHRT.

REALBESTAND-REFERENZ
====================
Das bereits verifizierte Sicherheitsbackup vom 02.10.2026 12:14 ergibt fuer die
unveraenderte P102-Logik:
- 156 gespeicherte Fahrten
- 13 aktuelle Fahrten der letzten bestaetigten Planliste
- 143 aeltere Carryover-Fahrten
- 0 initial angeheftet
- 143 spaeter bereinigbar

TEST NACH INSTALLATION
======================
1. Native-App oeffnen.
2. Import > Planliste importieren.
3. KEINE Datei auswaehlen und KEINE Planliste neu importieren.
4. Erwartung: P102-Karte ist sichtbar zwischen Hauptimport und erweitertem JSON-Import.
5. Erwartete Zaehler: 13 / 143 / 0 / 143 und gruener eindeutiger Abgleich.
6. Erst danach genau eine aeltere Fahrt mit „📌 Behalten“ testen.

APP.JS SHA-256
==============
3f4d818ba17c4be909330ad84d785c1c03a74ed566d003557ce6c1da76a6422a
