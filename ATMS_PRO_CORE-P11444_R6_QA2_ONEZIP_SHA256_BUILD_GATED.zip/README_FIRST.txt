ATMS PRO – P11444-R6 – SIGNIERTER QA2-TEST (ONE-ZIP)

BASIS: GitHub Yaso868/ATMS-PRO, nur Branch atms-price-p11429-test-only,
Basis-Commit: 7ccff9826365cf3fd2401af3e0bad172c1d0a28f.
Das Produktiv-Branch main und gespeicherte Samsung-Fahrten dürfen nicht verändert werden.

INSTALLATION (ausschließlich nach freigegebenem Testbranch-Upload):
1. GitHub-Testbranch öffnen; ausschließlich DIESE ZIP ins Repository-Stammverzeichnis hochladen,
   nicht entpacken, keine anderen Änderungen gleichzeitig committen.
2. GitHub Actions wendet sie über den vorhandenen fail-closed Installer nur nach
   SHA-256- und Original-Quellstandprüfung an.
3. Der Workflow baut eine signierte DEBUG-APK für de.atmspro.app.qa2
   (ATMS PRO TEST 2). Nach bestandenem Build committed Actions die geprüften
   Quellen und entfernt die hochgeladene ZIP automatisch.
4. APK erst nach bestandenem Build und unabhängiger Installationsfreigabe
   auf dem Samsung testen; NUR TESTANALYSE, KEIN Fahrtenimport.

VERBOTEN: Upload auf main, zweite ZIP, Entpacken/Dateiüberschreiben,
Produktiv-App installieren/ersetzen, Fahrten löschen, Backup zurückspielen,
ungeprüfter Build oder echter Import.

ÄNDERUNGEN: P11444-R6 duale quellgebundene Vollzellen-OCR für Hotel-Ziel
und OS166-Zusatznotiz; keine globalen Firmen/Hotel-Aliase, keine Flugzeit-Erfindung.
Samsung-Code und bestehende Fahrten wurden bei lokaler Paket-Erstellung nicht angefasst.

LOKALE TESTS: 42/42 aktive Gradle-preBuild-Exec-Skripte PASS; P11444-R6 293
Regressionsprüfungen einschl. 82 Negativfälle PASS; lokale Gesamtprojektintegration
und Basis-SHA PASS. Ein echter signierter Android-APK-Build und ein Originalfoto-
Samsung-End-to-End-OCR-Test sind damit ausdrücklich NOCH NICHT nachgewiesen.

SICHERHEITSNACHWEIS: README_PATCH_BASELINE.txt (Authentifizierung der Basis
und WATCH-Dateien), SHA256.txt (bytegenaue Payload-Integrität).
