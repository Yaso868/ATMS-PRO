ATMS PRO – P114.24 – AIRPORT FIRST SOURCE REJECTION REASONS (DIAGNOSE ONLY) – 10.10.2026
Guarded Android One-ZIP with exact P114.23 source SHA-256 for all changed assets.
Read-only P114.24 change: show exact-direction/day/airport official source failure code per flight, or
ATMS fallback classification Airport:kein_eindeutiger_tagesbeleg if no confirmed official first source.
Additional diagnostic count: official attempted / matched. Never treat the fallback classification
as the flight provider's own reason. No flight promotion, no import, no ride mutation, no cleanup.
Existing P114.22/P114.23 verification and negative-route gates remain mandatory.
RELEASE BASE VERIFIED: User-provided GitHub main archive comment identifies commit 6325228cd3caa118a90d8ebb0f7d9acbee02fe86; all 7 changed-source and 11 watch-source SHA256 values match that exact archive. GitHub installer must independently enforce the baseline ancestry, correct version and complete SHA256 hashes before accepting this patch.
No claim of a completed GitHub Android build or on-device test for P11424.
