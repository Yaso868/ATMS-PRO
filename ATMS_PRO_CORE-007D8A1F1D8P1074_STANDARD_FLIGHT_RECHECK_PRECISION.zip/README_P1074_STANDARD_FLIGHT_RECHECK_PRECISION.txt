ATMS PRO · P107.4 STANDARD-FLIGHT RECHECK PRECISION
Datum: 04.10.2026
Basis: GitHub main ZIP-Kommentar c7b273ab35faeecc57130bb5e3ed383b11bf1c26 (nach P107.3 / Actions #169 erfolgreich)

Zweck
- Behebt die im P107.3-Realgeraet-Test beobachteten Fehlalarme bei korrekten, zeitgleichen Fluegen mit aehnlicher Nummer, aber unterschiedlichem Flugort.
- Erhaelt gleichzeitig die gezielte Gegenpruefung fuer tatsaechlich verdaechtige Ein-Ziffer-Abweichungen.

Produktionslogik
- Keine Airline-, Flugnummer-, Fahrer-, Orts- oder Datums-Hardcodes.
- Ein zeitgleicher Ein-Ziffer-Peer gilt nur noch als Kontextbeleg, wenn Richtung und Flugzeit gleich sind und bekannte Flugorte ebenfalls uebereinstimmen. Unterschiedliche bekannte Flugorte duerfen sich nicht mehr gegenseitig als OCR-Konflikt markieren.
- Fehlt der Flugort bei beiden Fahrten, bleibt die lokale Gegenpruefung moeglich; es wird weiterhin nichts geraten.
- Die lokale Re-OCR liest bevorzugt exakt das bereits erkannte Flugnummern-Wort mit engem Rand statt die komplette Tabellenzelle.
- Tesseract PSM und Zeichen-Whitelist werden jetzt ueber worker.setParameters(...) tatsaechlich auf den jeweiligen OCR-Worker angewendet.
- Automatische Aenderung bleibt nur bei eindeutigem Mehrfach-Konsens zulaessig. Ungeklaerte wirklich schwache/konfliktbehaftete Zellen bleiben fail-closed und koennen manuell korrigiert werden.
- Service-Worker-Cache auf P1074 angehoben.

Regression
- P107.4 Golden-Test prueft explizit, dass gleichzeitige Fluege mit unterschiedlichem bekanntem Flugort KEINE Peer-Konflikte erzeugen.
- Gleichzeitige Ein-Ziffer-Abweichungen im selben Kontext bleiben pruefbar.
- Starker Mehrfach-OCR-Konsens zugunsten des bereits erkannten Werts wird als sichere Bestaetigung akzeptiert.
- Bisherige P107.1/P107.2/P107.3 Golden-Faelle bleiben enthalten.
