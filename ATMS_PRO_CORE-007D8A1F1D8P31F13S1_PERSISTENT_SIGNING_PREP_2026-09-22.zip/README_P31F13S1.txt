P31F13S1 Persistent APK Signing Preparation
Adds conditional persistent signing support to android-native/app/build.gradle.
No private signing key is included in this patch ZIP.
If signing environment variables are absent, the existing debug signing behavior remains available during migration.
