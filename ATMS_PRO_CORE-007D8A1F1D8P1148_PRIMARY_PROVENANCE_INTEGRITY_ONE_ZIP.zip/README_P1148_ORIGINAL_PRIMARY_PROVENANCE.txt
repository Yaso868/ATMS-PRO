ATMS PRO CORE-007D8A1F1D8P1148 – ORIGINAL PRIMARY PROVENANCE
08.10.2026

BASIS: vom Nutzer bereitgestellte aktuelle ATMS-PRO-main.zip, SHA-256: e2ef05424bfeb69a0e623cd6f9efd6b7254be1ab743af9a1870538defbf82071
Der exakte GitHub-main-Commit-HEAD ist aus dem Downloadarchiv nicht rekonstruierbar und war live technisch nicht abrufbar. Vor Upload muss main sicht- und vergleichbar P1147 Build Repair enthalten; bei neuerem/abweichendem main STOP.

FIX: Der urspruengliche Primaer-OCR-Zellenbeleg wird direkt bei der Vollbild-Zellzuordnung getrennt vom spaeter mutierbaren Verifikationsstatus erfasst. Die P114.7-Konsensauflösung kann bei bereits korrektem Hauptwert diesen Originalbeleg verwenden. Competing exact-cell/expanded source views, semantic alternatives, falscher Ursprungsrow/column, niedrige OCR-Konfidenz und unsichere Zellgrenzen bleiben fail closed.

REGRESSION: Der bestehende Golden Error Case fuer Planliste 07.10.2026 Zeile 17 wird nicht dupliziert; die vom Nutzer freigegebene P114.7-Realgeraet-Fehlerdokumentation V1.2 wird eingebunden, ohne einen positiven P114.8-Realgeraet-Erfolg vorwegzunehmen. P113.4/9MB, EW9420, FLIGHT-008 und alle bestaetigten acht Get-E-Reparaturen sollen unveraendert bleiben.

SOURCE/INSTALLER: GitHub Workflow .github/workflows/android-native-apk.yml akzeptiert EIN ATMS_PRO_CORE-*.zip im Repo-Root. Das ZIP enthaelt ausschliesslich android-native/..., README_*.txt und SHA256.txt; der Installer prueft SHA und fuehrt vor Annahme einen signierten Debug-APK-Build aus.

FREIGABE: Nutzer schrieb PATCHEN, bereits im Chat als Freigabe fuer P114.8 bestaetigt.

WICHTIG: Lokale JS-Tests und simulierte Installer-Pruefung sind keine erfolgreiche GitHub Actions APK und kein bestaetigter Realgeraet-Fix. Die Planliste NICHT importieren.
