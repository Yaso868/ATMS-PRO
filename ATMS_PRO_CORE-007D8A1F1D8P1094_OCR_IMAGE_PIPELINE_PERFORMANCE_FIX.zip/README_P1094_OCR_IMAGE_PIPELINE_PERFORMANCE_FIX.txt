ATMS PRO · CORE-007D8A1F1D8P1094
P109.4 – OCR IMAGE PIPELINE PERFORMANCE FIX
Date: 06.10.2026

BASIS
- Built directly from the fresh ATMS-PRO-main.zip supplied after the P109.3D2 real-device proof.
- Fresh ZIP SHA-256: e29a3c9e563a9a1cf808677d0f7cea9974a07337451f339cb87d4b57cb1e63f7
- Exact P109.3D2 native source hashes before modification:
  * index.html: dfdb058fac955f0a68392a75687cc0108e70dedf5f8537184b3070affe38e70a
  * service-worker.js: 98dcb9cee4671a1d73ab3bf6be5895f26ecf6fb33fa7d3a28db031f5286a553e
  * js/plan-import.js: 97273c7c999d884c3847992ac926ce069b458131f1953fd99766e8d33340138d
- Those three files matched the supplied P109.3D2 diagnostic package byte-for-byte before P109.4 was created.

MEASURED ROOT CAUSE FROM P109.3D2
- Fast real-device run: P54 total about 11.7 s.
- Slow real-device run: P54 total about 109.7 s.
- In the slow run the dominant PRE-recognize loss was inside HTMLCanvasElement.toBlob():
  * full primary 3200x1990: about 13.057 s in canvas.toBlob()
  * early-time crop 446x3770: about 13.024 s in canvas.toBlob()
  * later time crops: about 4.0 s in canvas.toBlob()
  * repeated tiny 396x112 price crops: about 4.0 s each in canvas.toBlob()
  * DEU route/driver crops also showed multi-second toBlob stalls
- Crop creation itself was normally 0–10 ms.
- FileReader was normally only a few ms.
- Worker.postMessage was normally 0–1 ms.
- Worker creation/reuse was therefore not the primary root cause.

P109.4 CHANGE
- Keeps the existing P109.3 shared ENG + DEU workers.
- Keeps every existing OCR pass, crop, dimension, scaling factor, language and PSM behavior.
- Immediately before the existing shared-worker recognition call, an HTMLCanvasElement input is encoded as a LOSSLESS PNG data URL with canvas.toDataURL('image/png').
- Tesseract.js v5 accepts base64 image strings, so this bypasses its Canvas -> toBlob -> FileReader path while preserving the same raster content.
- If lossless PNG data-url conversion is unavailable or throws, ATMS falls back fail-safely to the previous Canvas input path.
- P109PERF and P109D2 diagnostics remain enabled for Run A / Run B proof.
- P109PERF now reports img=png-data-url and enc=<ms> per shared-worker OCR operation.
- P109D2 remains able to show the actual toDataURL / postMessage timing used by the P109.4 path.

UNCHANGED / SAFETY
- No OCR pass removed.
- No PSM removed or reduced.
- No DEU OCR disabled.
- No scaling factor changed.
- No crop geometry changed.
- No row/column mapping changed.
- No customer/place/driver/flight/date/file/row hardcode added.
- P108 time fail-closed logic unchanged.
- P109.2 edge-consensus logic unchanged.
- Avion correction path unchanged.
- Schütz correction path unchanged.
- FLIGHT-008 unchanged.
- Airport-conflict fail-closed behavior unchanged.
- PLAN/DISPO/LIVE unchanged.
- Import/dedupe/bundle logic unchanged.
- Storage V2 / persistence / P103 / archive unchanged.

VISIBLE VERSION / CACHE
- About/version marker: CORE-007D8A1F1D8P1094
- Service-worker cache/query marker updated to P1094 only to force delivery of the changed plan-import.js.

LOCAL VALIDATION
- node --check android-native/app/src/main/assets/js/plan-import.js: PASS
- node --check android-native/app/src/main/assets/service-worker.js: PASS
- android-native/tools/ocr-regression-selftest.js against the patched validation tree: PASS
- P109.2 text-cell edge-consensus self-test: PASS
- Static OCR call-count check before/after P109.4:
  * Tesseract.recognize(: 17 -> 17
  * worker.recognize(: 4 -> 4
  * p109SharedOcrRecognize(: 7 -> 7
  * cropCanvasRegion(: 19 -> 19
  This confirms P109.4 changes image transport only; it does not remove OCR work.

REAL-DEVICE ACCEPTANCE – WA0023
Run A: fresh app start, analyze IMG-20261005-WA0023.jpg.
Run B: analyze the same image again in the same app process.

Functional gate for BOTH runs:
- 29/29 rides
- 0 hints
- 0 OCR errors
- 18 automatic corrections
- ‘Avion -> Avion remains corrected via dual-local + same-plan edge consensus
- Schiitz -> Schütz remains corrected via DEU composite batch + local consensus
- times/prices/routes/drivers unchanged
- automatic import unchanged
- FLIGHT-008 unchanged
- EW522 must remain fail-closed on the DUS vs CGN->BCN conflict when the flight sources are reachable
- Network/DNS failure of DUS/FlightStats is separate from OCR-performance acceptance and must not be misclassified as an OCR regression.

Performance gate:
- ideal P54 total <= 15 s
- acceptable P54 total <= 20 s
- BOTH Run A and Run B must be evaluated
- P109Perf should show workers=2 and img=png-data-url on shared-worker recognize operations
- P109D2 should no longer show the previous recurring multi-second canvas.toBlob stalls on those operations

RECOMMENDED GITHUB COMMIT TITLE
P109.4 – OCR Image Pipeline Performance Fix

RECOMMENDED COMMIT BODY
Bypasses the P109.3D2-proven Android WebView canvas.toBlob() OCR stall by transporting existing shared-worker Canvas inputs as lossless PNG data URLs. Keeps all OCR passes, crops, scales, languages, PSM behavior, consensus/fail-closed rules, Avion/Schütz integrity, FLIGHT-008, import/persistence and PLAN/DISPO/LIVE unchanged. Retains P109PERF/P109D2 for Run A/Run B real-device acceptance.
