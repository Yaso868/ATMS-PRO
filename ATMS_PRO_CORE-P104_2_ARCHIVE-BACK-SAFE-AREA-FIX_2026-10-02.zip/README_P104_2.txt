ATMS PRO · P104.2 · ARCHIVE BACK + PRIMARY SAFE-AREA FIX
Datum: 02.10.2026

Basis:
- frisch vom Nutzer geladener GitHub-main nach P104.1 / Native Build #158

Änderungen:
1. Archiv-Browser READ-ONLY
   - während der Archivansicht wird die äußere „Backup & Wiederherstellen“-Zurückleiste ausgeblendet
   - es bleibt genau ein eindeutiger Zurück-Pfeil im Archiv-Viewer sichtbar
   - Zurück schließt nur den READ-ONLY-Viewer und kehrt zu „Backup & Wiederherstellen“ zurück
   - Android-System-Zurück bleibt über die bestehende Viewer-Abfanglogik nicht-destruktiv

2. Nachrichten
   - mobiler oberer Safe-Area-Abstand analog zu den bestätigten Native-Top-Bars
   - beim echten Wechsel auf den Nachrichten-Tab wird die vertikale Ansicht auf den Seitenanfang gesetzt

3. Live-Dispo
   - mobiler oberer Safe-Area-Abstand analog zu den bestätigten Native-Top-Bars
   - beim echten Wechsel auf Live-Dispo wird die vertikale Ansicht auf den Seitenanfang gesetzt
   - laufende Re-Renders/Refreshes innerhalb Live-Dispo springen NICHT automatisch nach oben

Unverändert:
- Archivformat, Datei-/Payload-SHA-256-Prüfung und READ-ONLY-Logik
- aktive Fahrten, Storage V2, Backups, Archive, Erledigt-Status
- OCR, Import/Dedupe, Bundles, FLIGHT-008
- PLAN/DISPO/LIVE-Berechnungslogik und Persistenz

Lokale Prüfung:
- JavaScript-Syntaxcheck mit node --check: bestanden
- echter Android-Build und Signatur werden ausschließlich durch den GitHub Native Patch Installer bewiesen
