ATMS PRO · P112.1 REALGERÄT-RENDER-FIX
Datum: 06.10.2026

Ausgangslage:
- P112 Build #186 war technisch erfolgreich.
- Realgerät-Render-Gate ist jedoch fehlgeschlagen: Tagesübersicht, Nächste Fahrt / ETA und Letzte Nachricht waren am echten Seitenende nicht sichtbar.

Bestätigte Ursache:
- renderP112DriverCockpitExtension() erzeugte den neuen P112-Block korrekt.
- Der bestehende P26R-Legacy-Cleanup lief danach und blendete alle nach der Warnkarte liegenden DOM-Blöcke aus, deren ID nicht mit "atmsLiveTarget" beginnt.
- Der P112-Block hieß "atmsP112DriverCockpitExtension" und wurde deshalb irrtümlich als Legacy-Nachlauf behandelt und per inline display:none ausgeblendet.

Minimaler Fix:
- Der P112-Cockpit-Block wird mit data-atms-live-primary="1" als produktiver Primärblock markiert.
- Der bestehende P26R-Cleanup respektiert dieses Merkmal und blendet solche Primärblöcke nicht aus.
- Keine Änderung der P112-Datenlogik, GPS-/Trackinglogik, LIVE-/ETA-Semantik, Warnlogik, Nachrichtenpersistenz, OCR, Import, Storage oder Backup.

Abnahme:
- Syntax/Static Render-Gate lokal PASS.
- Ein echter Android-Realgerät-Screenshot ist weiterhin Pflicht.
- P112/P112.1 bleibt bis dahin IN ARBEIT; Build grün allein ist kein Feature-PASS.
