ATMS PRO · CORE-007D8A1F1D8P112
DRIVER-COCKPIT EXTENSION
Stand: 06.10.2026

PATCHBASIS
- Frisch vom Nutzer nach P111 heruntergeladenes GitHub-main-Archiv: ATMS-PRO-main.zip
- GitHub-Source-Archive Commit aus ZIP-Metadaten: 7b958919cde397782c95ca8ba890ce77ee609eca
- Archiv-SHA-256: f91e4591c7632a19db649e604de99d6e2bdcda8c8b7244aaab1cce929b23f855
- In der Patchbasis verifiziert: android-native index.html = CORE-007D8A1F1D8P111
- In der Patchbasis verifiziert: android-native service-worker.js = P111 cache refresh
- In der Patchbasis verifiziert: android-native app.js enthaelt CORE-007D8A1F1D8P111.

ZIEL
Das produktive P111-Fahrer-Cockpit wird um genau drei echte Informationsbereiche erweitert: Tagesuebersicht, naechste Fahrt/ETA und letzte vorbereitete Nachricht. Keine Demo- oder Schaetzwerte.

AENDERUNGEN
1. Tagesuebersicht – ausgewaehlter Fahrer
   - Reale Fahrten des Tages aus dem vorhandenen Fahrtenbestand.
   - Puenktlich/Achtung/Verspaetet nur bei bestaetigter LIVE-Abholzeit-Bewertung.
   - Fahrten ohne belastbare LIVE-Abholzeit bleiben explizit unbewertet.

2. Naechste Fahrt / ETA
   - Naechste zeitlich bevorstehende offene Fahrerfahrt.
   - Route und DISPO/PLAN aus vorhandenen Daten.
   - ETA nur aus bereits vorhandenem liveEtaResults-Ergebnis.
   - LIVE-Abholzeit/Verspaetung nur nach bestehender fail-closed LIVE-Semantik.
   - Ohne Wert wird „–“ angezeigt.

3. Letzte Nachricht
   - Zeigt nur die neueste bereits lokal vorbereitete, nicht verworfene Dispo-Nachricht fuer den ausgewaehlten Fahrer.
   - Keine Nachricht wird erzeugt oder automatisch versendet.
   - Direkter Sprung in die bestehende Nachrichtenansicht.

NICHT GEÄNDERT
- P111 GPS/Schicht/Karte/Fahrtenkontrolle
- OCR / Golden Error Pack / P110
- Flugpruefung / FLIGHT-008
- PLAN-/DISPO-/LIVE-Zeitsemantik
- Tracking- oder Routinglogik
- Nachrichten-Persistenz oder Versandverhalten
- Fahrerzuordnung / Ersatzfahrerlogik
- Storage V2 / Backup / Archiv / Persistenz
- Keine neue API, Registrierung oder laufende Kosten

REALGERAET-ABNAHME
Nach erfolgreichem Build Live-Dispo oeffnen. Erwartung:
- unter dem bestehenden Zielbild erscheinen Tagesuebersicht, Naechste Fahrt / ETA und Letzte Nachricht;
- reale Fahrer-/Fahrtdaten werden angezeigt;
- ohne LIVE/ETA bleiben Werte neutral „–“;
- keine erfundenen Verspaetungs- oder ETA-Werte;
- bestehendes P111-Cockpit bleibt funktional.
