ATMS PRO · P106.1 · NATIVE FILE PICKER REGRESSION FIX · 02.10.2026

Basis:
- aktueller GitHub-main nach P106 / Native Build #162
- P106 OCR-/Fahrerfarben-/Mehrbildlogik bleibt unverändert

Realgeraet-Fehler nach P106:
- Tippen auf „Bild(er) oder Planliste auswählen“ öffnet den Android-Dateipicker.
- Nach Auswahl einer Datei wird die Auswahl nicht an die WebView zurückgegeben.
- UI bleibt auf „Noch keine Planliste ausgewählt.“
- Fehler tritt auch bei nur EINER Datei auf.

Fix:
- Android SAF-Dateipicker wird in MainActivity explizit über ACTION_OPEN_DOCUMENT aufgebaut.
- EXTRA_ALLOW_MULTIPLE wird nur bei <input multiple> aktiviert.
- akzeptierte MIME-Typen werden aus WebChromeClient.FileChooserParams übernommen.
- Rueckgabe verarbeitet sowohl ClipData (Mehrfachauswahl) als auch data-URI (Einzelauswahl).
- WebChromeClient.FileChooserParams.parseResult bleibt als sichere Fallback-Auswertung erhalten.
- doppelte URIs werden nicht mehrfach an die WebView übergeben.

Nicht geändert:
- P106 OCR-/Fahrername-/Fahrerfarbenlogik
- Mehrbild-Zusammenführung nach erfolgreicher Dateiauswahl
- P105 Archiv-Restore
- Storage V2 / Backup / P103
- Flugprüfung, Routing, Preise und Dedupe

Verbindlicher Realtest:
A) eine Bilddatei auswählen
   Erwartung: „Ausgewählt: <Dateiname> …“ und Analyse-Button aktiv.
B) danach zwei Bildteile gemeinsam auswählen
   Erwartung: „Ausgewählt: 2 Bildteile …“.
C) erst danach P106 OCR-Referenztest ausführen.
