ATMS PRO · P106 · OCR DRIVER/COLOR + MULTI-IMAGE FIX · 02.10.2026

Basis:
- aktueller Native-main nach P105 (SAFE ARCHIVE RESTORE)
- keine Änderung an Flugprüfung, Routing, Preisen, P103/P105, Storage V2 oder Persistenzregeln

Enthalten:
1) Fahrername / OCR-Konsens
- deutsche Fahrer-Spalten-OCR darf bei starkem Mehrfach-Konsens genau EIN im Primär-OCR ausgelassenes Zeichen ergänzen
- kein Namenswörterbuch, kein Fahrer-Hardcode
- Beispielklasse des belegten Realtests: Selm -> Selim

2) Fahrerfarben
- aktuelle, direkt aus der Fahrer-/Wg-Zelle erkannte Planfarbe ersetzt veraltete automatische Planfarbe desselben Fahrers
- alte Planfarben anderer Fahrer blockieren die aktuelle Farbe nicht mehr
- manuell gesperrte P74-Farben bleiben unangetastet
- fehlende/schwache Fahrerzellfarbe wird als OCR-Hinweis markiert
- derselbe Fahrer mit deutlich widersprüchlichen Zellfarben in derselben Planliste wird als OCR-Hinweis markiert

3) Mehrteilige Bild-/WhatsApp-Planlisten
- Datei-Auswahl erlaubt mehrere Bilder
- mehrere Bildteile werden in Auswahlreihenfolge zu EINEM OCR-Bild verbunden
- damit kann Teil 1 die vollständige Kopfzeile liefern und Teil 2+ als Fortsetzung ohne eigene Kopfzeile gelesen werden
- Excel/CSV/JSON bleiben Einzelauswahl

Verbindlicher Realtest nach Installation:
A) 8-Fahrten-Referenzbild:
- Selim statt Selm
- Dennis Türkis aus der Fahrerzelle
- Ali Violett, Rida Korallrot/Orange-Rot, Sabrina Pink/Magenta, Selim Gelb

B) Zwei Bildteile gemeinsam auswählen:
- Kopfzeilenbild mit 8 Fahrten + Fortsetzungsbild mit 2 Fahrten
- Erwartung: 10 Fahrten, 7 Fahrer, 8 eindeutige Flüge
- Fortsetzung muss XC333 und XC334 mit Fahrer Daniel enthalten
- Daniel-Farbe: Hellgrün/Limegrün

Fail-closed bleibt erhalten:
- unsichere OCR-Zellen werden nicht erfunden
- keine automatische Flugverifikation wird gelockert
