ATMS PRO · CORE-007D8A1F1D8P1078 · IMPORT STATUS CLARITY
Basis: GitHub main HEAD 5f6dceb88e0de866a2e4a9f50c5301d5f9b099c8 (P1077)
Datum: 05.10.2026

Zweck:
- Keine Änderung an Flugprüfung oder OCR-Entscheidungslogik.
- Vorschautabelle benennt die letzte Spalte als „Zeilenprüfung“ statt allgemein „Status“.
- Ungelöste zeilenbezogene Warnungen erscheinen als „Hinweis“ statt „Prüfen“.
- Der Bereich „Flugprüfung offen“ erklärt ausdrücklich, dass die Zeilenprüfung kein Flugstatus ist.
- Beim Bildimport wird die semantische Fahrer-Spalte in der Mapping-Anzeige als „Name (Fahrer)“ angezeigt, auch wenn der OCR-Header der letzten Spalte fälschlich als „Wg“ gelesen wurde.

Unverändert:
OCR-Werte, Mapping-Indizes, Flugverifikation/FLIGHT-008, PLAN, DISPO, LIVE, Preise, Fahrer/Fahrzeug-Daten und Persistenz.
