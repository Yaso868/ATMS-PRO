ATMS PRO CORE-007D8A1F1D8P11415 – HEADERLESS CLOCK-BOUNDARY PREFLIGHT INTEGRITY
08.10.2026 · GOLDEN ERROR 62 · ROOT CAUSE FIRST

Installation: Diese EINE ZIP-Datei über die GitHub-Repository-Oberfläche
https://github.com/Yaso868/ATMS-PRO unter Branch main, ROOT Breadcrumb
ATMS-PRO /, über Add file -> Upload files hochladen.
Vorher bestätigen, dass die zuletzt installierte Codebasis mindestens
P114.14 enthält; bei unbekanntem neuerem HEAD bitte Upload abbrechen.
Nach grünem GitHub Native APK + Patch Installer Build das dort erzeugte
Debug-APK-Artefakt installieren, ohne App-Daten zu löschen.

Reale Quelle: IMG-20261008-WA0014.jpg, 17 sichtbare Fahrten ohne Kopfzeile.
P114.14 belegte 16 angeblich ungültige Kernfelder vor Flug-Gate; Zeile 1
mit time='| 13:50' ist durch die bisher zu strenge headerlessTimeLike
fälschlich ungueltig. Die normalisierte, eindeutige Uhrzeit ist 13:50.

Patch:
- Headerless-Zeitanker und Kernfeld-Preflight akzeptieren AUSSCHLIESSLICH
  eindeutige Uhrzeit-Tokens mit den bereits vom unveränderten
  clockBoundaryNoiseInfo geprüften Tabellenlinien am Zellenrand.
- Derselbe Parser verlangt verankerten vollstaendigen Token und echte
  Stunden/Minutenwerte. Preise, Zusatztext, mehrere Uhrzeiten oder
  fragliche Randzeichen bleiben weiterhin ungueltig.
- Keine Daten werden auf Verdacht ergänzt, keine Uhrzeit gerundet,
  kein Flugort geraten. Globale Grenze >12 ungültige Pflichtfelder,
  per-Zeile >4, Flugspaltenkonflikt und Import-Fail-Closed bleiben erhalten.
- P114.11 Get-E, P114.12 Zeitbelege, P114.13 Flug-Gate-Trace und P114.14
  Early-Return Diagnose bleiben unverändert. Neue Asset-Version P11415.
- Die 15 anderen bei P114.14 angezeigten Fehler waren nicht mit
  vollständiger Einzelprovenienz belegt: Diese Patchprüfung garantiert
  NICHT, dass die reale Planliste jetzt importiert werden kann.

Tests:
- 33/33 Produktionsfunktionsfälle: sichere und unsichere Randzeiten,
  17-Zeilen-Kontrolle, echte fehlende Felder und Flugspaltenkonflikte.
- Alle 23 in Gradle preBuild eingehängten Node-Selbsttests grün.
- Golden Regression Pack unverändert 62 Fälle; kein pauschaler Realdurchlauf.
- SHA256.txt enthält Prüfsummen aller 7 Paket-Nutzdateien.

Signierter APK-Build: ausschließlich über GitHub Actions, lokal nicht ausgeführt.
Kein automatischer Fahrtenimport; Realgerät-Erfolgstest ist noch offen.
