ATMS PRO · P106.4 · Routen-Konsens-Fix
======================================

Ausgangsbasis
-------------
Frisch heruntergeladener GitHub-main-Stand vom 03.10.2026 nach P106.3.
Geaendert wird ausschließlich:
android-native/app/src/main/assets/js/plan-import.js

Problem / Beweisfall
--------------------
Planliste 03.10.2026, 13 Fahrten:
Zeile 2 / 06:50 wurde im Original als Ziel "DUS Airport" gezeigt, die OCR lieferte
jedoch "DUSAirpot". Der bisherige P75I-Routenkonsens korrigierte nur sichere
3+-Token-Einzelzeichenfehler und ließ diesen zusammengerutschten 1-vs-2-Token-Fall
unbehandelt durch.

Loesung
-------
Kein Orts-Hardcode. P106.4 erweitert ausschließlich den generischen
Listenkonsens fuer Routenfelder:
- Der fehlerhafte Text muss in diesem Feld genau einmal vorkommen.
- Das Vergleichslabel muss identisch mindestens 3-mal wiederholt vorkommen.
- Die Tokenisierung muss sich unterscheiden.
- Die kompakten Zeichenketten muessen entweder exakt gleich sein (nur Trennerfehler)
  oder genau eine Einfuegung/Loeschung auseinanderliegen.
- Gleich lange 1-Zeichen-Substitutionen werden weiterhin NICHT automatisch korrigiert.
- Bestehender P75I-Konsens fuer 3+-Token-Routen bleibt erhalten.

Erwarteter Regressionstest
--------------------------
Dieselbe Planliste vom 03.10.2026 erneut analysieren.
Soll:
- 13/13 Fahrten
- 3 Fahrer
- 10 eindeutige Fluege
- 0 Fehler
- "DUSAirpot" -> "DUS Airport" automatisch korrigiert
- bestehend: "Marriott Seesten DUS" -> "Marriott Seestern DUS" weiterhin automatisch korrigiert
- damit insgesamt 2 automatische Routenkorrekturen sichtbar
- 5 Fahrerfarben-Hinweise duerfen unveraendert bleiben
- 9 offene Flugpruefungen duerfen unveraendert bleiben, da die Orte im Original leer sind

Lokale Sicherheitspruefungen
-----------------------------
- JavaScript-Syntax: node --check = OK
- P106.4 Konsenstests = OK
  * DUSAirpot -> DUS Airport bei 8 Vergleichszeilen
  * bestehende Marriott-Seesten-Korrektur bleibt aktiv
  * nur 2 Vergleichszeilen reichen fuer den neuen kompakten Pfad NICHT
  * gleich lange Substitution wird NICHT automatisch korrigiert
