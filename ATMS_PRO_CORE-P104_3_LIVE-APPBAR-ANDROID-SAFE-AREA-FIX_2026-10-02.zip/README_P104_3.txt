ATMS PRO · P104.3 · LIVE APPBAR ANDROID SAFE-AREA FIX
02.10.2026

Ziel
- Korrigiert ausschließlich die obere ATMS-PRO-Kopfleiste der Fahrer-Fahrtenkontrolle / Live-Dispo.
- Die Zeile mit „ATMS PRO“ erhält einen eigenen Android-Safe-Area-Abstand nach oben.
- Android-Uhr, Netz/WLAN und Akku sollen dadurch nicht mehr optisch mit der ATMS-PRO-Leiste überlagert sein.

Technik
- Bestehende Zielbild-Appbar bleibt unverändert in Funktion und Inhalt.
- Nur die Appbar-Paddings werden um max(30px, env(safe-area-inset-top)) erweitert.
- Mobile Kompaktregel berücksichtigt denselben Safe-Area-Abstand.
- Oberer Radius wird entfernt, damit die Appbar sauber an die Systemkante anschließt; untere Rundung bleibt erhalten.

Unverändert
- Live-Dispo-Berechnung, Tracking, Fahrer-Fahrtenkontrolle und Warnschwelle
- Nachrichten
- Archiv/READ-ONLY/SHA-Prüfung und P104.2-Back-Stack
- aktive Fahrten und Storage V2
- OCR, Import/Dedupe, PLAN/DISPO/LIVE-Datenlogik
- Persistenz

Prüfung vor Paketierung
- JavaScript-Syntax: node --check bestanden.
- Android-Build und Signatur werden wie üblich erst im GitHub Native APK + Patch Installer bewiesen.
