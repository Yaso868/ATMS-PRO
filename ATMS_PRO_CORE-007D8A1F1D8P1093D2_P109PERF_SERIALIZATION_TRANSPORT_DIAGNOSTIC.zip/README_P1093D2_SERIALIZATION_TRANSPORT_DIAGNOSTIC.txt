ATMS PRO · CORE-007D8A1F1D8P1093D2
P109PERF SERIALIZATION / TRANSPORT DIAGNOSTIC — DIAGNOSTIC ONLY
Date: 06.10.2026

PURPOSE
- Split the already-proven pre-recognize wait into concrete browser-side stages without changing OCR decisions.
- Answer one question only: are the recurring ~4 s / ~13 s waits spent in Canvas/Blob serialization, in main-thread transport to the Tesseract WebWorker, or after transport before Tesseract emits "recognizing text"?

BASE CONTENT
- Built from the exact P109.3 installed payload files whose source hashes match ATMS_PRO_CORE-007D8A1F1D8P1093_OCR_SHARED_WORKER_SESSION_PERFORMANCE.zip.
- P109.3 upload commit visible on GitHub: 82b8f60.
- Native workflow #181: SUCCESS, 52 s, 1 artifact; validate-install-build green.
- The final github-actions[bot] HEAD SHA created by #181 must still be visually verified before this diagnostic ZIP is uploaded. This README deliberately does not guess it.

DIAGNOSTIC-ONLY CHANGES
1. Keeps the complete P109.3 OCR path, shared ENG/DEU workers, crop geometry, scales, languages, PSM/setParameters behavior, ordering, consensus rules and import decisions unchanged.
2. Adds passive timing wrappers around the ACTUAL browser methods used while worker.recognize(canvas) is active:
   - HTMLCanvasElement.toBlob
   - HTMLCanvasElement.toDataURL
   - CanvasRenderingContext2D.getImageData
   - OffscreenCanvas.convertToBlob (when available)
   - Blob.arrayBuffer
   - FileReader.readAsArrayBuffer
   - FileReader.readAsDataURL
   - Worker.postMessage
3. IMPORTANT: no extra toBlob(), toDataURL(), getImageData(), arrayBuffer() or OCR call is executed for the probe. Existing native calls are only timestamped and forwarded unchanged.
4. cropCanvasRegion() only records non-enumerable timing metadata on the returned Canvas. Pixel dimensions, drawImage arguments, smoothing and returned object remain unchanged.
5. Adds a P109D2 diagnostic line beside P54Perf/P63Primary/P109Perf.

P109D2 FIELD MEANING
For each shared-worker recognize operation:
- crop= time spent creating/drawing that ATMS crop Canvas (0 for full-image primary)
- pre= existing time from worker.recognize() call until Tesseract logger first emits "recognizing text"
- ser= sum of ACTUAL observed serialization/image-read method durations
- serEnd= time from recognize-call start to the end of the last observed serialization stage
- postSer= remaining time from last serialization end until "recognizing text"
- tx= synchronous Worker.postMessage duration
- txEnd= time from recognize-call start to end of the last observed Worker.postMessage
- workerWait= remaining time from Worker.postMessage end until "recognizing text"
- events=[...] exact serialization/read stages with start + duration + payload bytes when available
- transport=[...] actual Worker.postMessage event timing/action

ROOT-CAUSE INTERPRETATION
- If ser itself is ~4 s / ~13 s, browser-side image serialization/read is the dominant stall.
- If ser is short but txEnd is late, the delay is before/around transport after serialization.
- If txEnd is early but workerWait is ~4 s / ~13 s, the stall is after data was handed to the Tesseract WebWorker and before recognition begins.
- If no expected serialization event appears, that is also evidence about the actual Tesseract v5 browser path and must be interpreted together with getImageData / postMessage timing.

FUNCTIONAL SAFETY — MUST REMAIN IDENTICAL
WA0023 gate:
- 29/29 rides
- 18 automatic corrections
- 0 hints
- 0 OCR errors
- ‘Avion -> Avion remains corrected via dual-local + same-plan edge consensus
- Schiitz -> Schütz remains corrected via DEU batch + local consensus
- times/prices/routes/drivers unchanged
- automatic import unchanged
- LH74 / EW522 / EW7 remain open exactly as before
- EW522 DUS-vs-CGN->BCN airport conflict remains fail-closed
- FLIGHT-008 unchanged
- PLAN/DISPO/LIVE, persistence, Storage V2, P103, dedupe and archive unchanged

REAL-DEVICE TEST
1. Install the P109.3D2 APK over the existing app.
2. Analyze IMG-20261005-WA0023.jpg once after a fresh app start.
3. Functional gate above must pass before timing is interpreted.
4. Copy only P54Perf, P63Primary, P109Perf and the new P109D2 block.
5. One diagnostic run is sufficient for the root-cause split; do not call P109.3D2 a performance fix.

LOCAL VALIDATION BEFORE PACKAGING
- node --check plan-import.js: PASS
- node --check service-worker.js: PASS
- android-native/tools/ocr-regression-selftest.js: PASS
- P109.2 text-cell edge-consensus regression self-test: PASS
- P109.3 source payload hash match verified before modification: PASS
