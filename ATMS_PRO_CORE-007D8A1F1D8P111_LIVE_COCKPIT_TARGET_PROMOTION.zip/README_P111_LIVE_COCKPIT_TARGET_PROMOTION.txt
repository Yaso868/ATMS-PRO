ATMS PRO · CORE-007D8A1F1D8P111
LIVE-COCKPIT TARGET PROMOTION
Stand: 06.10.2026

PATCHBASIS
- Frisch vom Nutzer nach P110 heruntergeladenes GitHub-main-Archiv: ATMS-PRO-main.zip
- Archiv-SHA-256: a3f70ea4f2607ceb065878d85fe9e89275ec7ee1b467ba59262f2a61574336b5
- In der Patchbasis verifiziert: index.html = CORE-007D8A1F1D8P110
- In der Patchbasis verifiziert: service-worker.js = P110 cache refresh
- In der Patchbasis verifiziert: plan-import.js = CORE-007D8A1F1D8P110
- GitHub-Source-Archive enthaelt keinen Commit-SHA. Ein HEAD-SHA wurde nicht aus dem Archiv geraten.

ZIEL
Die bestaetigte Zielbild-Demo der Fahrer-Fahrtenkontrolle wird zum normalen produktiven Live-Cockpit mit echten ATMS-Daten. Keine Beispielwerte duerfen in den Produktivmodus uebernommen oder erfunden werden.

AENDERUNGEN
1. Zielbild-Demo wird aus der normalen Live-Dispo entfernt
   - Demo-Schalter und Demo-Banner werden nicht mehr erzeugt/angezeigt.
   - Der Zielbild-Aufbau selbst bleibt als produktive UI bestehen.

2. Aktuelle Position / Karten-Vorschau
   - Nutzt weiterhin ausschliesslich die bereits vorhandene lokale GPS-Position der aktiven, freigegebenen Fahrerschicht.
   - Die Karten-Vorschau zeigt zusaetzlich reale Routenorte der naechsten offenen Fahrt dieses Fahrers.
   - Keine Reverse-Geocoding-API, keine neue Registrierung, keine Kosten und keine erfundenen Strassennamen.
   - Koordinaten, Positionsalter und gemessene GPS-Genauigkeit bleiben sichtbar.

3. GPS-Qualitaet im Fahrer-Info-Block
   - Aus der tatsaechlich gemessenen Genauigkeit abgeleitete Anzeige: Sehr gut / Gut / Ausreichend / Schwach.
   - Ohne GPS bleibt Bereit / GPS wartet / Nicht aktiv wie fachlich vorhanden.

4. Fahrer-ID
   - Fehlt eine echte Fahrer-ID im gespeicherten Fahrerprofil, wird ehrlich „–“ angezeigt.
   - Der Fahrzeugwert wird nicht mehr faelschlich als Fahrer-ID-Ersatz dargestellt.

5. Fahrten / Prognose / Warnungen
   - Bestehende echte LIVE-/ETA-/Verspaetungsbewertung bleibt unveraendert.
   - Statusfarben und Warnkarte verwenden weiterhin nur vorhandene bestaetigte Daten.
   - Ohne belastbare LIVE-Daten bleibt die Anzeige neutral; keine Demo-/Schaetzwerte.

NICHT GEÄNDERT
- OCR / Golden Error Pack / P110
- FLIGHT-008 und Flugpruefung
- PLAN-/DISPO-/LIVE-Zeitsemantik
- GPS-Freigabe und Schichtsteuerung
- Fahrerzuordnung / Ersatzfahrer-Logik
- Routing-Entscheidungslogik
- Nachrichten
- Fahrten / Dedupe / Bundles
- Storage V2 / Backup / Archiv / Persistenz

LOKALE PRUEFUNGEN
- node --check app.js: PASS
- node --check service-worker.js: PASS
- P109.2 Text Cell Integrity Regression Self-Test: PASS
- P110 Golden Error Pack deterministic Regression Self-Test: PASS
- Patch enthaelt nur app.js, index.html, service-worker.js plus README/SHA256.

REALGERAET-ABNAHME
Nach erfolgreichem GitHub-Build Live-Dispo oeffnen. Erwartung:
- kein „Zielbild-Demo“-Button mehr,
- reale Fahrer-/Schicht-/GPS-Daten im Zielbild,
- bei aktiver GPS-Schicht Karten-Vorschau mit realen Routenorten der naechsten offenen Fahrt,
- GPS-Qualitaet aus realer Genauigkeit,
- ohne echte LIVE-Daten keine erfundene Prognose oder Warnung.
