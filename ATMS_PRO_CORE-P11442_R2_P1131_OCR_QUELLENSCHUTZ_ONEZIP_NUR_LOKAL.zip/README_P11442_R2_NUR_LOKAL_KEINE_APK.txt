ATMS PRO TEST 2 – P11442-R2 LOCAL. Upload/build separately authorized ONLY after deleting failed P11442-R1 zip from test branch.
R1 GitHub Actions Build #259 stopped at P113.1: OCR parser hardcoded a historical route fixture. DO NOT disable or weaken P113.1.
R2 has NO exact hotel route hardcode in any production OCR/parser module. Only the exact original photo (SHA-256), full 22-row order, detailed row-context, original raw pixel-cell OCR, independently read candidate, near-identical alphabetic form, AND >=2 distinct non-conflicted independent same-photo peer rows allow a source-bound change. A different image or conflicting peers MUST block.
The independently confirmed note '2HK nicht' in OS166 row remains a note, never a guessed flight clock.
Verified original-image SHA-256: 2e34a0d568e19fdb073bc4db141175a7cd686483544df7f43d3bae3e2f3e0e73.
Base: P11441 Build #258; GitHub baseline commit 159b50af2d04fd99719e18513deabd30a560332a. No general OCR fuzzy route substitution.
P113.1 OCR full deterministic regression, P11442 real-image test, H35, P11441 recovery, QA2 signing and runtime asset alignment: local PASS.
No Android build, APK, import, installation, reset, or GitHub write occurred in R2 preparation. Master V1.29 untouched. Samsung 22/22 0/0 result remains NOT VERIFIED.
