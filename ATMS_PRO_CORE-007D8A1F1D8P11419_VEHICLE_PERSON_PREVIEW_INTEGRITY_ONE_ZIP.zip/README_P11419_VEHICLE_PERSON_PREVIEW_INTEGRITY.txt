ATMS PRO · P114.19 · PREVIEW VEHICLE + PERSONS / SOURCE-ROW DUPLICATE WARNING
09.10.2026 · EIN ZIP - GitHub Root - kein Entpacken oder direktes Dateien-Hochladen.

Source: vom Nutzer direkt bereitgestelltes /mnt/data/ATMS-PRO-main.zip vom 09.10.2026.
Source archive SHA-256: 6990dca03ed8b50be1e872cc2826670a361ae290705a3ab164eb2a1529c60827
Vorheriger Stand: CORE-007D8A1F1D8P11418; neun relevante P114.18-Patch-Dateien byteidentisch zum gelieferten Main-Archiv.
GitHub main vollständiger HEAD-SHA derzeit nicht unabhängig abrufbar; vor dem Commit im Repo die Branch-Situation sichtbar prüfen.

ÄNDERUNGEN
1. Import-Ergebnistabelle zeigt weiter Typ=Fahrtart und NEU Fahrzeug=Pkw/Van sowie Personen=Pers an.
2. Dubletten-HINWEIS-Fingerprint berücksichtigt Datum, Fahrzeug und Personenzahl; keine Datenlöschung.
3. Zwei original getrennte Source-Zeilen mit gleicher Uhrzeit/Fahrer/Route, aber Pkw/1 und Van/7, erscheinen getrennt und ohne falsche Dublettenwarnung.
4. Android-Tabelle horizontal scrollbar; Asset-Bootstrap, Service-Worker-Cache und neue Runtime-Gates synchronisiert.
5. Golden Pack 72 => 73, erste 72 Fälle unverändert. Neuer Fall 73 für zwei Ghasem-Quellfahrten.
6. GE-67 (Reimport / Fahrerwechsel) bleibt OFFEN: mergePlanImportByIdentity und app.js UNVERÄNDERT.
7. Bestehende P114.18 OCR-/Datum-/FLIGHT-008-/Storage-Gates bleiben erhalten.

TESTS
26/26 für preBuild registrierte Node-Selbsttests lokal bestanden, einschließlich 13/13 P114.18 Datums-/OCR-Gates, Runtime Asset Alignment P114.19 und tatsächlichem Preview-HTML-Mapping auf zwei synthetische Zeilen. Golden-Fall-Objekte 1–72 deep-equal unverändert.
Nicht ausgeführt: vollständiger Bild-OCR-Golden-Replay auf 73 Bildfixtures, Gradle/Android-APK-Build und Samsung-Realgerät-Test. Das ZIP ist vor CI ein geprüfter Kandidat.

INSTALLER
Einzig diese ZIP im GitHub-Repo-ROOT auf main hochladen. Workflow validiert Pfade und SHA256.txt, installiert android-native/ und startet Gradle assembleDebug. Danach APK und Quelle auf Realgerät prüfen. Vor Erfolgsbeleg keine produktive Fahrt importieren.
