ATMS PRO P11437 – gezielter OCR-Sprachdaten-404-Fix, Testbranch-Only.

Nur die 8 deklarierten Quelldateien installieren, nachdem GitHub Actions
SOURCE_VERSION=P11436, TARGET_VERSION=P11437, Branch-Baseline, SHA256-Schutz und
alle WATCH_SHA256-Quellen erfolgreich geprüft hat.

Runtime-Semantik: Tesseract bekommt gzip:false. Die Android-APK enthaelt
eng.traineddata / deu.traineddata, nicht .traineddata.gz. Die alten beiden
komprimierten Originalquellen werden NICHT veraendert.

Sicherheitskontrollen:
- Neue verpflichtende preBuild OCR-Options- und Runtime-Gates.
- Nach assembleDebug wird tatsaechliche APK auf Pfade, Byteinhalt und Loader
  geprueft. Fehlt etwas, muss der GitHub-Workflow FAIL setzen.
- Neue Paketversion P11437, versionCode 14, isolate package de.atmspro.app.qa.
- Historische Fehlerkorrekturen, Tagesansicht, 15 branch-only Tests erhalten.

NICHT: Produktiv-main; Samsung-Installation/Import/Reset; Vollabnahme 73 Golden.
