ATMS PRO P114.20 – FAHRER-IDENTITÄT OCR FAIL-CLOSED
Datum: 09.10.2026 · lokaler Kandidat; Upload erst NACH frischer GitHub-main-HEAD-Verifikation.

Ein-ZIP-Patch. Nur Android-Runtime und zwei Testskripte enthalten.
Ausgangs-Runtime: P11419; Ziel: P11420.
Baseline BASE_COMMIT ist ein historisch verifizierter Vorfahren-Commit, KEINE heute frisch verifizierte HEAD-SHA.
Der gehärtete Installer muss vorher aktiv sein und prüft Original-SHA aller geänderten Dateien
sowie Golden 73, CSS und P114.18/P114.19-Testskripte. Bei Abweichung sicherer STOP.

Fix: Fahrerwerte mit OCR-verdächtigen Binnenzeichen oder konkurrierendem Zell-OCR-Beleg
werden nicht stillschweigend übernommen. Sichtbarer zeilengenauer Korrektur-Button.
Kein Fahrer-/Orts-/Flugnummern-Hardcode. Original-leere Fahrerzellen bleiben unassigned.
Keine Änderungen an gespeicherten Fahrten, automatische Importe nur bei null blockierenden Fehlern.
Golden Pack 73 unverändert; GE67 weiterhin offen.

STATUS: 27/27 lokale aktive Android Node/Gradle-Gates PASS, kein Github Build, kein Samsung-E2E.
Ohne aktuell frisch verifizierte komplette main HEAD + Quellbasis ist ZIP NICHT uploadfreigegeben.
