ATMS_PATCH_GUARD_V1
BASE_COMMIT=9667dd98d57b130ff4ca3488bd7ba5ecc73728db
SOURCE_VERSION=11427
TARGET_VERSION=11429
FILE_COUNT=14
BASE_SHA256 18c11933eb47ac294bfeb2b713fbca55c97df678a91ce1b2171f46a5f4b7eebd android-native/app/build.gradle
BASE_SHA256 6ed0a59cb6d06e959a4707b05e921fac7a686f0fda0575d3f2ba65619af97402 android-native/app/src/main/assets/index.html
BASE_SHA256 ABSENT android-native/app/src/main/assets/js/h13-review-only.js
BASE_SHA256 ABSENT android-native/app/src/main/assets/js/h15-ride-drafts.js
BASE_SHA256 ABSENT android-native/app/src/main/assets/js/h17-geometry-candidates.js
BASE_SHA256 ABSENT android-native/app/src/main/assets/js/h19-pixel-review.js
BASE_SHA256 ABSENT android-native/app/src/main/assets/js/h26-source-band-audit.js
BASE_SHA256 ABSENT android-native/app/src/main/assets/js/h27-source-cell-focus.js
BASE_SHA256 643d24d4bba7a866a7689b225c5e00e5b3158c228935aabdec520612462406e6 android-native/app/src/main/assets/js/plan-import.js
BASE_SHA256 c1708d40a911ca38ae56dfa0e431d97f3db4a84481be156fc71db4fda940f379 android-native/app/src/main/assets/js/pwa.js
BASE_SHA256 d2488964910bb5d4d3345592e45293ca584ee20a485bcb21efd1ba66a07ad1bf android-native/app/src/main/assets/service-worker.js
BASE_SHA256 ABSENT android-native/tools/atms-price-gate-p11429.cjs
BASE_SHA256 ABSENT android-native/tools/atms-price-interior-p11429.cjs
BASE_SHA256 ABSENT android-native/tools/runtime-asset-alignment-selftest-p11429.js
WATCH_SHA256 3a64d5b0a7250e3f8cb1bd62c0c61ef1780511b68284d344f5c9c25bdf9585e5 android-native/app/src/main/assets/js/flight-engine.js
WATCH_SHA256 9bc8644fa3733447e7feac7e518a8e0294c2c43093bdd3e5f5f1c20b7741e625 android-native/app/src/main/assets/js/ocr-integrity-core.js
WATCH_SHA256 b70a8b0a56297ffa8495692b7012aa4ed2a10ec7c68bd57f5e882b4e3f16bcc7 android-native/app/src/main/java/de/atmspro/app/MainActivity.java
WATCH_SHA256 b2d560aeee50af57f525d69b25ae0e3782ea43d742d81382a627b4262a0a86c9 android-native/tests/ap01_editor_quarantine.test.cjs
