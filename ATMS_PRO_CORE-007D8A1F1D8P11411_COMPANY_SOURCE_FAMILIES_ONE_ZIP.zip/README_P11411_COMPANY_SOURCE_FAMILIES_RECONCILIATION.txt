ATMS PRO CORE-007D8A1F1D8P11411 – QUALIFIED COMPANY SOURCE FAMILIES RECONCILIATION

Base: Last confirmed P114.10 code, diagnostic release; NOT asserted to equal live GitHub main until freshly verified.
Scope:
- Preserve sourceRow/sourceColumn/field in actual targeted OCR verificationAttempts instead of discarding them.
- Resolve only the single-internal-delimiter loss when original complete primary OCR (>=80 confidence),
  independent full-cell source views (>=2 modes), and bounded adaptive source views (>=2 modes)
  agree, with >=3 matching same-plan peers and no credible competing source evidence.
- A neighbor-ambiguous edge-expanded crop does not veto independent clean full-cell + adaptive evidence;
  a proven neighbor-safe expanded crop with an alternative continues to block.
- Semantically distinct candidates, low confidence, wrong row/column, incomplete or opposing source
  OCR and competing exact-cell views remain FAIL-CLOSED. No flight/price/time/route logic altered.
- Read-only P114.10 diagnostic continues to exist and remains informative.
- Approved Master Prompt V1.4 and P114.10 Golden Error documentation are included.

Evidence: Captured REAL Android P114.10 cell-attempt report as immutable test fixture;
production function replay through repeated-text consensus, post-consensus reconcile,
zero-silent-error gate and validate. This is not a claim that a new Android OCR run was
performed locally; final Android APK test remains required.

Build: one root ZIP, SHA256.txt for its contents; original GitHub installer checks all hashes,
merges android-native/ source, runs signed :app:assembleDebug, and removes uploaded ZIP.
No manual individual-file uploads. Do not import original 33-ride plan until confirmed error-free.
NOTE: A GitHub live HEAD equality check is still required before repository upload.
