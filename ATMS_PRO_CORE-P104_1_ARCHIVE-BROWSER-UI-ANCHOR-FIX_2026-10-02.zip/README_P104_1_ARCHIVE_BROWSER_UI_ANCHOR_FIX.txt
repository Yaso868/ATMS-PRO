ATMS PRO · P104.1 · ARCHIVE BROWSER READ-ONLY · UI-ANCHOR-FIX
Datum: 02.10.2026

Basis:
- frisch heruntergeladener GitHub-main nach P104
- ZIP-Archiv-Commit: eb832b8445dd6134b54199b65e353f8baf2d0d7a
- P104 READ-ONLY Integritätsprüfung bleibt unverändert

Fehlerbild auf Realgerät:
- „👁 Archiv ansehen · READ-ONLY“ liest/verifiziert die Datei erfolgreich.
- Status meldet „✓ Archivdatei verifiziert geöffnet · READ-ONLY“.
- Die eigentliche Fahrtliste war danach jedoch nicht sichtbar.

Korrektur P104.1:
- reine UI-Anker-/Darstellungsreparatur.
- Der verifizierte Archiv-Viewer wird jetzt als robuste Unteransicht direkt in
  „Backup & Wiederherstellen“ / settingsBackupBody gerendert.
- Die normale Backup-Seite wird während der READ-ONLY-Ansicht nur visuell
  ausgeblendet und beim Zurück-Pfeil wiederhergestellt.
- Falls der bekannte Host unerwartet fehlt, existiert ein expliziter Fixed-Fallback
  mit top/right/bottom/left und maximalem z-index.

Unverändert:
- native Archivdatei-Lesefunktion
- Datei-SHA-256- und Byteprüfung
- ATMS_ARCHIVE-/Payload-SHA-256-Prüfung
- Archivdatum / Fahrt- und Erledigt-Zähler
- P103 Bereinigung
- aktive Fahrten
- Storage V2
- Backup/Wiederherstellung
- OCR / Import / Dedupe / Bundles / Fluglogik
- keine Wiederherstellung, keine Löschung, keine Mutation von Archivdaten

Patchinhalt:
- android-native/app/src/main/assets/js/app.js
