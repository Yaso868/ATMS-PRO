ATMS PRO · P101 STORAGE V2 PHASE 2B · PERSISTENTER ARCHIVORDNER
Datum: 2026-10-02

Verifizierte Basis
- GitHub main wurde unmittelbar vor diesem Patch am Realgerät geprüft.
- Sichtbarer aktueller Installer-Commit: 4bfa197
  "Apply validated ATMS patch: ATMS_PRO_CORE-P100_ADDRESS-CANDIDATE-PC-ROUNDTRIP_2026-10-02"
- Anschließend frisch heruntergeladene Datei: ATMS-PRO-main.zip
- SHA256 der verwendeten main.zip: e95706c0015db8a532a599938ded9c0a63a8fa4a0fa09989abd262bd1f6f6d85
- Native app.js vor Patch: 8dcfd80307bbc584154b5586d96df9abf1c371f7bea1c12c11894844ed2b4b99
- Native MainActivity.java vor Patch: 0c3f15571d35c4ab23fc5caca2e3095cef4b55e58b10b618915d7a29110d0d83

Ziel Phase 2B
1. In Einstellungen > Backup & Wiederherstellen > Tagesarchiv kann einmal ein Android-Archivordner gewählt werden.
2. Android nutzt ACTION_OPEN_DOCUMENT_TREE und übernimmt die Lese-/Schreibberechtigung dauerhaft via takePersistableUriPermission.
3. Der gewählte Tree-URI wird ausschließlich nativ in SharedPreferences gespeichert; keine absolute Dateipfad-Annahme.
4. Solange die persistente Berechtigung gültig ist, werden weitere .atmsarchive-Dateien direkt in diesem Ordner angelegt, ohne jedes Mal den Speichern-unter-Dialog zu öffnen.
5. Jede neue Archivdatei wird unmittelbar nativ wieder eingelesen und bytegenau mit dem geschriebenen Inhalt verglichen; zusätzlich wird SHA-256 zurückgegeben und in der bestehenden JS-Prüfung kontrolliert.
6. Existiert derselbe Dateiname bereits, wird NICHT überschrieben. ATMS erzeugt kollisionsfrei _2, _3 usw.
7. Schlägt Schreiben oder Read-Back fehl, wird die neu angelegte, nicht bestätigte Datei nach Möglichkeit wieder entfernt und das Archiv nicht als verifiziert registriert.
8. Die read-only Archivübersicht bleibt bestehen und zeigt bei Phase-2B-Archiven zusätzlich den tatsächlichen Dateinamen und den Archivordner.
9. Wenn noch kein Archivordner gewählt wurde, bleibt der bereits bestätigte Phase-2A-Speichern-unter-Dialog als Fallback erhalten.
10. Ist ein Ordner gespeichert, aber die dauerhafte Berechtigung später nicht mehr gültig, wird fail-closed blockiert und eine erneute Ordnerwahl verlangt; es gibt keinen stillen Fallback in einen anderen Speicherort.

Sicherheitsgrenzen
- KEINE automatische Löschung aktiver Fahrten.
- KEINE automatische Archivierung.
- KEINE automatische Wiederherstellung aus Archiv/IndexedDB/Shadow.
- localStorage bleibt Hauptspeicher / Source of Truth wie bisher.
- Storage V2 Phase 1 Spiegel/Abgleich bleibt unverändert.
- Storage V2 Phase 2A Archivformat ATMS_ARCHIVE v1 und SHA-256-Prüfung bleiben kompatibel.
- Keine Änderung an OCR, Planlistenimport, Dedupe, Bundles, Datumslogik, PLAN/DISPO/LIVE, FLIGHT-008, Adressbuch oder P100-Kandidaten-Roundtrip.
- "Nur aktuelle Planliste behalten" / Bereinigung ist ausdrücklich NICHT Bestandteil dieses Patches.

Geänderte Dateien
- android-native/app/src/main/java/de/atmspro/app/MainActivity.java
- android-native/app/src/main/assets/js/app.js

Lokale Vorprüfung
- node --check app.js: bestanden.
- Java-Quellsyntax grob mit javac-Parserlauf geprüft: keine Syntaxfehler-Marker; erwartete Fehler entstehen lokal nur wegen fehlender Android-SDK-Klassen.
- Klammerbilanz MainActivity.java: ausgeglichen.
- Patch-Diff geprüft: ausschließlich Phase-2B-Archivordner/Bridge/UI und P101-Kopfkommentar.
- Vollständiger Android-Build muss wie vorgesehen durch den GitHub Native APK + Patch Installer erfolgen; erst dessen grüner Lauf gilt als Build-Beweis.

Minimaler Realgerät-Test nach erfolgreichem Build
A. Backup & Wiederherstellen öffnen -> Tagesarchiv zeigt "Storage V2 Phase 2B" und "Archivordner wählen".
B. Einen neuen Ordner auswählen/bestätigen -> Status muss dauerhafte Lese-/Schreibfreigabe bestätigen.
C. App einmal schließen/öffnen -> derselbe Ordner muss weiterhin als freigegeben angezeigt werden.
D. Genau EIN Tagesarchiv erstellen -> kein erneuter Speichern-unter-Dialog; Datei landet direkt im gewählten Ordner und Status meldet Verifizierung/Read-Back/SHA-256.
E. Aktiver Fahrtenbestand muss unverändert bleiben.
