ATMS PRO P11448 · guarded single ZIP for TEST 2 testbranch only
Source from P11447 successful Build #268, commit 12951601b5f6a2d1c3bd810310a7eb41049215fb.
Manual image-cell review is allowed only for company/destination, bound to source and session.
All other import, date, price, flight, driver, duplicate, persistence checks stay mandatory.
Original local P11448 fixtures passed: 35 positive/29 negative, offline browser.
All historical guards + P11448 regression must pass actual GitHub Gradle preBuild.
GitHub main / TEST1 / production app untouched. No Samsung install/import/reset/restore.
Only ZIP replaces previous single archive in testbranch; fail closed on any mismatch.
