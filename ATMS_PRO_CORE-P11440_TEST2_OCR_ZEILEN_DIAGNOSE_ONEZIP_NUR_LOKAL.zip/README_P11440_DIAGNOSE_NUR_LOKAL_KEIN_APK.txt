ATMS PRO TEST 2 / P11440 LOCAL READ-ONLY OCR DIAGNOSTIC
Date: 2026-10-22
Status: LOCAL SOURCE ZIP, NOT AN APK, NOT UPLOADED OR INSTALLED.
Base: P11439 GitHub #255 installer HEAD 8d15702ecf97165682af867561a36542fdf618d8.

Scope:
- Report EACH unresolved synthetic OCR matrix position with image Y-band coordinates.
- Preserve and render bounded OCR 1 / OCR 2 word differences for the SAME image.
- Show limited sampled OCR words even when neither view is complete.
- Do not claim that a matrix position equals a literal original sheet row.
- No data import, no changes to recognition acceptance, no automatic OCR correction.
- No change to existing images, drivers, hotels, times, prices, duplicates, flight rules or company mapping.
- Maintain H35 module hashes, signing identity QA2, OCR traineddata, fail-closed tests.
- Current versionCode 17 (P11440) and cache generation aligned.

Limitation: 22/22 Samsung OCR is NOT yet verified and the exact readback words of the user's two affected rows are NOT yet known. This patch improves diagnosis only.
No GitHub writes or Android device actions are included in this local authorization.
