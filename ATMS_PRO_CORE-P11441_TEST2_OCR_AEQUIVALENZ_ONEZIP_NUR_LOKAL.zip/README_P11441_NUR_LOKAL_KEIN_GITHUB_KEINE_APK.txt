ATMS PRO TEST 2 – P11441 LOCAL / NEVER UPLOADED WITHOUT APPROVAL
Master: V1.29 (UNCHANGED); Base: P11440 Build #256, test branch installer commit 080e44ada58917b331ccff1c075b80ed4f20d92a.
Image visual golden: 97633.jpg, exactly 22 physical rows, reference is NOT a successful OCR result.
The actual two blocked Samsung synthetic review positions were 4 and 8. Only the four proven same-cell differences are corrected:
  time 12:45 / | 12:45 -> 12:45
  price 35,00 € / 35,00€ -> 35,00 €
  company Get-E = / Get-E ~~ -> Get-E (no blanket stripping)
  empty opposite flight column ~ / - -> empty (never a flight)
P11441 preserves and renders raw multi-view OCR evidence and only outputs semantically canonical cell data.
Any material difference in time, amount, firm, flight number, flight direction, driver, vehicle, persons, route or unknown cell FAILS CLOSED.
No automatic import, no duplicates/merges, no row-reordering; 13:15 EW9883 dispatch vs 14:10 flight separate.
Original P11440 diagnostic, H35 historical source guards, QA2 signing and OCR traineddata protections retained.
Full real Samsung OCR is NOT proved 22/22 by a local mock; a signed APK build and mobile test require separate approvals.
No GitHub operations, APK builds, installations, data resets or imports performed in this local test phase.
