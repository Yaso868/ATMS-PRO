ATMS PRO – Storage V2 Phase 1 + App-Icon
Datum: 01.10.2026
Basis: GitHub main / P95 Gesamtpatch Build #139 (Commit 88ff8b1, Realgerät bestätigt)

ÄNDERUNGEN
1. Storage V2 Phase 1 – Sicherheitsmodus
   - localStorage bleibt unverändert Source of Truth.
   - Fahrten und Erledigt-Status werden zusätzlich in einer getrennten IndexedDB gespiegelt.
   - Nach jedem regulär bestätigten Speichervorgang erfolgt Write/Read-Verifikation.
   - In „Backup & Wiederherstellen“ erscheint eine sichtbare Storage-V2-Statuskarte.
   - Bei Abweichung/Fehler: nur Warnung; keine automatische Reparatur.
   - Keine automatische Löschung.
   - Keine Archivierung.
   - Keine Umschaltung auf Storage V2 als Hauptspeicher.
   - Bestehender Durable-Shadow bleibt unverändert bestehen.

2. Neues ATMS-PRO-App-Icon
   - Dunkelblau-goldenes Launcher-Icon.
   - Manifest setzt icon + roundIcon auf die neue Drawable-Ressource.

SICHERHEIT
- Vor diesem Patch wurde auf dem Realgerät ein frisches ATMS-Backup erstellt:
  01.10.2026 09:58 · 140 gespeicherte Fahrten.
- Storage V2 Phase 1 löscht keine aktiven Nutzdaten.
- Der GitHub-Patch-Installer prüft SHA256 und baut die signierte Debug-APK vor dem automatischen Commit.

ENTHALTENE DATEIEN
- android-native/app/src/main/assets/js/app.js
- android-native/app/src/main/AndroidManifest.xml
- android-native/app/src/main/res/drawable/ic_atms_pro_launcher.xml
