ATMS PRO P11446 – SCALE-TRUE PHYSICAL SOURCE-ROW FENCE
23 Oct 2026, test branch atms-price-p11429-test-only ONLY.
SOURCE P11445, TARGET P11446. Main, TEST1, production and Samsung storage untouched.
This is a corrective continuation of P11445 after its genuine Samsung OCR failed
with p11445_physical_source_row_unproven at positions 5 Y346-395 and 10 Y669-719.
Root cause: 1536x605 source image is OCR-preprocessed at about 3200x1260,
so a fixed 27-35px physical pitch in the previous test was wrong.
P11446 derives pitch from actual neutral source rules and genuine across-row
colour transitions; it never infers missing prices or ride identities.
Two independent image OCR transformations are NOT two independent sources.
All former fail-closed/source-cells, historical checks and actual QA2 stable signing
continue to gate the build. 44/44 full project preBuild tasks PASS in local
source tree; new 10 positive/7 negative synthetic-scaled tests PASS; genuine
23 Oct scaled pixel geometry 5/5 local checks PASS without shipping user pixels.
Complete successful runtime Samsung recognition of 18 rides remains pending.
Only GitHub Actions signed TEST2 update allowed after guarded ZIP import.
