ATMS PRO · P107.7 · Standard Flight Conflict Evidence
Datum: 05.10.2026
Basis: CORE-007D8A1F1D8P1076 (vom Nutzer gelieferter, verifizierter GitHub-main ZIP-Stand)

Ziel
- Verhindert falsche harte OCR-Blocker, wenn eine lokale Gegenprüfung nur unklar ist.
- Prüft zugleich eindeutige, aus zuvor leerer Flugzelle wiederhergestellte EINZEL-Flugnummern mit engen Zell-Crops nach.
- Wiederholte bereits wiederhergestellte Flugnummern bleiben im schnellen P107.6-Pfad, außer ein echter Same-Context-Ein-Ziffer-Konflikt liegt vor.

Regeln
1. Inkonklusive Re-OCR allein erzeugt KEINEN neuen harten OCR-Fehler.
2. Ein harter Konflikt braucht positive Ein-Ziffer-Gegenevidenz aus mindestens zwei unabhängigen Crops.
3. Ein starker Zwei-Crop-Sieger darf weiterhin generisch automatisch korrigieren.
4. Keine Airline-, Flugnummer-, Fahrer-, Orts- oder Datums-Hardcodes in Produktionscode.
5. Historische konkrete Flugnummern existieren ausschließlich im Golden-Regressions-Test.

Erwarteter Regressionseffekt für den bekannten 29-Fahrten-Test vom 04.10.2026
- korrekte schwache Standard-Flugnummern sollen nicht allein wegen unklarer Bestätigungs-OCR blockieren;
- einstellige echte OCR-Abweichungen sollen bei klarer Zwei-Crop-Evidenz weiterhin automatisch konvergieren oder bei echtem Konflikt blockieren;
- P107.6-Performance-Schutz für wiederholte missing-flight-Recoveries bleibt erhalten.

Test-Gate
- android-native/tools/ocr-regression-selftest.js erweitert.
- Node-Selbsttest auf der P107.6-Basis mit P107.7-Dateien: PASS.
- JavaScript-Syntaxprüfung für plan-import.js und ocr-integrity-core.js: PASS.
- assembleDebug in GitHub Actions führt den Regressionstest über preBuild automatisch aus.
