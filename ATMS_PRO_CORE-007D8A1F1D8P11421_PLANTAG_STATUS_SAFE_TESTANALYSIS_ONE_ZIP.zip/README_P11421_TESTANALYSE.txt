ATMS PRO P114.21 – PLANTAG STATUS + SICHERE TESTANALYSE
09.10.2026 · LOKAL GETESTETER KANDIDAT (GitHub main HEAD live weiterhin nicht unabhaengig auslesbar)

Benutzerfehler: nach manueller Wahl 09.10.2026 zeigte die ausgewaehlte WhatsApp-Datei
unten weiterhin den Dateinamensplantag 08.10.2026 an.
Fix: Dateistatus liest immer den tatsaechlich aktiven Plantag.

Sicherheit: Neuer expliziter Button 'Nur Testanalyse – garantiert ohne Fahrtenimport'.
Testmodus blockiert Morgen-Modus-Auto-Import im Entscheidungsweg, deaktiviert die
manuelle Import-Schaltflaeche und verweigert jeden persistierenden Import im
backend importRides() vor applyImportedRides(). Die normale Analyse bleibt unveraendert
fuer den produktiven Tagesbetrieb. Keine Fahrtdaten werden beim Test gespeichert.
P114.20 Fahrer-OCR-Schutz und Golden Pack 73 unveraendert, GE67 weiterhin offen.

ZIP mit source-SHA, manifest-SHA und historischem BASE_COMMIT (nur Vorfahre).
Der gehoertete GitHub-Installer muss Source-Version P11420 sowie ALLE
pre-image und watch checks exakt bestaetigen; bei Abweichung STOPP vor Ueberschreiben.
Vor einem GitHub-Upload live HEAD/Parent und Quellstand unabhaengig verifizieren.
Bis dahin NICHT hochladen und KEINE Fahrten importieren.

Lokal: aktive Android Node-Tests 28/28 PASS; kein GitHub-Actions/Android-Build/Realgeraet-Test.
