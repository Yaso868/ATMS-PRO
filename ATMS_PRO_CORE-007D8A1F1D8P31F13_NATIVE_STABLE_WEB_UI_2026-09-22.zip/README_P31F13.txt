CORE-007D8A1F1D8P31F13 – Native Stable Web UI Integration

Basis:
- bestätigter P31F12F1 Native-DUS-Transport (22.09.2026): echtes DUS JSON, 20 Flüge
- bestätigte Stable-Weboberfläche P35F1
- P34F5 OCR/DISPO-Zeit bleibt unverändert

Änderung:
- Native MainActivity lädt jetzt file:///android_asset/index.html statt bridge-check.html.
- Die bestätigte Stable-Weboberfläche wird als lokale Android-Assets mitgeführt.
- Native DUS Bridge bleibt unter ATMS-FLIGHT-NATIVE-1 verfügbar.
- versionCode 2 / versionName 1.4.0-p31f13.

Nicht geändert:
- PLAN/DISPO/LIVE-Semantik
- P35F1 Settings/About
- P34F5 OCR-Fix
- P33F1 Clean Start
- P32 Ride Merge
- P31 Flugverifikationsregeln

Gezielter Endtest nach Build/Installation:
1. Native App öffnet die normale ATMS-PRO-Oberfläche.
2. Kein erneuter isolierter DUS-Bridge-Grundtest; DUS-Transport ist bereits bestätigt.
