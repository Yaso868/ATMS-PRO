ATMS PRO P114.26 – NUR GitHub CI-PATCH-KANDIDAT, NICHT INSTALLIERBARE APK

Quelle: vom Nutzer am 12.10.2026 bereitgestellte ATMS-PRO-main.zip.
Git-Commit-SHA aus dem ZIP-Kommentar: 7e7395a8640a62fd6fe27eb29b0ba051df109bbd.
Source P114.24 → Target P114.26. Strikter SHA-256-basierter Installer-Guard.

Enthaltene Verbesserungen:
- nur echte Zeichen-Normalisierungen für Flugnummern protokollieren
- ? bei Flugzeit als Unsicherheit erhalten und sichtbar warnen
- Preis ohne Dezimaltrennzeichen nicht als hundertfachen Preis übernehmen
- Rohpreis-OCR/Geometrie für spätere Beweisdiagnose speichern
- streng begrenzter Marriott-Boundary-Schutz bei einem identischen Quellen-Peer
- gleicher Offline-PWA-Cache, neuer P11426 Cache-Stand + verpflichtende Selbsttests

Bewusst NICHT gelöst: Get-E vs GetE und EWO588 vs EW9588 bleiben FAIL-CLOSED.
Keine automatische Korrektur ohne ausreichende Originalzellenbeweise.
Kein Produktivimport, keine Datenbereinigung, Storage V2 unverändert.

BELEGE VOR UPLOAD (lokal): P11426 accuracy 24/24, alle 32 Gradle preBuild-Node-Gates PASS,
53 historische Tests original P11424 32 PASS, stage P11426 31 PASS;
1 erwarteter P11424-Asset-Versionstest kann in P11426 naturgemaess nicht bestehen.
P11426-Ersatztest besteht. Kein unerwarteter funktionaler PASS->FAIL.
CI/Gradle, Android-Signatur, APK-Gerätetest und echtes 15-Fahrten-Bild-OCR noch NICHT bestanden.

GitHub-Workflow baut erst nach SHA/Commit-/Quellversion-/Watch-Prüfung die APK.
Dieser ZIP ist ein CI-Validierungskandidat; als Produktivstand erst bei GitHub Actions SUCCESS
und anschließendem kontrolliertem Samsung-Test verwenden.
