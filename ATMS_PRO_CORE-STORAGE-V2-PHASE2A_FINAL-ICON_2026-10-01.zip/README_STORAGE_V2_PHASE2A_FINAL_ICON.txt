ATMS PRO · Storage V2 Phase 2A + final launcher icon · corrective package
Date: 2026-10-01
Verified GitHub main HEAD before this patch: b39a1a7 (parent 73b2c14).

Purpose
- Preserve the non-destructive Storage V2 Phase 2A implementation.
- Deliver only the user-approved final launcher artwork from
  ICON_FINAL_BESTAETIGT/ATMS_PRO_APP_ICON_FINAL.png.
- Correct Build #141, which still displayed the previous launcher icon on the real device.

Icon hardening
- Final approved bitmap is packaged under a fresh Android resource identity:
  @drawable/ic_atms_pro_launcher_v2
- AndroidManifest.xml points both android:icon and android:roundIcon to that fresh resource.
- APK versionCode is bumped from 3 to 4 (versionName 1.4.0-p31f14) so Android/Gradle cannot reuse
  the previous package/resource result as the same application build.
- The source bitmap bytes are unchanged from the approved icon.

Storage safety remains unchanged
- localStorage remains primary storage.
- Archive creation is manual only.
- Write -> read-back -> byte/SHA-256 verification before catalog registration.
- No automatic deletion.
- No automatic archive.
- No primary-storage switch.
