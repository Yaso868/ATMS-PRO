ATMS PRO P114.19 – STAGED ROLLBACK REPAIR (09.10.2026)

ONLY five byte-exact P114.19 Android production files are restored.

DO NOT UPLOAD THIS PATCH TO GITHUB UNTIL THE SEPARATE GUARDED WORKFLOW HAS
BEEN INSTALLED, COMMITTED AND CONFIRMED ON main.
THE OLD WORKFLOW IGNORES README_PATCH_BASELINE.txt AND IS UNSAFE.

Target baseline: 611e0a883d74006f0b0639779298a2350fad6871
The new workflow requires BASE_COMMIT ancestry and exact SHA256 preconditions
for every modified file plus five protected watch-only source files.
Current app marker must be P114.17 and target must be P114.19.
The upload commit must change ONLY this patch ZIP.

Do not install any APK or import/clean trips until separate real-device approval.
Golden Pack 73 and all existing P114.18/P114.19 scripts are preserved.
GE67 and the KölnBus OCR defect are NOT repaired by this rollback recovery.
