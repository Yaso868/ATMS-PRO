ATMS PRO TEST 2 – P11443 SOURCE-BOUND COMPANY CELL PATCH – LOCAL ONLY.
Source: verified P11442-R2 Build #260, baseline GitHub testbranch 7e9e84b94cba6bb86ab498423570d745b3fac3fc.
User-approved local scope ONLY. No GitHub write, build, APK installation, reset, data import.
P11443 resolves one proven original-photo company OCR disagreement on source row 17:
15:45 DUS Airport -> original route from other exact image peers, EW9903 arrival, Van/6, Lana, 35 EUR, Avion, primary image cell 'Get-E', independent OCR 'GetE'. Preserve original 'Get-E'.
Only original raw image 97633.jpg with SHA256 2e34a0d568e19fdb073bc4db141175a7cd686483544df7f43d3bae3e2f3e0e73 and 22 consecutive source rows plus exact geometry, company-source-cell raw OCR, known flight/time/driver/price/customer/vehicle/route-peer context qualify.
Any other photo, row, different company, other source-cell view or inconsistent context remains fail-closed. NO global company alias; NO hardcoded named hotel route. Keep P113.1 and historical P114.7/P114.11 company source-truth vetoes intact.
P11442 OS166 '2HK nicht' remains in notes and is NOT used as flightTime; tests verify both through actual source-bound function. Final Android screenshot/preflight and real Samsung import-free test remain OPEN.
PreBuild LOCAL regression: 41/41 executable source gates PASS, P11443 real original photo 334 checks including 42 negative, historical P11442 source-bound test, P11441 183 check row-gate, H35 historical PASS.
Android APK build and Samsung 22/22 0/0 NOT run or claimed. Do not auto-install/import.
