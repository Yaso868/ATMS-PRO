ATMS PRO P11430 – PREPARED ONLY, NOT UPLOADED, NOT BUILT, NOT INSTALLED
BASE_BRANCH=atms-price-p11429-test-only
BASE_HEAD=e2aa86c9f3fe917d7752ffd101b13e0c89340935
APP_PACKAGE=de.atmspro.app
versionCode=7
versionName=1.4.0-ap01-p11430-price-ocr-test
INTENT=Diagnose der Originalpreis-Zelle 35,00 EUR (17.10.2026 12:40 / Milad / EW9531); keine Preisvorgabe und kein Produktivimport.
CHANGES=Only plan-import.js P11429 local price-parameter/diagnosis hotfix; P11430 index/cache/PWA/Gradle alignment and new prebuild price/OCR fake worker test.
NO_DATA_LOSS=No storage, import, database, backup, reset, restore, flight matcher or persistence change.
IMPORTANT=Historical license/security/release gates remain blocked; only explicit separate authorization could allow an isolated future GitHub test upload/build/installation.
SAFETY=Single-file ZIP upload only to test branch, never to main, after future fresh lease/identity checks.
