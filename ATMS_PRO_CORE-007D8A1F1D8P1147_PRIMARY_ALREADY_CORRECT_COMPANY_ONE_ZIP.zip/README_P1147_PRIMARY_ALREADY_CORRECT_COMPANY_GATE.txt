ATMS PRO – P114.7 · GUARDED PRIMARY-ALREADY-CORRECT COMPANY CONFLICT
08.10.2026 · Installer-kompatibles One-ZIP (kein Benutzer-Entpacken)

BASE: Nutzer-GitHub-main-ZIP 08.10.2026, Git-Archiv-Kommentar 2cd9bc5e3e7cad183fd7d1e3a4c13089b1adab00.
WICHTIG: Live-GitHub-HEAD wurde wegen Netz-/Webzugriffsgrenze NICHT extern verifiziert. Vor Upload ist ein HEAD-Abgleich erforderlich; bei anderer SHA keinesfalls dieses Paket einspielen.

FIX: P114.6 erfordert bei internem Firmen-Trennzeichenverlust bisher einen Korrektureintrag. Bei einem bereits korrekten Haupt-OCR-Wert entsteht dieser nicht und ein sekundär abgeschnittenes Textresultat blockiert unberechtigt.
P114.7 ermöglicht eine eng begrenzte Freigabe nur bei >=3 exakten Peerzeilen sowie starker Haupt-OCR-Evidenz (>=80 Konfidenz, vollständig zugeordnete, ungeclippte Firmenzelle) ODER zwei sicheren unabhängigen vollständigen Zellansichten. Semantische Varianten, zu wenige Peers, schwache Evidenz, konkurrierende exakte Zell-/Quellenbelege bleiben blockiert.
Die Freigabe folgt weiterhin dem obligatorischen ursprünglichen P114.6-Konsens-Pfad, wenn dieser vorhanden ist. Keine Fallwerte/Dateinamen/Zeilen/Flugnummern im Produktionscode.

REGRESSIONS: 4 positive + 20 negative/fail-closed P114.7-Tests; alle vorhandenen ausführbaren JS-OCR-/Integritätstests; P113.4/9MB echter Image-Cell-Replay = 3/3 9MB; Golden-Manifest erweitert und SHA-256 der acht Quellbilder geprüft. Alter P114.4/5/6 Cache-Aligment-Test ist absichtlich versionsgebunden und durch P114.7 Alignment ersetzt.

REGELWERK: android-native/ATMS_PRO_MASTER_PROMPT_2026-10-08.md (v1.1), android-native/AGENTS.md und executable masterPromptRuleGateP1147 (preBuild). Eine automatische Prüfung von Remote-GitHub-HEAD, vollständigem Android-Build und Realgerät ist lokal mangels Zugriff nicht möglich und steht separat aus.

INSTALLER: ZIP enthält NUR android-native/**, README_*.txt und SHA256.txt; SHA256.txt schützt alle Payload-Dateien. Unzip ins Repo-Root ist NICHT erforderlich. GitHub CI-Workflow installiert die Dateien selbst und baut anschließend die native Debug-APK. Nur EIN ZIP hochladen. Kein Commit der einzelnen Dateien erforderlich.

REALGERÄT: 33/33 WA0001 erneut prüfen, Get-E Zeile 17 ohne Blockade (sofern starke Zell-Evidenz vorliegt), 9MB/EW9420 korrekt, andere 8 Get-E und alle Fahrtdaten unverändert. Planliste NICHT importieren.
