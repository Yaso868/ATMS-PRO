ATMS PRO – P114.7 BUILDKETTEN-REPARATUR (REPLACEMENT ONE-ZIP)
Datum: 08.10.2026

SCOPE:
- Reparatur des durch P114.7 verursachten CI-Buildfehlers (P114.6 asset-alignment preBuild blockiert die P114.7-Version).
- app/build.gradle: runtimeAssetAlignmentP1146 aus preBuild-Abhaengigkeiten ENTFERNT.
- Die weiterhin sinnvolle inhaltliche P114.6-Regression companyConflictPostConsensusP1146 bleibt PFLICHT.
- tools/runtime-asset-alignment-selftest-p1147.js: prueft zusaetzlich, dass exakt die aktuelle versionsgebundene Alignment-Gate aktiviert ist; negative Testfaelle fuer alte, fehlende und doppelte Version-Gates.
- Ansonsten P114.7 produktive OCR-Regel, 9MB, EW9420, alle anderen Regressionen und MASTER-PROMPT v1.1 bytegenau UNVERAENDERT.

AKTIVER PRODUKTIVSTAND: CORE-007D8A1F1D8P1147 (kein neuer OCR-Algorithmus).
BEOBACHTETER GITHUB-HAUPTBRANCH: Nutzer-Screenshot 08.10.2026: Commit 4d479d9, Actions #210 FAIL (P114.7 ZIP-Upload). Unabhaengiger Live-GitHub-HEAD-Abgleich nicht moeglich, vor Upload anhand GitHub main pruefen.
VORHERIGE CODENACHWEISBASIS: Github-Archiv ZIP Kommentar HEAD 2cd9bc5e3e7cad183fd7d1e3a4c13089b1adab00; P114.7 Patch-Upload CI-Build #210 abgebrochen, daher kein nachgewiesenes akzeptiertes P114.7-App-Commit.

WICHTIG ZUM EIN-ZIP-ABLAUF:
GitHub Workflow erlaubt EXAKT EIN ATMS_PRO_CORE-*.zip im Repo-Root. Da der fehlgeschlagene P114.7-Upload dort liegen geblieben sein kann, ersetzt diese Korrektur die vorherige ZIP-Datei unter EXAKT DEMSELBEN DATEINAMEN. KEINE zweite anders benannte ZIP daneben hochladen. GitHub Upload im Repo-Root als Datei ERSETZEN. SHA256 der neu hochgeladenen ZIP pruefen.
Ein Upload. Keine Einzeldateien, kein manuelles Entpacken.

LOCAL TESTS:
- 15/15 direkt registrierte und via preBuild verpflichtende Node-Tests (Originaldateien + P114.7 CI-gate) PASS.
- P114.7 4 positive + 20 negative/fail-closed Matrix PASS.
- Golden Regression Pack 60 Faelle; 8 Originalbilddateien SHA-256 geprueft.
- P113.4/9MB Bild-Replay 3/3 "9MB" PASS.
- Installer-Pfad, SHA-256, Staging und danach alle PreBuild-Node-Tests erneut verifiziert.

NICHT BEHAUPTET:
Ein vollstaendiger Gradle assembleDebug und signiertes APK sind lokal nicht moeglich (Gradle/Android SDK/Secrets fehlen); der GITHUB-ACTIONS-BUILD IST NOCH AUSSTEHEND. Realgeraettest ebenfalls ausstehend. Planliste vom 07.10.2026 NICHT importieren.

PROZESSFEHLER-RULE: Keine neue dauerhafte Fehler-/Hard-Rule ohne separate Freigabe des Nutzers aufgenommen. Bestehende Master-Prompt v1.1 und AGENTS.md bleiben unveraendert.
