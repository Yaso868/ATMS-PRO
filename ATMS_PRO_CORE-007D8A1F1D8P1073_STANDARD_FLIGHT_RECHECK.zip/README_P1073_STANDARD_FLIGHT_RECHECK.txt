ATMS PRO · P107.3 STANDARD-FLIGHT LOW-CONFIDENCE CELL RECHECK
Datum: 04.10.2026

Zweck
- Schließt die im Realgerät-Test derselben 29-Fahrten-Liste sichtbare Lücke, bei der formal plausible, aber falsch gelesene Standard-Flugnummern unbemerkt importbereit werden konnten.
- Betroffenes Muster: zweistelliger Flugdesignator bleibt korrekt, eine Ziffer im Zahlenteil wird von der Primär-OCR falsch gelesen.

Produktionslogik
- Keine Airline-, Flugnummer-, Fahrer-, Orts- oder Datums-Hardcodes.
- Gezielte lokale Zweit-OCR nur, wenn
  1) die Standard-Flugnummer in der Liste eindeutig ist und die Primär-Flugzelle schwach (<70 OCR-Konfidenz / kein exakter Rohworttreffer) ist, ODER
  2) eine Fahrt mit identischer Flugzeit + Richtung einen Flugkandidaten besitzt, der sich exakt in einer Ziffer unterscheidet.
- Zwei enge Crop-Geometrien × zwei OCR-Modi.
- Automatische Änderung nur mit >=3 Stimmen, Evidenz aus beiden Crops und eindeutigem Sieger.
- Zulässige automatische Alternative: gleicher zweistelliger Designator, gleicher optionaler Suffix, gleicher Zahlenteil-Laenge, exakt eine Ziffer unterschiedlich.
- Ist die schwache Zelle nicht eindeutig bestaetigbar, wird der Import blockiert und die bestehende manuelle Flugnummer-Korrekturmaske angezeigt.
- Service-Worker-Cache auf P1073 angehoben.

Regression
- Historische konkrete Werte stehen ausschließlich im Testfixture.
- Golden-Test prüft Ein-Ziffer-Alternative, Mehrfach-OCR-Konsens sowie die bisherigen P107.1/P107.2-Fälle.
