#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.join(__dirname,'..');
const read=(p)=>fs.readFileSync(path.join(root,p),'utf8');

function validate(index,sw,pwa){
  const errors=[];
  const need=(ok,msg)=>{ if(!ok) errors.push(msg); };
  need(index.includes('CORE-007D8A1F1D8P11417'),'visible core version is not P11417');
  need(index.includes('./js/ocr-integrity-core.js?v=P11417'),'index OCR core query is not P11417');
  need(index.includes('./js/plan-import.js?v=P11417'),'index plan-import query is not P11417');
  need(index.includes('./js/pwa.js?v=P11417'),'index PWA bootstrap query is not P11417');
  need(sw.includes('atms-pro-pwa-2026-10-09-p11417-plan-date-integrity'),'service-worker cache generation is not P11417');
  need(sw.includes('"./js/ocr-integrity-core.js?v=P11417"'),'service-worker OCR core shell query is not P11417');
  need(sw.includes('"./js/plan-import.js?v=P11417"'),'service-worker plan-import shell query is not P11417');
  need(sw.includes('"./js/pwa.js?v=P11417"'),'service-worker PWA shell query is not P11417');
  need(sw.includes('caches.match("./js/plan-import.js?v=P11417")'),'service-worker plan-import fallback is not P11417');
  need(pwa.includes("navigator.serviceWorker.register('./service-worker.js?v=P11417', {updateViaCache:'none'})"),'PWA registration is not forced to P11417/no-cache update');
  const activeSw=sw.split(/\r?\n/).filter(line=>!line.trim().startsWith('//')).join('\n');
  need(!/plan-import\.js\?v=P114[0-9](?![0-9])/.test(activeSw),'service-worker contains a stale active plan-import generation');
  need(!/ocr-integrity-core\.js\?v=P114[0-9](?![0-9])/.test(activeSw),'service-worker contains a stale active OCR-core generation');
  need(!/pwa\.js\?v=(?:CORE-[^"']+|P114[0-9](?![0-9]))/.test(activeSw),'service-worker contains a stale active PWA generation');
  return errors;
}

// CI build-graph audit: old version-specific asset tests must not remain mandatory
// after switching app asset generation. Functional P114.6 regressions remain active.
function activeAlignmentGates(build){
  return Array.from(build.matchAll(/dependsOn\s+tasks\.named\(['"]runtimeAssetAlignmentP(\d+)['"]\)/g),m=>m[1]);
}
const gradleBuild=read('app/build.gradle');
assert.deepStrictEqual(activeAlignmentGates(gradleBuild),['11417'],
  'preBuild must run exactly the current P114.17 asset alignment gate (no stale version-bound gate)');
assert(gradleBuild.includes("dependsOn tasks.named('companyConflictPostConsensusP1146')"),
  'keep P114.6 functional post-consensus regressions');
assert(gradleBuild.includes("dependsOn tasks.named('companyPrimaryAlreadyCorrectP1147')"),
  'keep P114.8 positive+negative production regressions');
assert(gradleBuild.includes("dependsOn tasks.named('masterPromptRuleGateP1147')"),
  'keep master-prompt verification');
assert(gradleBuild.includes("dependsOn tasks.named('headerlessUnassignedDriverP11416')"), 'require P114.16 driver safety gate');
assert(gradleBuild.includes("dependsOn tasks.named('headerlessClockBoundaryP11415')"), 'retain P114.15 clock safety gate');
assert(gradleBuild.includes("dependsOn tasks.named('timeSourceIntegrityP11412')"), 'require P11412 time-source safety test retained');
assert(gradleBuild.includes("dependsOn tasks.named('headerlessFlightGateTraceP11413')"), 'require unchanged P11413 headerless flight-gate safety test');
assert(gradleBuild.includes("dependsOn tasks.named('headerlessMetadataIntegrityP11414')"), 'require P11414 early-return metadata-integrity safety test');
assert(gradleBuild.includes("dependsOn tasks.named('companySourceReconcileP11411')"), 'P11411 protected Get-E company regression must remain mandatory');
assert(gradleBuild.includes("dependsOn tasks.named('companyPrimaryProvenanceP1148')"),
  'keep P1148 immutable provenance and final import safety test');
// Red controls guard against reintroducing stale preBuild tasks on a future release.
for(const bad of [
  gradleBuild.replace("dependsOn tasks.named('runtimeAssetAlignmentP11417')", "dependsOn tasks.named('runtimeAssetAlignmentP1146')"),
  gradleBuild.replace("dependsOn tasks.named('runtimeAssetAlignmentP11417')", "dependsOn tasks.named('runtimeAssetAlignmentP11417')\n    dependsOn tasks.named('runtimeAssetAlignmentP1146')"),
  gradleBuild.replace("dependsOn tasks.named('runtimeAssetAlignmentP11417')", "")
]) assert.notDeepStrictEqual(activeAlignmentGates(bad),['11417'], 'stale/missing alignment gate should be rejected');

const index=read('app/src/main/assets/index.html');
const sw=read('app/src/main/assets/service-worker.js');
const pwa=read('app/src/main/assets/js/pwa.js');
assert.deepStrictEqual(validate(index,sw,pwa),[],'current runtime assets must be aligned');

for (const [name,badIndex,badSw,badPwa] of [
  ['stale index plan-import',index.replace('plan-import.js?v=P11417','plan-import.js?v=P1145'),sw,pwa],
  ['stale index OCR core',index.replace('ocr-integrity-core.js?v=P11417','ocr-integrity-core.js?v=P1145'),sw,pwa],
  ['stale index PWA bootstrap',index.replace('pwa.js?v=P11417','pwa.js?v=P1145'),sw,pwa],
  ['stale service-worker cache',index,sw.replace('p11417-plan-date-integrity','p1145-company-boundary-classification'),pwa],
  ['stale service-worker plan shell',index,sw.replace('"./js/plan-import.js?v=P11417"','"./js/plan-import.js?v=P1145"'),pwa],
  ['stale service-worker fallback',index,sw.replace('caches.match("./js/plan-import.js?v=P11417")','caches.match("./js/plan-import.js?v=P1145")'),pwa],
  ['stale service-worker registration',index,sw,pwa.replace('service-worker.js?v=P11417','service-worker.js?v=P1145')],
  ['cached service-worker update mode',index,sw,pwa.replace("{updateViaCache:'none'}","{}")],
]) {
  assert(validate(badIndex,badSw,badPwa).length>0,`${name} was not detected`);
}

const plan=read('app/src/main/assets/js/plan-import.js');
assert(plan.includes('CORE-007D8A1F1D8P11417'),'P11417 plan-import semantics marker missing');
assert(plan.includes('CORE-007D8A1F1D8P11416'),'P11416 driver integrity source must remain present');
assert(plan.includes('PRIMARY-ALREADY-CORRECT COMPANY CONFLICT'),'P11416 production plan-import marker missing');
assert(plan.includes("p54MeasureSync('company_conflict_post_consensus'"),'P11417 production pipeline hook missing');

console.log('P114.17 runtime asset alignment self-test: PASS');
