ATMS PRO – P114.17 – PLANTAG / DATE-SOURCE INTEGRITY
09.10.2026 · CORE-007D8A1F1D8P11417

GIT-QUELLWAHRHEIT (am 09.10.2026 ueber GitHub commit history geprueft):
main HEAD f3936c6584eb321513b4a84cae7adf9a9decff0d
GitHub-Repo: https://github.com/Yaso868/ATMS-PRO
P114.16 release patch SHA-256:
f3a272197eae2047d4bef0dae60cd5dfafa75627cd72fba85a747ef30d55144b
Der Stand wurde am 09.10. frisch abgeglichen. Die hier mitgegebenen P114.16-Runtime-Dateien stammen aus dem zu diesem Release gehoerigen und SHA-geprueften Installer-Archiv (dessen Dateien vom GitHub Bot im Commit f3936c6 angewendet wurden).

PATCH-INHALT (DATUMSSCOPE):
1. Beseitigt ReferenceError in der manuellen Datums-Change-Handler-Logik (mappingInfo/headerDetection nicht im Scope).
2. Stellt Android-kompatiblen Kalender-Oeffnen-Knopf plus manuelle Eingabe TT.MM.JJJJ bereit.
3. Manuell bestaetigter Plantag bleibt gegen spaetere Dateinamen- oder OCR-Erkennung vorrangig.
4. Schon vorhandene Rohwort-OCR aus der physisch VOR der sicheren Tabellenkopfzeile gelegenen 'Liste TT.MM.JJJJ' Ueberschrift darf den WhatsApp-Dateinamen korrigieren. Geometrische/Semantische Eindeutigkeit zwingend; kein weiterer OCR-Aufruf.
5. WA0023: 'Liste 09.10.2026' erfordert Plantag 09.10 fuer ALLE 34 Fahrten; nie die 21 fruehen Fahrten nach Datum 09.10 schieben, waehrend 13 am 08.10 bleiben.
6. Echter Uebergang 08.10 23:00 -> 09.10 01:35 bleibt Folgetag-Prueffall; keine automatische stille Umsortierung anhand beliebiger Tabellenreihenfolge.
7. Widerspruch zwischen Dateiname und Bildkopf verhindert unbemerkten MORGEN-MODUS-Autoimport; nur explizite Pruefung/Importfreigabe.
8. Nach einer Aenderung des Plantags werden alte Analyse/OCR-Fehler/Import-Freigaben invalidiert. Es wird NICHT still validiert und automatisch importiert. Neue Analyse ist erforderlich.
9. Cache und Index/PWA fuer P114.17 synchronisiert; Gradle PreBuild um deterministische Datums- und Asset-Gates erweitert.
10. Die komplette Golden-Pack-70-JSON wird als unveraenderte Testfixture mitgeliefert; 67 alte Fall-Datensaetze wurden mit vorherigem Pack verglichen und sind identisch.

NICHT BEHOBEN / OFFEN, KEINE FALSCHEN ERFOLGSBEHAUPTUNGEN:
- GE-67: Re-Import/Duplikate/Fahrerwechsel in persistentem Speicher, ROOT CAUSE offen.
- GE-63 bis GE-66 und GE-69/GE-70: OCR-Quellen-/Flugnummern-/Routenabweichungen weiter fail-closed.
- Die lokal getesteten Datumsszenarien sind NICHT gleichbedeutend mit einem Samsung Realgeraete-Test oder 70/70 Vollpipeline-OCR-Tests.
- Kein PDF-Planlistenimport in P114.17.

LOKALE QA:
node android-native/tools/plan-date-integrity-selftest-p11417.js
node android-native/tools/runtime-asset-alignment-selftest-p11417.js
node --check android-native/app/src/main/assets/js/plan-import.js

INSTALLATION:
ZIP NICHT entpacken; Repo https://github.com/Yaso868/ATMS-PRO oeffnen,
Branch main/Breadcrumb ATMS-PRO / pruefen, Add file -> Upload files.
Ein einziges Patch-ZIP ins Repo-Root hochladen; Commit-Name/Text getrennt bereitgestellt.
Der bestehende GitHub Actions Patch-Installer prueft SHA256.txt und baut erst dann eine signierte Debug-APK, sofern die verpflichtenden Tests bestanden sind. Vor Installation Actions und APK separat kontrollieren.
Keine automatischen Fahrtenuebernahmen durch den Assistenten.
