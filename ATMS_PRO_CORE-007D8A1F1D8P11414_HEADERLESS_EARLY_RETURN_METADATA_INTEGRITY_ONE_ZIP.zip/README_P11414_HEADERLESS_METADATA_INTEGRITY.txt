ATMS PRO CORE-007D8A1F1D8P11414 – HEADERLESS EARLY-RETURN METADATA INTEGRITY
08.10.2026 · ROOT CAUSE FIRST · DIAGNOSE-ONLY · GOLDEN ERROR 62

Installation: Das ZIP gehört als EINE Datei ins ROOT des GitHub-Repositories
https://github.com/Yaso868/ATMS-PRO, Branch main, Breadcrumb ATMS-PRO /.
Erst hochladen, nachdem der aktuelle main-Stand nachweislich P114.13 enthält;
keinen älteren Projektstand überschreiben. Den GitHub Native APK + Patch Installer
Workflow vollständig grün abwarten und erst dann die neue APK installieren.

Technische Reparatur:
- '_atmsImageMeta' bleibt auch bei early-return an der geklonten Matrix.
- Abbrüche bei >4 ungültigen Zellen einer Zeile sowie >12 insgesamt behalten
  exakten bisherigen Sperrgrund, tatsächlich gezählte Fehler, ersten
  betroffenen Matrix-/Quell-Zeilenindex und begrenzte Original-Zellwerte.
- Fehlendes Tesseract oder Canvas wird eindeutig als nicht geprüfte OCR
  gemeldet (keine erfundenen Null-Zähler).
- Flugprüfung vor Core-Sicherheitsgrenzen explizit 'not_evaluated_preflight',
  statt '0 Flüge, 0 Doppelspalten'.
- Android-Fehlermeldung führt P11414, Messbereich und RohZellen kompakt auf.
- Kein Unlock, kein Ersetzen von Flugnummern, keine Fahrtenübernahme;
  bisherige Fail-Closed-Sperre bleibt unverändert.

Lokale Tests:
- 22/22 in Gradle preBuild eingehängte Node-Gates bestanden.
- P11414 early-return 11/11; P11413 flight 12/12; P11412 time 12/12;
  P11411 company 28/28; Golden Pack 62 unverändert.
- SHA256.txt enthält die SHA256-Werte ALLER neun Installer-Nutzdateien.
- Lokaler GitHub-Workflow-Payloadabgleich/SHA256-Probe bestanden.

WICHTIG: P114.14 ist kein nachgewiesener endgültiger Fix für die Ablehnung
von IMG-20261008-WA0014.jpg. Erst eine erneute Realgerät-Diagnose zeigt den
konkreten Abbruchpfad. Signierter APK-Build ausschließlich bei GitHub Actions.
