ATMS PRO P114.16 – VERIFIED UNASSIGNED DRIVER INTEGRITY
08.10.2026

Freigabe: User ausdrücklich JETZT PATCHEN.

Problem (Golden Error 62):
08.10.2026 IMG-20261008-WA0014.jpg, 17 Fahrten ohne Kopfzeile,
Fahrt 16:00 DUS Airport -> NH Nord, Fahrerzelle im Original leer.
P114.15 brachte die vorangehenden Zeitfehler 16 -> 1; übrig blieb die
starre Fahrer-Pflicht in der kopfzeilenlosen OCR-Vorprüfung.

Neu:
- Fahrer wirklich leer: durch Rohwortgeometrie und 3 lokale OCR-Lesungen
  desselben rechten Zellbereichs absichern; als driver="" mit Status
  driverAssignmentStatus="unassigned" speichern; Vorschau Nicht zugewiesen.
- Vorhandener Fahrer: exakten Namen erhalten oder nur mit belegtem OCR-
  Konsens aus derselben Fahrerzelle wiederherstellen.
- Einzelne Namenshinweise, konkurrierende Rohworte, fehlende Zellgeometrie
  sowie fragliche OCR => unveränderte Importsperre; kein Farb-/Nachbarraten.
- Andere Felder, Flugspalten, 12er-Pflichtfeldschwelle und Zeit-Gates
  bleiben unverändert. Warnung Nicht zugewiesen stoppt unbeaufsichtigten
  Morgen-Modus-Autoimport; manuelle geprüfte Übernahme bleibt möglich.

Lokal: P114.16 34/34 Produktionsfunktions-Szenarien PASS;
24/24 ausführbare Gradle-preBuild Node-Gates PASS; Golden Pack 62 geschützt.
Installer ZIP: SHA256.txt prüft jede Nutzdatei. ZIP auf GitHub-Repo
ROOT im Branch main hochladen (nicht entpacken), Actions baut APK.
Keine APK oder Samsung-Realgerätprüfung in diesem Paket.

Sicherheitsvoraussetzung:
Der aus den zuletzt freigegebenen P114.15-Paketen rekonstruierte
Quellstand ist Patchbasis. Aktuelle öffentliche GitHub-HTML-Ansicht war
bei der Abfrage gecacht und zeigte P114.14. Vor dem GitHub-Commit
unbedingt main tatsächlich als P114.15 bestätigen und fremde Commits
nicht überlagern. 40-stelligen HEAD niemals raten.
