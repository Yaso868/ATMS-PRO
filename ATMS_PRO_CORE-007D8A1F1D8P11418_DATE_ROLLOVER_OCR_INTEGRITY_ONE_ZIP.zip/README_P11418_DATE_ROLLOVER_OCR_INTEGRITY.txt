ATMS PRO P114.18 – DATE / ROLLOVER / BOUNDED OCR INTEGRITY
Stand: 09.10.2026 · CORE-007D8A1F1D8P11418

QUELLE / RELEASE-SPERRE:
- Das bearbeitete Native-Asset ist vom SHA-256-geprueften P114.17 One-ZIP, auf GitHub als Commit c19c1cd bestaetigt.
- GitHub main/Repo wurde am 09.10.2026 erneut oeffentlich aufgerufen. Der exakte neue HEAD SHA und die aktuellen Remote-Quelldatei-Bytes konnten im aktuellen Toolzugang NICHT abgerufen werden.
- Darum bleibt diese ZIP ein LOKAL PRUEFBARER KANDIDAT. Vor Upload fuer die produktive GitHub-Build-Pipeline den exakten main HEAD UND die erwartete P114.17-Dateibasis erneut gegen GitHub vergleichen. Bei Abweichung STOP; kein Blind-Patch.

INHALT:
1. P114.17-Kalenderauswahl und alle Sicherheitsgates beibehalten.
2. selectFiles() loescht den zuvor manuell bestaetigten Plantag NICHT mehr. Bildname bleibt Hint, nicht Override.
3. Unabhaengige Planueberschrift vs manuelle Wahl: Konflikt verhindert unbeaufsichtigten Auto-Import, Nutzerauswahl wird nicht still ueberschrieben.
4. Mit vertrauenswuerdigem Plantag und ausschliesslich Morgen-/Tagesfahrten kein automatischer 'alle fruehen Fahrten = morgen'-Block. Fruehe und spaetabendliche Zeiten bleiben gemeinsam pruefpflichtig, auch bei unsortierter Liste.
5. 2-Familien-Route-Grenzfall: ein sekundar abgeschnittener kompletter erster Orts-Token darf den starken primaeren Routenwert nur dann nicht blockieren, wenn der Quell-Rohwortbereich die Matrixgrenze messbar ueberschreitet und zwei kontextgleiche Listen-Peers die volle Route belegen; echte Alternativen bleiben hart gesperrt.
6. Extra langer Flug-Praefix plus eine zusaetzliche Ziffernabweichung darf nur mit 6 echten, exakten lokalen Kandidaten aus >=2 Crops und >=2 Modusfamilien und einstimmigem Ziffernbeleg korrigiert werden. Kein konkreter Flugnummern-Hardcode, jeder abweichende Crop blockiert.
7. P114.18-Golden-Pack 72 erweitert exakt und unveraendert das Pack 70 um den 2 real bestaetigten P114.17 Datumsbugs; Fehler 67 Re-Import weiterhin OFFEN, keine Bestandsmigration, kein Loeschen, keine Fahrtenuebernahme.

LOKALE QA AUSGEFUEHRT:
node android-native/tools/plan-date-integrity-selftest-p11418.js   -> 13/13 bestanden (gezielte Produktionsmodul-Unit-Regressions)
node android-native/tools/runtime-asset-alignment-selftest-p11418.js  -> PASS
node --check android-native/app/src/main/assets/js/plan-import.js  -> PASS
Golden-70 SHA-256 wie Quelluebergabe: 78c09acd14b3f0fde2283a83cefcbe0f9f10b4ff544ffe6edfeb8feeede8e656
NICHT BEHAUPTEN: 72/72 echte Voll-OCR-Testlaeufe oder Samsung-Realgeraete-PASS.

NUTZER-REGELN:
- NUR ein ZIP ins Repo-Root ueber Add file -> Upload files. Nicht entpacken, nicht /upload/main direkt anspringen.
- Erst branch main UND Breadcrumb ATMS-PRO / visuell pruefen; Abweichung -> STOP.
- Vor produktivem Commit aktuelles GitHub main mit Quelle abgleichen.
- Kein Fahrtenimport, kein automatisches Loeschen alter Fahrten.
- Nach erfolgreichem GitHub Actions APK-Build die neue APK auf Samsung und 34-Fahrten-Liste pruefen; keine alte APK irrtuemlich installieren.
