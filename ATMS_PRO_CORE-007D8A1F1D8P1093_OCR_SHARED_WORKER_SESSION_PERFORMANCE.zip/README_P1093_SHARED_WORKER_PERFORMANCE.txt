ATMS PRO · CORE-007D8A1F1D8P1093
OCR SHARED-WORKER SESSION PERFORMANCE FIX
Date: 06.10.2026

BASE
- GitHub main was freshly verified by the user before packaging: HEAD 7ad04eb, parent 96941c7, 3/3 checks green.
- HEAD 7ad04eb is the final P109.2D diagnostic bot commit.
- This package is built from the exact P109.2D production payload that was installed by that bot commit, with only the P109.3 files below changed.

P109.2D REAL-DEVICE EVIDENCE
- WA0023: 29/29 rides, 0 hints, 0 OCR errors, 18 automatic corrections.
- Avion edge correction remained correct; Schütz diacritic correction remained correct.
- P109PERF observed 45 OCR workers in one 29-row analysis.
- Repeated fresh workers showed long pre-recognize stalls on Android WebView.
- Examples from the proof run: early-time workers each waited about 13.4 s before active recognition; later price workers showed about 4.2 s pre-recognize stalls.
- The existing explicit Text Integrity worker already demonstrated that reuse works: after the first pass, later local recognizes reused the same worker and completed without recreating the full lifecycle.

P109.3 CHANGE
- Introduces one import-scoped shared ENG Tesseract worker and one shared DEU Tesseract worker.
- The existing high-cost phases are routed through those workers:
  * primary_ocr
  * early_time_batch_ocr
  * price_targeted_ocr
  * route_deu_column_ocr
  * driver_deu_column_ocr
  * text_integrity_ocr
  * missing_flight_targeted_ocr
- Calls are serialized per language so two OCR crops never execute concurrently on the same worker.
- The workers are terminated once after the shared OCR phases finish.
- P109PERF remains enabled and reports worker reuse for the P109.3 real-device proof.

SEMANTICS / SAFETY
- No crop geometry changed.
- No OCR language changed.
- No row/column mapping changed.
- No customer, place, driver, flight, date, row or filename hardcode added.
- Existing one-shot options are NOT converted into worker.setParameters(). This intentionally preserves the Tesseract.js v5 behavior of the old one-shot calls; changing those to OCR parameters would alter recognition semantics.
- The only existing explicit setParameters sequence remains Text Integrity (PSM 6/7/6), unchanged.
- P108 time fail-closed logic unchanged.
- P109.2 Avion edge consensus unchanged.
- Schütz/diacritic consensus unchanged.
- FLIGHT-008 and all flight verification rules unchanged.
- PLAN/DISPO/LIVE unchanged.
- Import/dedupe/bundle logic unchanged.
- Storage V2/persistence unchanged.

VISIBLE VERSION / CACHE
- About/version marker: CORE-007D8A1F1D8P1093.
- Service-worker cache/query marker updated to P1093 only to force delivery of the new plan-import.js.

EXPECTED REAL-DEVICE ACCEPTANCE
1. Install P109.3 APK over the current app.
2. Analyze IMG-20261005-WA0023.jpg once without manual edits.
3. Functional gate must remain: 29/29, 0 hints, 0 OCR errors, Avion corrected, Schütz corrected.
4. Copy the CORE diagnosis line containing P54Perf, P63Primary and P109Perf.
5. P109Perf should show a drastic worker-count reduction from P109.2D's 45 workers and reuse=YES on later operations.
6. Total/P54 wall-clock performance must materially improve without changing recognition decisions.

LOCAL VALIDATION BEFORE PACKAGING
- node --check plan-import.js: PASS
- node --check service-worker.js: PASS
- android-native/tools/ocr-regression-selftest.js: PASS
- P109.2 text-cell edge-consensus self-test: PASS
