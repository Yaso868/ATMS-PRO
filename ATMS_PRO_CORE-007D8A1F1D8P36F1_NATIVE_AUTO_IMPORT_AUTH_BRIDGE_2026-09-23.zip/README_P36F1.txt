ATMS PRO CORE-007D8A1F1D8P36F1 – Native Clean-Plan Auto-Import Authorization Bridge
Date: 23.09.2026

Purpose
- Restores the missing native authorization bridge required by the existing P31F5/P36 clean-plan auto-flight pipeline.
- A real trusted user click on “Planliste analysieren” arms the asynchronous pipeline.
- Programmatic/untrusted clicks remain blocked.
- The final pipeline gate creates the existing short-lived CORE-006A import authorization immediately before applyImportedRides().

Scope
- android-native/app/src/main/assets/js/app.js only.
- No changes to OCR parsing, flight matching, airport providers, PLAN/DISPO/LIVE semantics, persistence, signing, or workflow files.

Expected P36F1 test
1. Select the same 23.09.2026 plan image.
2. Tap “Planliste analysieren” once as a real user action.
3. A clean plan should transition into “Plan sauber · Automatik startet …”.
4. DUS/CGN official-source checking should run before any Gemini fallback.
5. Final automatic import remains protected by CORE-006A.
