ATMS PRO – AP-01 PRODUCT-FIRST – P11427 LOCAL BUILD CANDIDATE

Dieses ZIP ist eine einzelne, guard-gebundene Quellcode-Patchdatei für den bestehenden GitHub-Actions-Installer. KEINE APK und KEIN GitHub-Archiv.

Basis GitHub main: 117c251cd40a0983e3bf072feb7fcca1f4aef6c3 (P11426)
Ziel: CORE-007D8A1F1D8P11427, Android versionCode 5, versionName 1.4.0-ap01-p11427
Geänderte Android-Dateien: 16 (einschließlich lokaler Tests und Gate-Skripte).

AP-01: bearbeitbare Planliste mit bis zu und über 85 Fahrten, manuelle 12-Feld-Korrektur, Original-Audit, sichere Bestands-/Importintegrität, Back-Gesture-Schutz, offene Flugprüfungen sichtbar, P11411 OCR-Konfliktlogik nicht gelockert.

Bedingungen:
- G06 bleibt BLOCKIERT. Keine Freigabe der originalen Bild-OCR oder generellen Flugverifizierung.
- Dieses ZIP enthält keine produktiven Fahrtdaten, keine Backups, kein APK, keine Schlüssel.
- Nur exakt EIN ZIP im Repository-Root auf GitHub hochladen (anderes Material in demselben Commit verboten).
- Der Installer verifiziert Quelle, sha256, Version und signierten Build. Ein Fehler muss STOP ergeben.
- KEINE Installationsfreigabe. Signaturgleichheit und installierter versionCode auf Samsung gesondert prüfen.
- KEIN Reset, Restore oder produktiver Import.
- Der GitHub-HEAD darf sich vor dem Upload nicht von der geprüften P11426-Basis geändert haben.

Testgrundlage: 22/22 Import-Browsertests; 15/15 Back-Navigation; 10/10 Editor; 18/18 Flug-Recheck; 16/16 G06-Trace; 12/12 P11417; P11427 Asset-Test PASS. Es wurde noch KEIN GitHub-Runner-Build ausgeführt.
