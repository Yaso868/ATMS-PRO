ATMS PRO · P107.6 STANDARD FLIGHT EVIDENCE GATE
Datum: 04.10.2026

Ziel
- Die P107.5-Realgeraet-Fehlalarme fuer bereits separat wiederhergestellte korrekte Flugnummern vermeiden.
- Den korrekten Nachbarflug nach einer gerade erfolgten Ein-Ziffer-Korrektur nicht durch einen veralteten Unique-Count blockieren.
- Eindeutige Ein-Ziffer-OCR-Korrekturen weiterhin automatisch zulassen, ohne Flugnummern-Hardcodes.

Aenderungen
1. Flugnummern, die bereits durch den dedizierten Missing-Flight-Mehrfach-OCR-Pfad wiederhergestellt wurden, werden nicht erneut durch den schwaecheren Standard-Flight-Recheck bewertet.
2. Die Anzahl gleicher Flugnummern wird waehrend des Rechecks aus der aktuell bereits korrigierten Fahrtenliste berechnet. Dadurch kann eine fruehere Korrektur einen spaeteren identischen Nachbarflug bestaetigen.
3. Ein geaenderter Kandidat mit exakt einer Ziffer Abweichung darf mit zwei unabhaengigen Crop-Stimmen automatisch korrigiert werden, wenn die urspruengliche Lesart in der gezielten Re-OCR null Stimmen erhaelt. Bei gemischter Evidenz bleibt der Fall blockierend.
4. Die strengere Bestaetigung einer unveraenderten Lesart bleibt bestehen.
5. Service-Worker-Cache auf P1076 aktualisiert.

Sicherheitsgrenzen
- Keine produktiven Airline-, Flugnummer-, Fahrer-, Orts- oder Datums-Hardcodes.
- Nur Ein-Ziffer-Alternative bei identischem zweistelligem Designator und gleicher Laenge.
- Zwei unterschiedliche Crops bleiben Pflicht fuer die reduzierte Zwei-Stimmen-Korrektur.
- Sobald die urspruengliche Lesart irgendeine gezielte Stimme erhaelt, reicht die reduzierte Zwei-Stimmen-Regel NICHT aus.
- Ungeklaerte Faelle bleiben fail-closed und manuell pruefbar.

Regression
android-native/tools/ocr-regression-selftest.js
Erwartung: P107.6 OCR regression self-test: PASS
