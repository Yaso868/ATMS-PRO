ATMS PRO – CORE-007D8A1F1D8P11412 – TIME SOURCE FAMILY INTEGRITY
Erstellt: 08.10.2026 – ROOT CAUSE FIRST – ausdrueckliche Freigabe: JETZT PATCHEN

EIN-ZIP-Installer fuer GitHub Repository ROOT von https://github.com/Yaso868/ATMS-PRO
Archive origin: user-uploaded current main.zip, original SHA-256 c1ccc346b1859dcc8a17548cadf639f54046146c21124b5cc144a0e6a574c79a.
Archived source: P11411 visible in plan-import.js, index.html and service-worker.js.
GitHub main: public branch visible with 602 commits. Last proven P11411 commit prefix 1d1b735.
The ZIP does NOT contain .git metadata. An exact 40-hex current HEAD SHA cannot be proved from this ZIP alone.
Before upload verify live GitHub main still matches P11411; do not apply if branch advanced.

Problem: Original Planliste IMG-20261008-WA0010.jpg (08.10.2026), Excel Zeile 12,
Primär 13:55 (95.3% source confidence), column re-OCR reports 13:56, hard import blocked.
The actual independent screenshot/source image bytes are not proven identical to the original WhatsApp file.

Root cause: P109 shared-worker read ignored purported PSM4/6/11 options; similar
re-reads from the same time-column were counted as two source confirmations.
P11412 isolates time OCR in one dedicated worker, applies explicit PSM values,
and only for real conflicts obtains two differently configured full-cell checks.
Qualified primary confirmation requires source cell, actual raw OCR, confidence >=90,
high geometry integrity, matching sourceRow/sourceColumn and TWO agreeing full-cell
configured modes. If inconclusive or contrary, original fail-closed block remains.
Never use a filename-specific or row-specific production exception.
No automatic import, no changes to user data, company, flight checks or persistence.

Local verification (not an Android build / not real-device acceptance):
- P11412 time-source integrity actual JS function with instrumented OCR mocks: 12/12 PASS.
- Functional regressions across existing OCR/flight/company/mirror/header: PASS.
- Existing P11411 company source conflict real trace functional test: 28/28 PASS.
- 61 Golden case manifest unique, 59 untouched and P11411 historical case preserved,
  latest approved case 61 included; historical 60-case fixture unchanged.
- P11412 version/cache/runtime gate: PASS; checked-in master prompt: PASS.
- Android Gradle/signing and P11412 actual source-image run: NOT performed here.

Only ONE ZIP to upload to the repository root. GitHub workflow validates paths,
checks SHA256.txt, stages android-native files, runs Gradle build, and commits
installed code only after successful build. The user must verify workflow SUCCESS
and perform the final Samsung test before calling P11412 REALDEVICE PASS.
