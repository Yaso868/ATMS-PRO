ATMS PRO · P106.3 · MULTI-IMAGE HEADER-ORDER FIX · 02.10.2026

Basis:
- frischer GitHub-main nach P106.2 / Native Build #164
- P106.2 Einzelbild-Schema-/Performance-Fix bleibt unverändert
- P106.1 nativer Ein-/Mehrfach-Dateiwähler bleibt unverändert

Belegter Realgerätefehler:
- Einzelbild nach P106.2: 8/8 Fahrten in ca. 4,5 s korrekt erkannt; Fahrer, Selim und Flugnummern wieder korrekt.
- Mehrbild mit denselben 8 Fahrten + kopfzeilenlosem 2-Fahrten-Ausschnitt: ATMS meldete zwar "2 Teile", erkannte aber nur 8 statt 10 Fahrten.
- Diagnose zeigte die sichere Kopfzeile erst weit unterhalb des Bildanfangs. Ursache: Android/SAF lieferte die zwei ausgewählten Bilder in einer Reihenfolge, in der der kopfzeilenlose Fortsetzungsausschnitt vor dem Hauptbild lag.
- imageWordsToMatrix nimmt bei sicherer Kopfzeile absichtlich nur Zeilen UNTERHALB der Kopfzeile als Daten an. Dadurch wurden XC333/XC334 vor der Kopfzeile korrekt fail-closed verworfen.
- Folgefehler im Mehrbildlauf: ca. 104 s Laufzeit sowie einzelne verschobene/fehlende Flugdaten. Dieser Analyse-Lauf wurde NICHT übernommen.

Fix:
1) Konservative Erstordnung
- Bei mehreren Bildern wird nur dann ein deutlich höherer Bildteil als wahrscheinlicher Hauptteil nach vorn gesetzt, wenn seine skalierte Höhe mindestens 35 % über dem zweitgrößten Teil liegt.
- Gleich große/ähnliche Screenshots behalten exakt ihre Auswahlreihenfolge.

2) Sichere Header-Ortung nach OCR
- Für jedes zusammengeführte Bild wird die Position der tatsächlich sicher erkannten Kopfzeile auf den ursprünglichen Bildteil zurückgerechnet.
- Liegt die sichere Kopfzeile in einem späteren Teil, wird genau einmal neu kombiniert: dieser Header-Teil kommt nach vorn, alle übrigen Teile behalten ihre bisherige Reihenfolge.
- Liegt die sichere Kopfzeile danach weiterhin nicht am Anfang, bricht ATMS fail-closed ab statt zu raten.

3) Scope
- Einzelbildpfad wird nicht geändert.
- Keine Änderung an Fahrername, Fahrerfarben, Flugverifikation, Preisen, Routing, Dedupe, Storage V2, Archiv oder P105.
- P106.3 korrigiert ausschließlich die Reihenfolge/Verkettung im Mehrbild-Pfad.

Verbindlicher Realtest nach Installation:
A) Hauptbild + Fortsetzungsbild gemeinsam auswählen und analysieren, NICHT übernehmen.
B) Erwartung:
   - "Bild / WhatsApp · 2 Teile"
   - 10 Fahrten insgesamt
   - XC333 + XC334 zusätzlich vorhanden
   - Daniel auf beiden Fortsetzungsfahrten
   - keine verlorenen zuvor korrekten Flüge aus dem Hauptbild
   - Laufzeit darf nicht wieder in den ~104-s-Regressionsbereich fallen
C) Fahrerfarben (insb. Dennis=Tuerkis, Daniel=Hellgruen) werden anschließend separat bewertet; diese Farberkennung wird durch P106.3 nicht verändert.
