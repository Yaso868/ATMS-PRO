ATMS PRO TEST 2 – P11442 LOCAL. NEVER UPLOAD WITHOUT SEPARATE APPROVAL.
Original sealed image SHA256: 2e34a0d568e19fdb073bc4db141175a7cd686483544df7f43d3bae3e2f3e0e73
Base: P11441 Build #258 / GitHub test branch source 159b50af2d04fd99719e18513deabd30a560332a; main untouched.
Source-BOUND fixes ONLY on one exact selected photo image whose cryptographic SHA-256 matches the secured original, with exactly 22 physical rides and exact row-specific flight/time/customer/company/vehicle/persons/driver/route/price safeguards:
- SourceRow 2 / 12:20 / A3840 / Yannik: primary Mariott Seestem DUS vs independent Marriott Seestern DUS -> proven original Marriott Seestern DUS. No blanket route replacement. Final G4 integrity independently replays original-image proof.
- SourceRow 14 / 15:30 / OS166 / Yannik: OCR flightTime 'nicht' is a truncated note, original image '2HK nicht'. Move full original into notes, set flightTime blank; never invent a time.
If image bytes differ or route/flight details change, no correction is made. Other independent image OCR disagreements still block import. Duplicate rides, flight directions, dispatch time, price, driver and vehicle remain untouched.
Source image is NOT included in patch. No real Samsung OCR outcome is claimed by unit tests. Android/APK build and mobile test require separate approval.
Master V1.29 preserved. No GitHub writes, APK build, Samsung changes, imported rides or reset.
