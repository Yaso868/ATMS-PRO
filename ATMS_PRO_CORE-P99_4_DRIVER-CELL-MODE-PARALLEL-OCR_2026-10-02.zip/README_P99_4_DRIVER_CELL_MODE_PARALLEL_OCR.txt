ATMS PRO – P99.4 DRIVER CELL MODE-PARALLEL OCR PERFORMANCE FIX
Datum: 02.10.2026

ZIEL
Beschleunigt ausschließlich den bereits vorhandenen gezielten Fahrerzellen-Nachscan.
Der Realgerät-P54-Beweistest der 13-Fahrten-Liste vom 01.10.2026 zeigte:
  missing_driver_targeted_ocr = 27715 ms
  gesamt = 36929 ms

ÄNDERUNG
- Für jeden unveränderten Fahrerzellen-Crop laufen die drei bereits vorhandenen OCR-Modi
  default / PSM 7 / PSM 8 parallel.
- Die drei vorhandenen Crops bleiben bewusst nacheinander.
- Maximale Parallelität: 3 OCR-Aufrufe, nicht 9.
- Promise.all bewahrt die bestehende Modus-Reihenfolge für die anschließende Auswertung.

UNVERÄNDERT / SICHERHEIT
- gleiche drei Crop-Geometrien und Skalierungen
- OCR-Sprache 'eng'
- gleiche Kandidatenbereinigung
- gleiche Stimmenzählung
- mindestens zwei identische Treffer erforderlich
- Gleichstand bleibt blockiert
- bestehende manuelle Prüfflags bleiben
- keine Fahrer-Hardcodes
- keine Änderung an Datum, PLAN/DISPO/LIVE, FLIGHT-008
- keine Änderung an Import/Dedupe/Bundles, Storage V2 oder Persistenz

REALGERÄT-BEWEISTEST NACH INSTALLATION
Nur dieselbe 13-Fahrten-Planliste vom 01.10.2026 einmal analysieren.
Im Diagnose-Selbstcheck vergleichen:
- missing_driver_targeted_ocr
- gesamt
Zusätzlich prüfen:
- 13/13 Fahrten
- Fahrerwerte unverändert korrekt
- Folgetag-Entscheidung weiterhin 2 Fahrten 01:35 -> 02.10.2026
Keine erneute Übernahme der Fahrten erforderlich; Performance-Test endet nach Analyse.
