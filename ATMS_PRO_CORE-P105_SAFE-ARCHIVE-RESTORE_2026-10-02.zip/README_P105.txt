ATMS PRO · P105 · SAFE ARCHIVE RESTORE
02.10.2026

Ziel
- Ergänzt eine sichere, additive Wiederherstellung aus bereits verifizierten .atmsarchive-Dateien.
- Öffnen des Archivs bleibt weiterhin READ-ONLY; Wiederherstellung erfolgt nur über eine separate zweistufige P105-Freigabe.
- Bestehende Fahrt-IDs werden niemals überschrieben.
- Nur im aktiven Bestand fehlende Archivfahrten werden ergänzt.

Sicherheitsablauf
1. Archiv wird wie in P104 erneut nativ gelesen und per Datei-SHA-256, Payload-SHA-256, Dateigröße, Datum und Zählern geprüft.
2. P105 zeigt vorab: neu hinzufügen / bereits vorhanden / überschreiben = 0.
3. Vor jeder Freigabe muss Storage V2 exakt synchron sein.
4. P105 erstellt ein NEUES vollständiges ATMS-Backup des aktuellen Bestands und prüft dessen Metadaten gegen den unveränderten Fahrten-/Erledigt-Speicher.
5. Erst danach wird eine zweite ausdrückliche Bestätigung freigeschaltet.
6. Beim Anwenden werden Archiv und aktiver Bestand erneut geprüft.
7. Nur fehlende Fahrt-IDs werden additiv ergänzt; bestehende Fahrten und deren Status bleiben unverändert.
8. Wiederhergestellte Altfahrten werden als ältere Carryover markiert, damit die aktuelle Planliste nicht fälschlich vergrößert wird.
9. localStorage, Durable Shadow und Storage V2 müssen den neuen Zustand exakt bestätigen.
10. Bei einem Fehler nach Beginn des Schreibens wird der exakte Vorzustand zurückgerollt und erneut in Durable Shadow + Storage V2 bestätigt.

Backup-Erweiterung
- Erfolgreiche Backups liefern jetzt intern true/false zurück, damit P105 einen abgebrochenen Export sicher blockieren kann.
- BACKUP_META enthält zusätzlich rideCount, doneCount, ridesHash und doneHash.
- Normale manuelle Backup-Funktion und Dateiformat ATMS_BACKUP v1 bleiben kompatibel.

Erwartung mit dem aktuell bestätigten Datenstand
- Aktiver Bestand nach P103: 13 Fahrten.
- Verifiziertes Vor-Archiv 01.10.2026: 15 Fahrten.
- Vergleich anhand der unveränderten Fahrt-IDs ergibt: 4 neu hinzufügen, 11 bereits vorhanden, 0 überschreiben, danach 17 aktiv.
- Die 4 zusätzlichen Fahrten sind die früheren Carryover EW9735, EW9835, EW9815 und EW9423.

Unverändert
- P104/P104.1/P104.2/P104.3 Archiv-Lesen, Viewer und Navigation
- Storage V2 Phase 1 / Phase 2B Archivformat
- P103 Bereinigung
- OCR und Import/Dedupe/Bundles
- PLAN/DISPO/LIVE und FLIGHT-008
- Adressbuch, Fahrer, Disponenten

Prüfungen vor Paketierung
- JavaScript-Syntax: node --check bestanden.
- Offline-Konsistenzcheck mit den vorhandenen Sicherungen 12:14 (156 Fahrten) und 18:03 (13 Fahrten): Für das 01.10.-Archiv ergeben sich genau 4 fehlende + 11 bereits vorhandene Fahrt-IDs.
- Android-Build und Signatur werden wie üblich erst im GitHub Native APK + Patch Installer bewiesen.
