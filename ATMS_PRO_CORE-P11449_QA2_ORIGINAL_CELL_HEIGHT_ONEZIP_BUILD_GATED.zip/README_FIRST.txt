ATMS PRO P11449; one ZIP / TEST2 only, source P11448 Build 269 baseline 23f494817d4252410d850dbdfbfd188fa32afe74
Fix ONLY original image-height metadata from a source canvas with exact matching dimensions.
Security: preserve all P11448 field/row/source/hash/price/date/flight/driver/duplicates gates.
No named hotel or company exception. Original 97988.jpg tested locally, NEVER uploaded to GitHub.
All mandatory preBuild gates must pass in CI. No Samsung writes, imports, reset or deletion.
