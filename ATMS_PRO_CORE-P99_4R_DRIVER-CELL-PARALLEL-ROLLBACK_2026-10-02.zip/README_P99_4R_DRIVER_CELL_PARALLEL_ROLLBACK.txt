ATMS PRO P99.4R – Driver Cell Mode-Parallel OCR Rollback
Date: 02.10.2026

Purpose
- Reverts only the P99.4 Promise.all parallel execution of the three OCR modes inside one driver-cell crop.
- Restores the previously proven strictly sequential OCR mode execution.

Real-device evidence
- Pre-P99.4 total analysis: about 36.9 s; missing_driver_targeted_ocr about 27.7 s.
- P99.4 run 1: total about 58.9 s; missing_driver_targeted_ocr about 8.8 s.
- P99.4 run 2: total about 63.4 s; missing_driver_targeted_ocr about 4.9 s.
- Other Tesseract phases regressed strongly, so the parallelization is rejected.

Safety
- No change to crop geometry, OCR modes, scales, candidate cleanup, voting, two-hit consensus, tie blocking, manual-review flags, or acceptance thresholds.
- No change to ride data, date logic, PLAN/DISPO/LIVE, FLIGHT-008, import/dedupe/bundles, Storage V2, or persistence.
- P99.3 and all other already validated changes remain untouched.
