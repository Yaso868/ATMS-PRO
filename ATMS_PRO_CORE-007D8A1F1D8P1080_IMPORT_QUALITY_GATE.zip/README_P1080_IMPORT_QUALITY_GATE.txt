ATMS PRO · P108.0 · Import Quality Gate / Golden Regression
Datum: 05.10.2026
Source of Truth: GitHub main, frisch verifiziert gegen Bot-Commit 6187f3e
Basis-Commit: 6187f3ed4e833eeb0fd3e9d9931660d4da5e060b

Ziel
- Behebt keine einzelne Planliste per Hardcode, sondern vier allgemeine Fehlerklassen aus der Golden-Regression IMG-20261005-WA0029.jpg.
- Keine Flugnummer-, Fahrer-, Orts-, Datums- oder Zeilen-Sonderregel im Produktionscode.
- Unsichere OCR bleibt fail-closed.

A) Mehrwort-Routenzellen
- Roh-OCR-Wörter derselben geometrischen Zelle werden zusätzlich in X-Reihenfolge als Zell-Evidenz zusammengesetzt.
- Dadurch kann ein stabiler Targeted-OCR-Zellkonsens wie ein Mehrwort-Ziel wiederhergestellt werden, ohne Orte zu erfinden.

B) Zeit-Quality-Gate
- Die vorhandene gebündelte Zeit-Gegen-OCR prüft nun alle formal gültigen Fahrzeiten, nicht nur 00:00–05:59.
- Ein starker widersprüchlicher Tageszeit-Konsens ohne unabhängige Spiegelbestätigung wird als Fehler blockiert statt still importiert.
- Frühzeit-Verhalten bleibt fail-closed kompatibel.

C) Lange Flugpräfixe
- Auffällige lange Flugnummern werden auf der Bounding-Box des tatsächlich gelesenen Flugworts statt primär auf der breiten Zellfläche gegengeprüft.
- Drei Tight-Crops × drei OCR-Segmentierungsmodi bleiben erhalten; bestehende Mehrfach-Crop-/Vote-Gates bleiben bestehen.
- Keine feste EWS→EW-Regel; wenn die Bild-Evidenz nicht konvergiert, bleibt der Import blockiert.

D) Fahrerfarben
- Benachbarte 20er-RGB-Buckets werden mit unveränderten Sicherheits-Schwellen zu einem lokalen Farbcluster zusammengefasst; Schwellen werden nicht abgesenkt.
- Fehlende/schwache Einzelzellen dürfen nur aus mindestens zwei sicheren Same-Plan/Same-Driver-Farbwerten mit engem Spread rekonstruiert werden.
- Keine historische/Stammdaten-Farbe und keine Fahrername→Farbe-Regel.

Golden-Regression / Anti-Hardcode
- Konkrete Regressionwerte bleiben nur im Test-/Dokumentationskontext.
- Produktionsdateien enthalten keine WA0029-Flug-/Zeit-Sonderwerte.
- Node-Regressions-Selbsttest enthält P108.0-Strukturgates.

Lokale Vorprüfung
- node --check plan-import.js: PASS
- node --check ocr-integrity-core.js: PASS
- node --check service-worker.js: PASS
- android-native/tools/ocr-regression-selftest.js: PASS

Realgerät-Abnahme nach GitHub Action/Installation
1. IMG-20261005-WA0029.jpg neu analysieren.
2. Zeile Holiday Inn DUS → DUS Airport darf Ziel nicht mehr verlieren.
3. Fahrt 15:10 DUS Airport → NH Nord-Holiday Inn darf nicht still als 16:10/OK durchlaufen; entweder korrekt erkannt oder explizit blockiert.
4. EW522 darf nur bei echtem Tight-Crop-Konsens automatisch korrigiert werden; sonst muss Blocker bestehen bleiben.
5. Ghasem-Farbe darf nur aus direkter Zellfarbe oder sicherem Same-Plan-Konsens entstehen.
6. Danach bestätigte Golden-Regression-Planlisten auf neue stille Abweichungen prüfen.
