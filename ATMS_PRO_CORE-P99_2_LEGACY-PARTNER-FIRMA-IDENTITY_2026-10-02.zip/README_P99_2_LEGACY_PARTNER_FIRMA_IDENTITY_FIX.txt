ATMS PRO · P99.2 LEGACY PARTNER/FIRMA IDENTITY FIX
Datum: 2026-10-02

Basis vor Patch:
- GitHub main am 02.10.2026 unmittelbar vor Patch frisch geprüft.
- Cache-frischer raw-main-Stand trägt P99.1 LEGACY FLIGHT-METADATA DEDUPE.
- Die betroffenen main-Blöcke planImportLegacyFlightCoreIdentity(), planImportLegacyDateCompatible(), planImportLegacyFlightMetadataInferior() und mergePlanImportByIdentity() wurden frisch abgeglichen.
- Vollständige app.js-Basis dieses Patches ist die unmittelbar zuvor für Build #146 verwendete P99.1-Datei; Header und betroffene P99.1-Blöcke stimmen mit dem frisch gelesenen raw main überein.
- Kein älteres Repository-ZIP wird ungeprüft als Codebasis verwendet.

Belegter Realgerät-Restfehler nach P99.1:
- XR6574 bleibt nach erneutem Import zweimal sichtbar.
- Beide Einträge zeigen dieselbe fachliche Fahrt:
  * Fahrtzeit 01:35
  * Fahrer Daniel
  * CGN Vorfeld -> Adagio
  * Flug XR6574
  * Corendon / TakeOff
  * Van
  * 6 Personen
  * 65,45 EUR
- aktuelle korrekte Variante: Flugzeit 02:04, Flugort Hurghada
- alte Carryover-Variante: Flugzeit 01:35, Flugort nicht verfügbar
- P99.1-Date/Metadata-Guards sind passend, aber der Legacy-Core-Schlüssel kann alte und neue Speicherung desselben sichtbaren Partners auseinanderhalten, wenn der alte Datensatz Corendon nur in partner/airline und der neue zusätzlich in customer trägt.

Ziel P99.2:
1. Nur den engen P99.1-Legacy-Core-Schlüssel korrigieren.
2. Partner/Kunde fachlich kanonisch aus dem ersten vorhandenen Wert normalisieren:
   partner -> airline -> customer -> kunde
3. Firma bleibt separat und verpflichtend über:
   company -> firma
4. Dadurch werden alte und neue Speicherung derselben sichtbaren Kombination Corendon / TakeOff identisch bewertet, ohne Firma und Partner miteinander zu vermischen.
5. Alle übrigen P99.1-Sicherheitsgates bleiben unverändert:
   - nur _planCarryover=true + _planMissingFromLatest=true
   - keine erledigten Fahrten
   - keine Bundles
   - gleicher Fahrtkern (Flug, Richtung, Zeit, Fahrer, Route, Partner/Kunde, Firma, Fahrzeug, Personen, Preis, Währung)
   - Datum nur gleicher Tag oder exakt bestätigte Plantag->Folgetag-Frühfahrt
   - Altvariante muss nachweisbar schlechtere Flugmetadaten besitzen
   - exakt ein Kandidat; bei Mehrdeutigkeit fail closed

Nicht Teil dieses Patches:
- keine globale/breite Dedupe-Regel
- keine Änderung an P98/P99-Zeit-/Folgetag-/Bündel-/Firma-Logik
- keine Änderung an Adressbuch-Kandidaten / P100
- keine Änderung an Storage V2
- keine Änderung an FLIGHT-008

Lokale Vorprüfung:
- node --check app.js: OK
- synthetischer XR6574-Fall mit altem partner=Corendon, customer leer und neuem partner=Corendon, customer=Corendon: gleicher Legacy-Core-Schlüssel: OK
- Plantag 01.10 -> bestätigter Folgetag 02.10 bei 01:35: kompatibel: OK
- Alt Flugzeit=Fahrtzeit + Flugort fehlt gegenüber Neu Flugzeit=02:04 + Hurghada: inferior-Metadaten-Beweis: OK
- legitime Altvariante mit eigener Flugzeit + Flugort bleibt geschützt: OK
- abweichende Firma oder Fahrer bleibt geschützt: OK

Gezielter Realgerät-Beweistest nach Build:
- dieselbe 13-Zeilen-Liste genau EINMAL analysieren, Folgetag bestätigen und übernehmen.
- danach nur XR6574 prüfen.
- Soll: genau ein XR6574-Eintrag:
  01:35 · Daniel · CGN Vorfeld -> Adagio · Corendon / TakeOff · Van · 6 Pers. · 65,45 EUR · Flugzeit 02:04 · Hurghada.
- die alte Variante mit Flugzeit 01:35 / Flugort nicht verfügbar darf nicht mehr vorhanden sein.
- keine erneute Vollprüfung bereits bestandener P98/P99-Gates erforderlich.
