CORE-007D8A1F1D8P31F13S3 – Persistent Signing Update Test

Purpose:
- targeted update-compatibility test only
- changes Android Native versionCode from 2 to 3
- keeps versionName 1.4.0-p31f13 unchanged
- keeps applicationId de.atmspro.app unchanged
- keeps persistent signing configuration unchanged
- changes no ATMS PRO Web UI/application behavior
- intended to be installed over the confirmed P31F13S2 installation without uninstalling it
