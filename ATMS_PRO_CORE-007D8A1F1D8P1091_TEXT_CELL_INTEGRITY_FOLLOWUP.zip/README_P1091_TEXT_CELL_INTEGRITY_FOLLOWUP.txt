ATMS PRO · P109.1 · Text Cell Integrity Gate Follow-up
Datum: 05.10.2026

SOURCE OF TRUTH
- Zuletzt im laufenden Realgerät-/GitHub-Ablauf verifizierter Produktions-HEAD: 831a836
- Commit-Titel: Apply validated ATMS patch: ATMS_PRO_CORE-007D8A1F1D8P1090_TEXT_CELL_INTEGRITY_GATE
- Parent/Upload-Commit: bed53cd
- P109.0 Workflow #177: SUCCESS; APK-Artefakt erstellt und auf Realgerät installiert.
- P109.1 wurde ausschließlich aus dem validierten P109.0-Payload weiterentwickelt; keine ältere ZIP wurde als Wahrheit verwendet.

REALGERÄT-BEWEIS P109.0
- Referenz: IMG-20261005-WA0023.jpg · 29/29 Fahrten.
- Diakritik-Fall: Primärwert wurde als plausible ASCII-/Glyphen-Segmentierung erkannt; unabhängige DEU-Nach-OCR lieferte den korrekten diakritischen Kandidaten und meldete sichere Korrektur.
- Randzeichen-Fall: Primärwert enthielt ein führendes OCR-Fremdzeichen; unabhängige Nach-OCR lieferte denselben Text ohne Randartefakt, P109.0 blockierte aber noch als Konflikt.
- Import wurde dadurch korrekt fail-closed blockiert.
- P109.0 Laufzeit: gesamt ca. 110,7 s; text_integrity_ocr ca. 57,7 s.
- Das im UI darunter sichtbare JSON war bei blockiertem Import noch der vorherige erfolgreiche Import und daher irreführend/stale.

P109.1 ZIELE
1) Randzeichen-Konflikt generisch auflösen, wenn Bildbeleg + aktuelle Planliste gemeinsam stark genug sind.
2) Text-Integrity-OCR deutlich beschleunigen, ohne Wörterbuch-/Namens-Hardcodes.
3) Bei blockierter Analyse immer das AKTUELLE staged JSON anzeigen, nicht den vorherigen Import.
4) Fail-closed für ungelöste echte Textkonflikte unverändert beibehalten.

A) EDGE-CONFLICT PROMOTION – NUR MIT DREIFACHER EVIDENZ
- P109.0 wertete einen Kandidaten mit z. B. 1 DEU-Batchbeleg + 1 lokalem Zellbeleg bereits als Konflikt, obwohl derselbe Zieltext mehrfach sauber in derselben aktuellen Planliste vorkam.
- P109.1 darf ausschließlich bei Randinterpunktions-Alternativen einen solchen Konflikt hochstufen.
- Erforderlich sind gleichzeitig:
  a) mindestens 1 unabhängiger DEU-Batchbeleg aus dem Bild,
  b) mindestens 1 lokaler Zell-OCR-Beleg aus dem Bild,
  c) mindestens 2 gleiche Peers in der AKTUELLEN Planliste.
- Same-Plan-Peers allein korrigieren niemals einen Wert.
- Keine pauschale Satzzeichen-Trim-Regel.
- Keine Kunden-/Orts-/Zeilen-/Dateinamen-Sonderregeln.

B) PERFORMANCE – EIN KOMPOSITER DEU-BATCHLAUF
- P109.0 führte für Name/Kunde, Firma und Flugort drei getrennte volle DEU-Spalten-OCRs aus.
- P109.1 packt diese drei relevanten Spalten als schmale Segmente nebeneinander auf EIN kompaktes Batch-Canvas.
- Danach erfolgt EIN gemeinsamer DEU-PSM6-Lauf bei Scale 2.
- OCR-Wörter werden anhand ihrer Segment-X-Position wieder dem richtigen Feld und anhand Y-Geometrie der richtigen SourceRow zugeordnet.
- Nur echte Near-Conflict-/Randzeichen-/Glyphensplit-Trigger erhalten weiterhin zwei lokale Zell-Nach-OCRs.
- Ein gemeinsamer DEU-Worker wird für Batch + lokale Rechecks wiederverwendet und erst am Ende terminiert.
- Ziel: den P109.0-Overhead deutlich reduzieren, ohne die Beweisanforderungen abzusenken.

C) STAGED JSON PREVIEW
- Nach jeder erfolgreichen Analyse wird das aktuelle state.rides sofort in „Erweiterter JSON-Import“ gespiegelt – unabhängig davon, ob der Import anschließend wegen Fehler/Warnung blockiert bleibt.
- Beim Auswählen einer neuen Planliste wird die alte JSON-Vorschau zunächst geleert.
- Dadurch kann ein blockierter aktueller Lauf nicht mehr mit dem JSON eines vorherigen erfolgreichen Imports verwechselt werden.

D) SICHERHEIT / NICHT GEÄNDERT
- Unaufgelöste text_ocr-Konflikte bleiben import-blockierend.
- Diakritik-Korrektur benötigt weiterhin unabhängige Bild-OCR-Evidenz; keine ii→ü-Regel.
- Partner bleibt Alias aus customer || company und wird nach sicherer Korrektur neu synchronisiert.
- Bestehende Flug-, Zeit-, Preis-, Routen-, Fahrerfarben- und Storage-Regeln werden nicht gelockert.
- Keine alten Planlisten oder Stammdaten als versteckte Wahrheit.

GOLDEN REGRESSION – REALGERÄT
1. IMG-20261005-WA0023.jpg erneut analysieren.
2. 29/29 Fahrten müssen erhalten bleiben.
3. Der bekannte Randzeichen-Fall muss bei Bildbeleg + >=2 aktuellen Plan-Peers automatisch auf den sauberen Text korrigieren; kein text_ocr-Blocker.
4. Der bekannte Diakritik-Fall muss weiterhin sicher korrigiert werden.
5. customer und partner müssen nach Korrektur identisch korrekt sein.
6. Erweiterter JSON-Import muss bereits VOR erfolgreichem Import den AKTUELL analysierten Stand zeigen.
7. Keine legitime Interpunktion ohne die oben geforderte Bild- + Peer-Evidenz entfernen.
8. text_integrity_ocr und Gesamtzeit notieren; P109.1 muss den P109.0-Overhead deutlich reduzieren.
9. Bestehende P108.0-Regressionspunkte dürfen nicht zurückfallen.
10. Flugprüfung erst nach sauberem OCR-Gate bewerten; ein OCR-Blocker verhindert bewusst die Auto-Flugpipeline.

LOKALE VORPRÜFUNG
- node --check ocr-integrity-core.js: PASS
- node --check plan-import.js: PASS
- node --check service-worker.js: PASS
- ocr-regression-selftest.js auf rekonstruiertem Produktionspfad P107.9 -> P108.0 -> P109.0 -> P109.1: PASS
- Vollständiger Android/Gradle-Build wird wie bisher dem GitHub-Patch-Installer überlassen; dessen Clean-Build bleibt das endgültige Build-Gate.
