ATMS PRO · P98 IMPORT-INTEGRITY + ADDRESS-CANDIDATES
Datum: 2026-10-01
Verifizierte GitHub-main-Basis vor Patch: ff4186c

Enthaltene vollständige Dateien:
- android-native/app/src/main/assets/js/plan-import.js
- android-native/app/src/main/assets/js/app.js

Ziele des Patches:
1. Gültige frühe Primärzeit (00:00–05:59) wird bei widersprüchlicher Nach-OCR nicht mehr still überschrieben. Eine abweichende Nach-OCR darf nur übernehmen, wenn die unabhängige timeMirror-Zeit denselben neuen Wert bestätigt. Dadurch bleibt z. B. eine primär + gespiegelt bestätigte 01:35 erhalten und die bestehende Folgetag-Batchentscheidung kann greifen.
2. Beim Bildimport wird eine am Ende der Firma-Zelle zusammengefallene Uhrzeit generisch abgetrennt (z. B. "WT 22:25", "Get-E | 22:45"). Keine Firmen-/Zeit-Hardcodes.
3. Deutsche Route-Nach-OCR darf eine Distanz-2-Diakritikkorrektur nur bei zwei identischen Nachscans und nachweislich sehr schwachem Primärwort (<=35) übernehmen. Damit ist der belegte Typ "Novotel Kéin" -> "Novotel Köln" fail-closed lösbar, ohne Ortswörterbuch.
4. Implizite Bündelbildung ist fail-closed: getrennte Quellzeilen werden nur noch automatisch gruppiert, wenn Fahrzeug UND positiver Preis übereinstimmen. Explizite bundleStops und bestehende bekannte Reparaturpfade bleiben separat erhalten. Der belegte EW9223-Fall Van/35,72 vs Pkw/47,60 bleibt getrennt.
5. Neue persistente "Adressbuch-Kandidaten": unbekannte, nach OCR-Normalisierung verwendete Routenorte werden aus bestätigten Imports gesammelt, über Ride-Fingerprint dedupliziert und nach Abholung/Ziel gezählt. Kein automatisches Schreiben ins Adressbuch. In Einstellungen > Adressen: "+ Ins Adressbuch" öffnet nur den bestehenden Editor vorbefüllt; "Ignorieren" blendet den Kandidaten aus.
6. Kandidaten werden in bestehende Safety-/IndexedDB-Schutzschicht aufgenommen; ATMS-Backup nimmt sie automatisch mit auf, weil das Backup alle atms_-Keys sichert.
7. Kandidatensammlung ist rein additiv und darf einen erfolgreichen Planimport nicht blockieren. Bestehende Routen mit ungelöstem Zwei-Lauf-OCR-Widerspruch werden nicht als Kandidat gesammelt.

Nicht Teil dieses Patches:
- FLIGHT-008 / Flugstatus-Widerspruch 2 offen vs 4 offen
- Storage V2 Phase 2B
- destruktive Bereinigung

Lokale Vorprüfung:
- node --check app.js: OK
- node --check plan-import.js: OK
- P98 Logiktest Firma/Zeit, Frühzeit-Schutz, Bündel-Gate: OK
- P98 Route-Distanz/Confidence-Gate: OK
- Kandidaten-OCR-Konflikt-Gate: OK

Gezielter Realgerät-Beweistest nach erfolgreichem Build:
- dieselbe 13-Zeilen-Liste IMG-20261001-WA0027.jpg
- XC112 + XR6574 müssen 01:35 behalten und gemeinsam als mögliche Folgetagsfahrten 02.10.2026 bestätigt werden können
- Novotel Köln muss korrekt stehen
- Firma darf keine angehängte Uhrzeit mehr enthalten
- die zwei EW9223-Zeilen müssen getrennte Fahrten bleiben: Van/4/35,72 EUR und Pkw/2/47,60 EUR
- Adressbuch-Kandidaten zeigt nur wirklich offene, nicht eindeutig im Adressbuch/Alias vorhandene Routenorte; kein automatischer Adressbucheintrag
