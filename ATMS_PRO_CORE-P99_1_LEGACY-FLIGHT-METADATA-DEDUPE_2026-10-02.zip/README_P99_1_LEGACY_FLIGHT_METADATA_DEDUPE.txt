ATMS PRO · P99.1 LEGACY FLIGHT-METADATA DEDUPE
Datum: 2026-10-02

Basis vor Patch:
- GitHub main am 02.10.2026 frisch geprüft.
- Aktuelles raw main app.js trägt P99 SOURCE-ROW REIMPORT + DATE-SAFE BUNDLES.
- Die für P99.1 betroffenen main-Blöcke planImportSourceRowIdentity(), mergePlanImportByIdentity() und die bestehende P77/P73-Dedupe-Logik wurden frisch abgeglichen.
- Die vollständige app.js-Basis dieses Patches stammt aus dem unmittelbar zuvor gebauten P99-Patch; Header und betroffene Blöcke stimmen mit dem frisch gelesenen raw main überein.
- Kein älteres Repository-ZIP wird ungeprüft als Codebasis verwendet.

Enthaltene vollständige Datei:
- android-native/app/src/main/assets/js/app.js

Belegter Realgerät-Restfehler nach P99:
- XC112 wurde korrekt auf genau einen Eintrag 01:35 / 6 Pers. bereinigt.
- XR6574 ist nicht mehr fälschlich als 12-Personen-Bündelfahrt vorhanden und der 11:35-Altstand ist weg.
- Es bleibt jedoch genau eine ältere XR6574-Carryover-Variante zusätzlich bestehen:
  * gleicher Fahrer Daniel
  * gleiche Fahrtzeit 01:35
  * gleiche Route CGN Vorfeld -> Adagio
  * gleiche Flugnummer XR6574
  * gleicher Partner Corendon / TakeOff
  * gleiches Fahrzeug Van
  * gleiche Personen 6
  * gleicher Preis 65,45 EUR
  * Altvariante: Flugzeit 01:35, Flugort nicht verfügbar
  * aktuelle Variante: Flugzeit 02:04, Flugort Hurghada

Ziel des Patches:
1. Extrem enger Legacy-Fallback nach normalem P73/P99-Matching.
2. Nur bereits als _planCarryover=true UND _planMissingFromLatest=true markierte Altvarianten kommen in Frage.
3. Fachliche Kernidentität muss vollständig übereinstimmen:
   Flugnummer, Richtung, Fahrtzeit, Fahrer, Von, Nach, Firma/Partner, Kunde, Fahrzeug, Personen, Preis und Währung.
4. Datum darf nur identisch sein ODER exakt die bereits bestätigte Plantag->Folgetag-Korrektur einer Frühfahrt (<06:00) darstellen.
5. Die Altvariante muss nachweisbar schlechtere Flugmetadaten besitzen:
   - kein aufgelöster Flugort/IATA
   - Listen-Flugzeit fehlt oder ist exakt auf die Fahrtzeit kollabiert
   - die aktuelle Variante besitzt einen aufgelösten Flugort/IATA und eine eigene von der Fahrtzeit abweichende Listen-Flugzeit.
6. Es muss exakt EIN passender Alt-Kandidat existieren. Bei 0 oder mehreren Kandidaten: fail closed, keine Änderung.
7. Erledigte Fahrten und Bundles werden niemals automatisch entfernt.

Nicht Teil dieses Patches:
- keine breite globale Dedupe-Regel
- keine Änderung an P98/P99-Zeit-, Folgetag-, Köln-, Firma- oder Bündellogik
- keine Änderung an Adressbuch-Kandidaten / P100
- keine Änderung an FLIGHT-008
- keine Änderung an Storage V2

Lokale Vorprüfung:
- node --check app.js: OK
- synthetischer XR6574-Fall: Alt 01:35/Flugzeit 01:35/kein Flugort + Neu 01:35/Flugzeit 02:04/Hurghada -> sicherer Legacy-Treffer: OK
- legitime ältere Fahrt mit eigenständiger Flugzeit + Flugort wird geschützt: OK
- nicht passende Datumsrelation wird geschützt: OK

Gezielter Realgerät-Beweistest nach Build:
- dieselbe 13-Zeilen-Liste genau EINMAL übernehmen.
- danach nur XR6574 prüfen.
- Soll: genau ein XR6574-Eintrag, 01:35, Daniel, CGN Vorfeld -> Adagio, Van, 6 Pers., 65,45 EUR, Flugzeit 02:04, Hurghada.
- kein zweiter XR6574-Eintrag mit Flugzeit 01:35 / Flugort nicht verfügbar.
- Gesamtbestand soll sich gegenüber dem Zustand vor diesem Reimport um genau diese eine Restdublette reduzieren, sofern keine andere unabhängige Änderung stattfindet.
