ATMS PRO · CORE-007D8A1F1D8P1092D
P109PERF WORKER-LIFECYCLE DIAGNOSTIC ONLY
Date: 06.10.2026

BASE
- Prepared from the freshly downloaded GitHub main archive after the user verified main HEAD d956b7d in GitHub.
- The archive itself does not embed a Git commit object; its production markers are P109.2 (index CORE-007D8A1F1D8P1092, service-worker p1092, plan-import P1092 edge-consensus header).

PURPOSE
- Diagnose the reproducible WA0023 OCR performance regression only.
- Adds read-only P109Perf timing output to the existing OCR self-check.
- Assigns diagnostic IDs OCR-W1, OCR-W2, ... to observed OCR calls.
- One-shot Tesseract.recognize calls record total time, time before first 'recognizing text' status, active-recognition tail, image size, phase/mode and lifecycle status timestamps.
- The existing explicit DEU Text Integrity worker records createWorker, setParameters, recognize/reuse and terminate timings separately.

INSTRUMENTED PHASES
- primary_ocr
- early_time_batch_ocr
- price_targeted_ocr
- route_deu_column_ocr
- driver_deu_column_ocr
- text_integrity_ocr
- missing_flight_targeted_ocr

NON-GOALS / SAFETY
- NO performance optimization is included.
- NO OCR crop, language, consensus threshold or correction rule is changed.
- NO customer, place, row, flight, date or filename hardcode is added.
- P109.2 Avion edge consensus and Schuetz/diacritic consensus remain unchanged.
- P108 time fail-closed logic remains unchanged.
- FLIGHT-008, PLAN/DISPO/LIVE, colors, import/dedupe, Storage V2 and persistence remain unchanged.

VISIBLE VERSION
- About/version marker becomes CORE-007D8A1F1D8P1092D solely to distinguish the diagnostic APK.
- Service-worker cache key/query changes only to force delivery of the diagnostic JavaScript.

REAL-DEVICE TEST
1. Install diagnostic APK over current ATMS PRO.
2. Analyze IMG-20261005-WA0023.jpg once.
3. Do not manually alter rides or OCR fields.
4. Copy/send the OCR self-check line containing BOTH:
   P54Perf=[...]
   P109Perf=[...]
5. The test must still show 29/29, 0 hints, 0 OCR errors, Avion corrected and Schuetz corrected.

LOCAL VALIDATION BEFORE PACKAGING
- node --check plan-import.js: PASS
- node --check service-worker.js: PASS
- android-native/tools/ocr-regression-selftest.js: PASS
