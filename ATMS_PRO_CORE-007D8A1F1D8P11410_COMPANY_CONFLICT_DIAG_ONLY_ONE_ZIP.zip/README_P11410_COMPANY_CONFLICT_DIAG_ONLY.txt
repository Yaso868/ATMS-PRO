ATMS PRO CORE-007D8A1F1D8P11410 – Company OCR conflict observability only

Scope: no OCR crop, OCR mode, worker invocation, original pixel, route,
company-normalization, flight verification, conflict decision, fail-closed import
gate, backup or ride persistence is changed.

The diagnostic reports each unresolved company conflict from the real on-device
production run with source row, primary and secondary values, actual OCR cell
attempts, primary provenance, peer counts and safety vetoes. The P114.9 adaptive
source-tail OCR function records exactly why it did not run or which modes ran.
The report appears below the OCR issues in the collapsible 'P114.10 Firmenkonflikt'
section; the copy button copies the JSON diagnostic for sharing in chat.

Test status: 18 mandatory JavaScript preBuild tasks including the unchanged
P114.9 source-truth veto and import validations; extra P114.10 side-effect
comparison uses an exact copy of P114.9's production implementation in the
test fixtures folder. Original 9MB image replay remains unchanged and protected.

Installer: single ZIP in the repository root; SHA256.txt lists all payload files.
Use the same existing 'ATMS PRO Native APK + Patch Installer' GitHub Actions.
Do not import the 07.10.2026 planlist until the root-cause investigation is complete.
GitHub main HEAD must be freshly verified before uploading this candidate.
