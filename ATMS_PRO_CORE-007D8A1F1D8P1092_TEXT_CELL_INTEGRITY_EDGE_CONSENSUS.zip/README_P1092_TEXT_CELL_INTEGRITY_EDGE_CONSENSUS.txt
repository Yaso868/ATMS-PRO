ATMS PRO · P109.2 · Text Cell Integrity Edge Consensus
Datum: 05.10.2026

SOURCE OF TRUTH
- Zuletzt im laufenden GitHub-/Realgerät-Ablauf verifizierter Produktions-HEAD: 9734c4b
- Commit-Titel: Apply validated ATMS patch: ATMS_PRO_CORE-007D8A1F1D8P1091_TEXT_CELL_INTEGRITY_FOLLOWUP
- Parent/Upload-Commit: 8a3c0e3
- P109.1 Workflow #178: SUCCESS; APK-Artefakt erstellt und auf Realgerät installiert.
- P109.2 wurde ausschließlich aus dem validierten P109.1-Payload weiterentwickelt; keine ältere ZIP wurde als Wahrheit verwendet.

REALGERÄT-BEWEIS P109.1 · IMG-20261005-WA0023.jpg
- 29/29 Fahrten erkannt.
- Diakritik-Fall: Primär-OCR Schiitz, DEU-Batch + zwei lokale DEU-Zell-OCRs Schütz; final customer=Schütz, partner=Schütz. PASS.
- Randzeichen-Fall: Primär-OCR enthält ein führendes Fremdzeichen; zwei lokale DEU-Zell-OCRs lesen denselben sauberen Zieltext, fünf weitere aktuelle Planzeilen tragen denselben sauberen Zieltext.
- Der einzelne kompakte DEU-Batchlauf liest in genau dieser Zeile einen dritten, nahen Kandidaten und P109.1 bleibt deshalb fail-closed.
- Sicherheitsverhalten korrekt: 1 Fehler, Import blockiert, aktuelles staged JSON sichtbar.
- Laufzeit: gesamt 12.147 ms; text_integrity_ocr 1.818 ms. Performance-Ziel P109.1 bestanden.

P109.2 ZIEL
Den verbleibenden generischen Randzeichen-Konflikt sicher auflösen, ohne Batch-OCR zur Pflicht zu machen, wenn zwei voneinander verschiedene lokale Bild-OCR-Konfigurationen einstimmig denselben sauberen Randzeichen-Kandidaten liefern und mindestens zwei gleiche Peers in der AKTUELLEN Planliste existieren.

A) GENERISCHE EDGE-CONSENSUS-REGEL
Eine Konflikt-Korrektur darf nur hochgestuft werden, wenn ALLE folgenden Bedingungen erfüllt sind:
1. Original und Kandidat unterscheiden sich ausschließlich durch die bereits generisch definierte Randinterpunktions-Klasse.
2. Der Kandidat ist nach den bestehenden Text-Integrity-Regeln eine sichere Near-Alternative.
3. Mindestens zwei lokale OCR-Lesungen aus unterschiedlichen OCR-Modi/Crop-Konfigurationen liefern exakt denselben Kandidaten.
4. Es gibt keine konkurrierende nicht-leere lokale OCR-Lesung.
5. Der kompakte Batchlauf stimmt NICHT für den ursprünglichen fehlerhaften Wert.
6. Mindestens zwei gleiche Peers mit demselben Kandidaten existieren in der AKTUELLEN Planliste.
7. Same-Plan-Peers allein dürfen niemals korrigieren.

Der bestehende P109.1-Pfad bleibt unverändert gültig:
- 1 Batchbeleg + 1 lokaler Beleg + >=2 aktuelle Peers reicht weiterhin für reine Randzeichen-Konflikte.

B) FAIL-CLOSED-GRENZEN
- Batch stimmt für den ursprünglichen Wert -> keine automatische Korrektur.
- Lokale OCRs widersprechen sich -> keine automatische Korrektur.
- Nur ein lokaler Beleg -> keine automatische Korrektur.
- Weniger als zwei aktuelle Plan-Peers -> keine automatische Korrektur.
- Nicht reine Randinterpunktions-Alternative -> P109.2-Sonderpfad greift nicht.
- Diakritik-/Glyphensplit-Korrekturen behalten die strengere bestehende Bildkonsens-Logik.

C) DIAGNOSE
- Neuer Korrekturpfad wird als `deu_dual_local_cell_plus_same_plan_edge_consensus` gekennzeichnet.
- Evidence enthält `edgePromotionMode=dual_local_peers` und `samePlanPeerCount`.
- Roh-OCR bleibt in *RawOcr erhalten.

D) NICHT GEÄNDERT
- P109.1 Composite-DEU-Batch-Performance bleibt erhalten.
- Staged JSON wird auch bei blockiertem Import aktuell angezeigt.
- Flug-, Zeit-, Preis-, Routen-, Fahrerfarben-, Storage- und Archivregeln werden nicht gelockert.
- Keine Kunden-/Orts-/Zeilen-/Dateinamen-Hardcodes.
- Keine alten Planlisten, Stammdaten oder Wörterbücher als versteckte Wahrheit.

GOLDEN REGRESSION · REALGERÄT
1. IMG-20261005-WA0023.jpg erneut analysieren.
2. 29/29 Fahrten müssen erhalten bleiben.
3. Der Randzeichen-Fall muss auf den sauberen Text korrigiert werden, wenn zwei lokale Bild-OCRs + >=2 aktuelle Peers übereinstimmen.
4. Der Diakritik-Fall muss weiterhin final korrekt in customer UND partner stehen.
5. 0 Text-OCR-Fehler für diese beiden bestätigten Fälle; ungelöste echte Konflikte bleiben blockierend.
6. Erweiterter JSON-Import muss den aktuellen Analysestand zeigen.
7. text_integrity_ocr und Gesamtzeit protokollieren; P109.1-Geschwindigkeitsklasse soll erhalten bleiben.
8. Keine legitime Interpunktion ohne die vollständige Edge-Konsens-Evidenz entfernen.
9. Bestehende P108.0/P109.0/P109.1-Regressionspunkte dürfen nicht zurückfallen.
10. Flugprüfung erst nach sauberem OCR-Gate bewerten.

LOKALE VORPRÜFUNG
- node --check ocr-integrity-core.js: PASS
- node --check plan-import.js: PASS
- node --check service-worker.js: PASS
- ocr-regression-selftest.js auf rekonstruiertem Produktionspfad P107.9 -> P108.0 -> P109.0 -> P109.1 -> P109.2: PASS
- Vollständiger Android/Gradle-Build bleibt Aufgabe des GitHub-Patch-Installers und ist das endgültige Build-Gate.
