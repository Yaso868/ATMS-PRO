ATMS PRO · P104 · ARCHIV-BROWSER READ-ONLY
Datum: 02.10.2026
Basis: frisch heruntergeladener GitHub-main nach P103 / finalem Bot-Commit 04e451f.

ZIEL
- Bereits verifizierte .atmsarchive-Dateien aus dem persistenten Android-Archivordner direkt in ATMS ansehen.
- Reine READ-ONLY-Anzeige; keinerlei Wiederherstellung oder Mutation.

NATIVE SICHERHEIT
- Exakter Dateiname im dauerhaft freigegebenen SAF-Archivordner.
- Nur lokale ATMS-App-Origin erlaubt.
- Nur .atmsarchive ohne Pfadbestandteile.
- Maximal 8 MiB für Direktansicht.
- Native Rückgabe enthält Byteanzahl + Datei-SHA-256 + Base64-Daten.

JS-VERIFIKATION VOR ANZEIGE
- Datei-SHA-256 muss exakt dem verifizierten Archivkatalog entsprechen.
- Byteanzahl muss dem Katalog entsprechen.
- ATMS_ARCHIVE Format / Version / Schema wird erneut geprüft.
- interne Payload-SHA-256 wird erneut berechnet und geprüft.
- Archivdatum, rideCount, doneCount und payloadSha256 müssen dem Katalog entsprechen.
- Erst danach wird die Fahrtliste angezeigt.

UI
- Verifizierte Archive im persistenten Archivordner erhalten:
  "👁 Archiv ansehen · READ-ONLY"
- Vollbild-Archivansicht mit Datum, Fahrten-/Erledigt-Zahl, Dateiprüfung und Fahrtenkarten.
- Android-Zurück schließt zuerst den Archiv-Browser.
- Legacy/Save-Dialog-Katalogeinträge ohne persistenten Ordner bleiben sichtbar, erhalten aber keinen Direktansicht-Button.

NICHT GEÄNDERT
- keine Wiederherstellung von Archivfahrten
- keine Löschung von Archiv- oder aktiven Daten
- keine Änderung an aktuellen Fahrten / DONE / Overrides
- keine Änderung an Storage-V2-Synchronisierung
- keine Änderung an P103 Bereinigung
- keine Änderung an P102/P101/P100
- keine Änderung an OCR, Import/Dedupe, Bundles, PLAN/DISPO/LIVE, FLIGHT-008

LOKALE PRÜFUNGEN
- node --check app.js: BESTANDEN
- Android-Vollbuild lokal nicht ausgeführt, weil das Repository keinen gradlew-Wrapper enthält.
  Verbindlicher Build-Beweis erfolgt wie üblich über den GitHub Native-Patch-Installer.
