ATMS PRO P11447 / QA2 / 2026-10-23
SINGLE ZIP - FAIL CLOSED RELEASE GUARD
BASE COMMIT 6cea5386074b9744a255bfd9eed19172a1c838aa / branch atms-price-p11429-test-only ONLY.
Only change on upload commit must be this one .zip file.
P11447 OCR fix + 39 positive, 12 negative source tests.
Version-specific P11447 asset alignment/signing guards retain P11446 test assertions.
Historical P11445/P11446 geometry tests remain preBuild-required.
NO real user imagery, no data persistence/import, no main writes.
NEVER INSTALL until GitHub CI and APK SHA/certificate are checked.
NO manual source edits on GitHub.
R2: fixes historical H35 version pin from exact P11446 to exact P11447. Other historical byte-exact SHA1 pins/order/read-only checks and subprocesses remain. New negative runtime-version controls mandatory in preBuild.
R3: legacy P11444 real-function fixture adapted only to production P11447 mandatory worker injection. Original 82 negative gates and 22 source rows unchanged, local 302/82 PASS. Full CI preBuild and signed APK remain mandatory.
