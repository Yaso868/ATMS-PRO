ATMS PRO P11435 – ZIELGENAUER LOKALER COMPANY-SOURCE-PIXEL-OCR FIX
Basis: GitHub-Testbranch-HEAD 6fd8622c5c09d5650594bdea085518691e8506a5 (nur READ-ONLY verifiziert).
SOURCE_VERSION=11434, TARGET_VERSION=11435, versionCode 12; keine GitHub-/APK-/Samsung-Aktion durch Erstellung.
Ausschliesslich originalfarbige Firmenzellen in den bestaetigten Vollzellen-/adaptive-Company-PSM6+PSM7-OCR-Nachansichten werden pixelweise in Graustufen umgewandelt.
Quellpixel-Crop-Masse/Zeile/Spalte bleiben erhalten; kein Text wird normalisiert, kein Name erzwungen; bei nicht lesbaren Canvas-Pixeln altes Fail-Closed Verhalten.
Firmen-Veto, SOURCE-Gates, flightLocation, Preis, Fahrer, Orte, Import, Storage, App.js und historischer OCR-Core bleiben unveraendert.
Enthaelt Additiv-Gate p11435CompanyPixelSafetyGate und aktuelle Runtime-Assetversion P11435.
Bild-Experiment mit ORIGINAL-19.10.2026 (lokal, NICHT im Installer): 3 Get-E-Zellen x2 PSM = 6/6 korrekt als Get-E; synthetische GetE/GetZ/Get-A-Gegenproben 6/6 korrekt. System-Tesseract ist NICHT Tesseract.js auf Android.
KEIN E2E-Geräte-PASS, KEIN gesamter 43/43-Gradle-CI-PASS, KEINE Importfreigabe.
