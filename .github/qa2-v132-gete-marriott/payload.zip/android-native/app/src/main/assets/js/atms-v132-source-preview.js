/* ATMS PRO V1.32 / STUFE 1: source-evidence-only preview. NO import, storage, network, OCR corrections. */
(function(global){
 'use strict';
 const FIELDS=Object.freeze(['price','time','pickup','destination','customer','company','arrivalFlight','departureFlight','vehicle','persons','flightTime','flightLocation','driver']);
 const IDENT=Object.freeze(FIELDS.filter(k=>k!=='flightTime'));
 const norm=v=>String(v??'').replace(/\s+/g,' ').trim();
 const cancel=v=>/^(?:storno|storniert|cancelled|canceled)$/i.test(norm(v));
 const clock=v=>/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(norm(v));
 const flightTime=v=>norm(v)===''||clock(v)||cancel(v);
 // Compare evidence without changing any of the thirteen photographed fields.
 // Whitelisted OCR BORDER noise is permitted only in the ride time and the
 // punctuation of a known 2-decimal euro amount; other identity fields stay exact.
 const clockKey=v=>norm(v).replace(/^\|\s*(?=\d{2}:\d{2}$)/,'');
 const priceKey=v=>{
   const raw=norm(v);
   if(!/^(?:\d{1,3}(?:[. ]\d{3})*|\d{1,7})(?:,\d{2})?\s*€$/.test(raw))return raw;
   const digits=raw.replace(/[^0-9]/g,'');
   // Reject guesses about integer-only amounts: four digits are ambiguous
   // without a comma. Match only if the other photo supplies a 2-decimal value.
   return digits.length>=3 && digits.length<=9 ? digits : raw;
 };
 const comparablePrice=(a,b)=>{
   const x=norm(a),y=norm(b);
   if(x===y)return Boolean(x);
   // OCR may miss the entire price in one of the two photographs. Only
   // accept the other photograph's unambiguous 2-decimal amount when
   // ALL other booking-identity fields and bounded overlap are proven.
   // The empty source cell remains unchanged in the raw evidence.
   if(!x||!y)return /^(?:\d{1,3}(?:[. ]\d{3})*|\d+),\d{2}\s*€$/.test(x||y);
   const comma=x.includes(',')||y.includes(',');
   return comma && priceKey(x)===priceKey(y) && /^\d{3,9}$/.test(priceKey(x));
 };
 const identity=r=>JSON.stringify(IDENT.filter(k=>k!=='price' && k!=='time')
   .map(k=>norm(r.fields[k])).concat(clockKey(r.fields.time)));

 const values=r=>JSON.stringify(FIELDS.map(k=>norm(r.fields[k])));
 const valid=r=>Boolean(r&&Number.isSafeInteger(r.sourceRow)&&r.sourceRow>0&&
   Number.isSafeInteger(r.partIndex)&&r.partIndex>=0&&r.fields&&typeof r.fields==='object'&&
   FIELDS.every(f=>typeof r.fields[f]==='string'));
 function markRaw(r){return {...r,status:cancel(r?.fields?.flightTime)?'storno_offen':'ungeprüft'};}
 function blocked(records,reason,details=[]){return {ok:false,reason,visible:records.map(markRaw),
   suppressed:[],duplicates:0,stornos:0,conflicts:details};}
 function compatibleTime(a,b){
   const t1=norm(a.fields.flightTime),t2=norm(b.fields.flightTime);
   if(!flightTime(t1)||!flightTime(t2))return false;
   if(t1===t2)return true;
   // A later photograph may contain a value that was empty in the first photo.
   // Keep that ORIGINAL PHOTO RECORD intact; never synthesize a new cell value.
   return (t1===''&&t2!=='')||(t2===''&&t1!=='');
 }
 function plausible(r){
   const f=r.fields;
   return clock(clockKey(f.time))&&Boolean(norm(f.pickup))&&
     Boolean(norm(f.destination))&&Boolean(norm(f.customer))&&Boolean(norm(f.company))&&
     Boolean(norm(f.driver))&&Boolean(norm(f.vehicle))&&/^\d+$/.test(norm(f.persons))&&
     Boolean(norm(f.arrivalFlight)&&norm(f.arrivalFlight)!=='-'||norm(f.departureFlight)&&norm(f.departureFlight)!=='-');
 }
 function reconcile(records){
   if(!Array.isArray(records)||!records.length||records.length>250||!records.every(valid))
     return blocked(Array.isArray(records)?records:[], 'source_part_or_row_unproven');
   // Two independently geometrically bounded photographs, NOT an assumed textual overlap.
   const parts=[...new Set(records.map(r=>r.partIndex))].sort((a,b)=>a-b);
   if(parts.length!==2)return blocked(records,'two_bounded_photos_required');
   // Photos can arrive in Android SAF order or be deliberately re-ordered for
   // OCR header detection. Source-image index is NOT chronological order.
   // The proven global physical sourceRow comes from the composed image raster.
   const perPart=parts.map(p=>records.filter(r=>r.partIndex===p).sort((a,b)=>a.sourceRow-b.sourceRow))
     .sort((a,b)=>a[0].sourceRow-b[0].sourceRow);
   if(perPart.some(x=>x.some((r,i)=>i&&r.sourceRow===x[i-1].sourceRow)))
     return blocked(records,'duplicate_physical_row_coordinates');
   if(perPart[0].at(-1).sourceRow>=perPart[1][0].sourceRow)
     return blocked(records,'interleaved_source_part_geometry');
   const groups=new Map();
   for(const r of records){const key=identity(r);const g=groups.get(key)||[];g.push(r);groups.set(key,g)}
   const pairs=[];
   for(const group of groups.values()){
     if(group.length===1)continue;
     // Never infer a repeated booking within the SAME photographed row band.
     if(group.length!==2||group[0].partIndex===group[1].partIndex)
       return blocked(records,'ambiguous_same_photo_or_many_identical_bookings',group.map(r=>({sourceRow:r.sourceRow,partIndex:r.partIndex})));
     const [a,b]=group.sort((x,y)=>x.sourceRow-y.sourceRow);
     if(!plausible(a)||!plausible(b)||!comparablePrice(a.fields.price,b.fields.price)||!compatibleTime(a,b))
       return blocked(records,'unverified_source_field_or_time_difference',[{rowA:a.sourceRow,rowB:b.sourceRow}]);
     pairs.push([a,b]);
   }
   // At least two adjacent-in-sequence independent matches provide overlap context.
   // One identical entry by itself is not evidence of a repeated screenshot.
   if(pairs.length<2)return blocked(records,'insufficient_overlap_evidence');
   pairs.sort((x,y)=>x[0].sourceRow-y[0].sourceRow);
   for(let i=1;i<pairs.length;i++)if(pairs[i][1].sourceRow<=pairs[i-1][1].sourceRow)
     return blocked(records,'crossing_or_reordered_row_pairs');
   // The overlap must reach the end of the first and the start of the second image.
   if(pairs.at(-1)[0].sourceRow!==perPart[0].at(-1).sourceRow ||
      pairs[0][1].sourceRow!==perPart[1][0].sourceRow)
     return blocked(records,'non_boundary_overlap');
   // A continuation photo begins with a repeated prefix. Any unmatched row
   // INSIDE that repeated prefix might be a changed passenger booking, not a
   // new entry. Reject the WHOLE deduplication rather than hide some matches.
   const repeatedSecond=new Set(pairs.map(pair=>pair[1].sourceRow));
   const secondPrefix=perPart[1].filter(r=>r.sourceRow<=pairs.at(-1)[1].sourceRow);
   if(secondPrefix.some(r=>!repeatedSecond.has(r.sourceRow)))
     return blocked(records,'unmatched_or_changed_row_inside_repeat_prefix');
   // Unmatched first-photo rows may be real orders absent from the continuation.
   // Keep every one of them unchanged.
   const suppressed=new Map(),replacements=new Map(),notes=[];
   for(const [a,b] of pairs){
     let retained=a,other=b;
     const aTime=norm(a.fields.flightTime),bTime=norm(b.fields.flightTime);
     if(!aTime&&bTime){retained=b;other=a}
     else if(aTime&&!bTime){retained=a;other=b}
     else if(aTime===bTime){
     // Prefer the photographed row containing the evidenced decimal
     // price; do not synthesize a value into the blank other row.
     retained=norm(a.fields.price)?a:b;other=retained===a?b:a;
   }
     const status=cancel(retained.fields.flightTime)?'storniert':'aktiv';
     // Immutable, in-memory evidence of both ORIGINAL photo rows. Suppressed
     // means hidden from the distinct-booking view, never discarded.
     suppressed.set(other.sourceRow,{sourceRow:other.sourceRow,partIndex:other.partIndex,
       fields:{...other.fields},keptSourceRow:retained.sourceRow,
       reason:'bounded_monotonic_cross_photo_overlap',retainedPart:retained.partIndex});
     replacements.set(retained.sourceRow,{...retained,status,overlapSources:[a.sourceRow,b.sourceRow]});
     notes.push({rowA:a.sourceRow,rowB:b.sourceRow,chosenRow:retained.sourceRow,
       originalTimeA:aTime,originalTimeB:bTime,originalPriceA:a.fields.price,
       originalPriceB:b.fields.price,status});
   }
   const visible=records.filter(r=>!suppressed.has(r.sourceRow)).map(r=>
     replacements.get(r.sourceRow)||({...r,status:cancel(r.fields.flightTime)?'storno_offen':'aktiv'}))
     .sort((a,b)=>a.sourceRow-b.sourceRow);
   if(visible.length+suppressed.size!==records.length)
     return blocked(records,'conservation_count_failed');
   const orphanStorno=visible.filter(r=>r.status==='storno_offen');
   if(orphanStorno.length)return blocked(records,'unproven_single_storno',orphanStorno.map(r=>r.sourceRow));
   return {ok:true,reason:'verified_geometric_monotonic_overlap',visible,
     suppressed:[...suppressed.values()],duplicates:suppressed.size,
     stornos:visible.filter(r=>r.status==='storniert').length,conflicts:[],pairs:notes,
     inputCount:records.length,keptCount:visible.length};
 }
 function partOfRow(sourceRow,meta,parts,scaledWidth,combinedWidth){
   const row=meta?.rowMetaByMatrixIndex?.[sourceRow-1];
   const factor=Number(scaledWidth)/Number(combinedWidth);
   if(!row||!Number.isFinite(factor)||!(factor>0)||!Array.isArray(parts)||
     !parts.length||!Number.isFinite(Number(row.y0))||!Number.isFinite(Number(row.y1))||
     !(Number(row.y1)>Number(row.y0)))return -1;
   const hits=parts.filter(p=>Number.isInteger(Number(p.sourceIndex))&&
     Number(row.y0)>=Number(p.y0)*factor+0.5&&
     Number(row.y1)<=Number(p.y1)*factor-0.5);
   return hits.length===1?Number(hits[0].sourceIndex):-1;
 }
 global.ATMSV132SourcePreview=Object.freeze({FIELDS,reconcile,partOfRow,cancel});
})(window);
