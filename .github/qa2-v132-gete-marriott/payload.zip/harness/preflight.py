#!/usr/bin/env python3
# Fail-closed, read-only provenance verification and byte-exact two-file overlay
# on ephemeral runner. Does not write GitHub or touch phones.
import hashlib, json, os, pathlib, subprocess, sys, zipfile
BASE='0d1c689eaf0a517506e6aec4c3bcc6824e46663d'
WF='.github/workflows/atms-v132-gete-marriott-qa2-once-20261027.yml'
PAYLOAD='.github/qa2-v132-gete-marriott/payload.zip'
ROOT_SHA='daa0f2803c3c2cc7ceeed9c9a8dc95a5e21f3a53ae52aaff88bf4c0e7dcd776e'
BASE_JS='5f0bb740a4732b4208f371dc2d897646ab43eb9cfaf9c997486936ca46b3fac9'
OUT_JS='1581b1bf454fa06c91815380b59201b9e44601ceff16318dc1a1a2c2b632040d'
PREVIEW='1590651f756d06a612ab9a86e926d8fa28dbe0250632a4b66caa0a675a79c1f9'
SRC='android-native/app/src/main/assets/js/plan-import.js'
PREV='android-native/app/src/main/assets/js/atms-v132-source-preview.js'
FILES=['harness/adapter-vm-inject.js','harness/qa2-p11447-prebuild.init.gradle',SRC,PREV]
def sha(data):return hashlib.sha256(data).hexdigest()
def fatal(s):raise SystemExit('FAIL-CLOSED QA2: '+s)
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
def main():
    if len(sys.argv)!=3:fatal('usage: preflight.py REPO ROOT_OF_EXTRACTED_PAYLOAD')
    repo=pathlib.Path(sys.argv[1]).resolve(); extracted=pathlib.Path(sys.argv[2]).resolve()
    if os.environ.get('GITHUB_REPOSITORY')!='Yaso868/ATMS-PRO':fatal('incorrect repository')
    if os.environ.get('GITHUB_EVENT_NAME')!='push':fatal('not a narrowly scoped push event')
    if os.environ.get('GITHUB_REF')!='refs/heads/atms-price-p11429-test-only':fatal('incorrect test branch')
    if os.environ.get('GITHUB_RUN_ATTEMPT')!='1':fatal('no reruns without new approval')
    if os.environ.get('GITHUB_EVENT_BEFORE')!=BASE:fatal('unexpected previous commit')
    head=git(repo,'rev-parse','HEAD')
    if head!=os.environ.get('GITHUB_SHA'):fatal('checkout head mismatch')
    if git(repo,'rev-parse','HEAD^')!=BASE:fatal('branch has changed from approved base')
    changed=subprocess.check_output(['git','-C',str(repo),'diff','--name-status',BASE,head],text=True).splitlines()
    if sorted(changed)!=sorted(['A\t'+WF,'A\t'+PAYLOAD]):fatal('unexpected committed file changes: '+str(changed))
    if git(repo,'status','--porcelain'):fatal('checkout contains unexpected edits')
    if sha((repo/'android-native/app/build.gradle').read_bytes())!=ROOT_SHA:fatal('Gradle baseline mismatch')
    if sha((repo/SRC).read_bytes())!=BASE_JS:fatal('GitHub JS baseline mismatch')
    if (repo/PREV).exists():fatal('existing preview cannot be replaced without its own reviewed baseline')
    for name in FILES:
        if not (extracted/name).is_file():fatal('missing payload file '+name)
    if sha((extracted/SRC).read_bytes())!=OUT_JS:fatal('correction SHA drift')
    if sha((extracted/PREV).read_bytes())!=PREVIEW:fatal('preview SHA drift')
    for n in [SRC,PREV]:
        p=repo/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((extracted/n).read_bytes())
    if sha((repo/SRC).read_bytes())!=OUT_JS or sha((repo/PREV).read_bytes())!=PREVIEW:fatal('overlay write verification failed')
    print('PASS: pinned parent SHA, EXACT TWO .github files changed, expected Gradle and JS, runtime overlay only')
if __name__=='__main__':main()
