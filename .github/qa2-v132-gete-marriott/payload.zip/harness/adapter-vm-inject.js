'use strict';
/* HARNESS-ONLY diagnostic adapter. Not part of ATMS PRO product or historical tests.
 * Loads IDENTICAL FUNCTION BODIES from the selected immutable local product source
 * into historical isolated vm tests without editing either source or test files.
 * No `GetE` rewriting, assertion changing, IO of private images or hidden bypasses.
 */
const fs = require('node:fs');
const vm = require('node:vm');
const crypto = require('node:crypto');
const realRun = vm.runInContext;
const kind = process.env.ATMS_HARNESS_TARGET;
const file = process.env.ATMS_HARNESS_SOURCE;
if (!['P11435','P11447'].includes(kind) || !file || !fs.statSync(file).isFile()) {
  throw new Error('explicit harness target and local source file are mandatory');
}
const originalSource = fs.readFileSync(file,'utf8');
const definitions = {
  P11435:['p11447TextCellOcrParameters'],
  P11447:['p11444OneMissingCompanyHyphen','p11444CompanyDelimiterProbe']
};
function exactFunction(name){
  const pattern = new RegExp('^  (?:async )?function '+name+'\\(', 'm');
  const m=pattern.exec(originalSource);
  if(!m) throw new Error('Missing exact function: '+name);
  const end=originalSource.indexOf('\n  }', m.index);
  if(end<0) throw new Error('Missing closing scope: '+name);
  return originalSource.slice(m.index,end+4);
}
const applicable = definitions[kind].every(name => originalSource.includes('  function '+name+'('));
const code=applicable ? definitions[kind].map(exactFunction).join('\n') : '';
if(!applicable && kind!=='P11447') throw new Error('Unexpected missing dependency in '+kind);
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
let inserted=0;
vm.runInContext = function runWithHarnessOnlyDependencies(sandboxCode, context, options){
  const matched=(kind==='P11435' ? sandboxCode.includes('this.TEST={')
       : sandboxCode.includes('this.testFunctions={') && sandboxCode.includes('async function p11444ReconcileSourceCells('));
  if(!matched || !applicable) return realRun.call(vm, sandboxCode, context, options);
  inserted++;
  if(kind==='P11435' && inserted>1) throw new Error('Refuse repeated P11435 harness injection');
  // Build actual function definitions as imported dependencies in the isolated VM.
  // The source for all functions comes from the exact local tested application version.
  return realRun.call(vm, code+'\n'+sandboxCode, context, options);
};
process.on('exit',()=>{
  console.error('HARNESS-ONLY ADAPTER '+kind+': '+inserted+' injection(s), functions=['+
    definitions[kind].join(',')+'], bodies_sha256='+sha(code)+', source_sha256='+sha(originalSource)+
    ', applicable='+applicable+', no source or historical test edits');
  if(applicable && inserted<1) process.exitCode=1;
  if(!applicable && inserted!==0) process.exitCode=1;
});
