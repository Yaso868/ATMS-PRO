ATMS PRO P114.22 – GitHub Actions #231 Build-Reparatur (09.10.2026)

Nur der vorbestehende isolierte Laufzeittest android-native/tools/plan-import-runtime-smoke-p11331.js wurde aktualisiert. Er laedt nun die echten Diagnose-Hilfsfunktionen resetPreviewFlightDiagnostic und syncPreviewFlightCheckControl aus plan-import.js, ohne sie zu stubben, und stellt die benoetigten DOM style/hidden-Eigenschaften sowie den importgesperrten Testzustand bereit. Der aus P114.22 resultierende ReferenceError im Gradle preBuild-Smoketest ist so in der lokalen produktionsgleichen Laufzeitkopie behoben.

Unveraendert: alle 7 bisherigen P114.22-Payload-Dateien, alle Flug- und OCR-Regeln, die Importlogik und alle Bestandsfahrten. Die originale SHA256-Watch-Liste und das P114.21-Baseline-Gate bleiben aktiv.

Freigabe: Nutzer hat ausdruecklich JETZT PATCHEN gesagt. Die APK und GitHub Actions sind nach dem Upload noch NICHT bestaetigt.
