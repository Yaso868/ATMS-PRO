ATMS PRO P114.22 · FLUGPRUEFUNG OHNE IMPORT · 09.10.2026

Quellstand: GitHub main HEAD laut oeffentlicher Commit/HEAD.patch 28fd0842fa7ee2148137bf72817641b196713155 (P114.21 GitHub-Actions-Auto-Apply), 629 Commits. BASE_COMMIT ist exakt dieser frisch verifizierte Hauptzweig-HEAD vor Erstellung des P114.22-Patches. GitHub-Installer verlangt echte Source-Version P11421 und SHA256 aller 5 Dateien plus 7 unveraenderte Watch-Dateien; bei irgendeiner Abweichung STOPP VOR Ueberschreiben.

Feature: Ausschliesslich nach expliziter importfreier Testanalyse erscheint 'Fluege pruefen - garantiert ohne Fahrtenimport'. Die nativen Airport-/FlightStats-Zweitquellen werden ohne Gemini-/Kostenaufruf gegen einen isolierten Snapshot ausgefuehrt; Routenkonflikte bleiben offen, Zwei-Quellen-Status wird nur mit Datum, identischer IATA-Route und unabhaengigen Quellen vergeben. Ergebnisse werden nur separat angezeigt; WEDER Flugorte noch Fahrten, Storage, JSON oder Import-Historie werden veraendert. LO405 wird nicht zu LO406 korrigiert. Bei Dateiauswahl, Datums- oder Analysewechsel / geaenderter Zeile werden veraltete Ergebnisse verworfen. Manuelle/automatische Importe bleiben im Testmodus gesperrt. Anzeige 'Bereit zur Uebernahme' im Testmodus wird korrigiert.

Neu: 16/16 ausfuehrbare Flight-Preview-VM-Regressionstests, 8/8 P114.21 Preview/Datumschecks, Runtime-Asset-Alignment PASS; alle historisch aktiven GitHub-preBuild-Gates bleiben aktiv, neuer P114.22-Regressionstest wird zusaetzlich zwingend.

NICHT nachgewiesen in dieser lokalen Sitzung: Github Actions Build, Signierung oder Realgeraet P114.22. Beides erfolgt erst nach Nutzer-Upload. 34 Fahrten 09.10. NICHT importieren; 5 aktuelle / 82 aeltere Fahrten nicht veraendern. GE67 nicht als behoben einstufen.
