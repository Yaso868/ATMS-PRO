ATMS PRO P11434-R4 — LOCAL TEST ADAPTER ONLY. NOT GITHUB, NOT APK.
BASE: P11434-R3 verified SHA256 1b3028156285017328e7d456bebc0e477b356cd83266b215ddd8bf9276fd690d.
Only added to payload: historical android-native/tools/route-g4-final-integrity-p11431.cjs.
Change in historical test ONLY: include real unmodified routeG4VerifiedFinalHandoff in its isolated VM alongside markZeroSilentErrorIntegrity.
Preserves all original 12 positive and negative test cases. No mock of new helper. Runtime production JS, app layout, company/price, storage, flights remain R3 byte-identical.
Source original Git blob SHA-1 7944d4a814d8af55855f1fdec69a5fe237a3ce5f, SHA256 0df0a628208bba2edbbedbc528f4b760751382bed52143c41b4f5dcdcc777d04.
Installer guard BASE_COMMIT remains original verified P11433 testbranch baseline e77457211d9c8fa17b8fd7fdf502cf5a75209b1a. No github or device action authorized in this package.
Related route semantic test still legacy and needs full-repo execution; no 42/42 PASS claim.
