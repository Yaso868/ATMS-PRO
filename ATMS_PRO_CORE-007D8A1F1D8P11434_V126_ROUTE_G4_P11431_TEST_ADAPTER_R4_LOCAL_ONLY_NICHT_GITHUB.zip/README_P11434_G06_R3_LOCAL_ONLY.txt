ATMS PRO P11434 R3 / G06 PROVENANCE TEST ADAPTER – LOCAL ONLY / NICHT GITHUB

Fixes solely the historical G06 trace test adapter in tools/g06-01-quarantine-trace-selftest.js.
Original historical OCR candidates from P11410 diagnosis are preserved unchanged; full-cell views
now carry explicit sourceRow/sourceColumn/field. An independent opposing full-cell view carries
its own provenance. Eleven added checks guard missing/wrong provenance, edge clipping,
neighbor bleed, uncertain geometry, counterproof, and zero storage/import/network calls.

P11434 R2 production Android application files are bit identical; P11411 adapter is unchanged.
TARGET_VERSION P11434 remains unchanged; versionCode 11 is unchanged. No device/APK actions.
Validated LOCAL: G06 27/27 PASS, P11411 32/32 PASS, V1.26 22/22 PASS,
P11434 41/41 PASS, Runtime alignment PASS. Historical Actions #245: 18 CI preBuild
independent tests PASS; 20/42 overall mandatory preBuild tasks remain unexecuted on R3.
Not 42/42 PASS, not an Android build, not a Golden-73 photo test, not release approved.
New upload would require removal of prior R2 ZIP and separate explicit GitHub/Build approval.
