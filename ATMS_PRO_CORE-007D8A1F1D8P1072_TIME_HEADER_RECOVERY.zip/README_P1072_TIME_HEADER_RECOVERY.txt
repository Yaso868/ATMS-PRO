ATMS PRO · P107.2 · IMAGE TIME-HEADER RECOVERY
04.10.2026

Basis:
- Frisch heruntergeladener GitHub-main-Stand nach P107.1 / Actions #167 Success.
- Realgerät-Regression mit der unveränderten Referenzdatei IMG-20261004-WA0000.jpg:
  "Fehler: Pflichtspalten nicht erkannt: time."

Ursache / Scope:
- Die Bild-OCR kann bei identischer Planliste sporadisch das erste Kopfwort "Uhrzeit" komplett verlieren.
- Die bisherige Spaltenzuordnung bricht dann fail-closed ab, obwohl "Von"/"Nach" und die tatsächlichen Zeitwerte der Datenspalte vorhanden sind.

P107.2:
- Generischer, fail-closed Fallback nur für Bild-OCR.
- Kandidat ist ausschließlich die Spalte direkt links von der bereits sicher erkannten Abholspalte "Von".
- Übernahme nur bei mindestens 3 nichtleeren Zellen mit gültiger Uhrzeit und mindestens 60 % Zeit-Konsens.
- Es wird KEINE einzelne Fahrtzeit geraten, ersetzt oder hart codiert.
- Andere Mehrdeutigkeiten bleiben blockierend.
- Transparenter OCR-Recovery-Hinweis wird in der Analyse angezeigt.
- Service-Worker-Cache wird auf P107.2 angehoben.
- Der bestehende P107.1 Golden-Gate wird um einen deterministischen Test für genau diese Fehlerklasse erweitert.

Keine produktiven Flugnummer-, Fahrer-, Kunden-, Orts- oder Uhrzeit-Hardcodes.
